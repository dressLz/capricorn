Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    'state': {
      type: Boolean, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: false
    },
    "activeIndex": {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: 0
    },
    'venue_id': {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: ''
    },
    'is_order': {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: 0
    }
  },
  data: {
    // 这里是一些组件内部数据
    list: [{
      'name': '基础信息'
    }, {
      'name': '场地管理'
    }, {
      'name': '教练管理'
    }, ]
  },
  methods: {
    // 这里是一个自定义方法
    //场地管理
    bindsetting: function(e) {
      var index = e.currentTarget.dataset.index;
      if (this.properties.activeIndex != index) {
        if (this.properties.is_order != '1') {
          wx.showToast({
            title:'需场馆审核通过',
            mask: true,
            icon: 'none'
          })
          return;
        }
        if (index == 0) {
          wx.redirectTo({
            url: '../venue/venue?venue_id=' + e.currentTarget.dataset.venue + '&is_order=' + this.properties.is_order,
          })
        } else if (index == 1) {
          wx.redirectTo({
            url: '../reserve/reserve?venue_id=' + e.currentTarget.dataset.venue + '&is_order=' + this.properties.is_order,
          })
        } else {
          wx.redirectTo({
            url: '../coach/coach?venue_id=' + e.currentTarget.dataset.venue + '&is_order=' + this.properties.is_order,
          })
        }
      }
    },
  }
})