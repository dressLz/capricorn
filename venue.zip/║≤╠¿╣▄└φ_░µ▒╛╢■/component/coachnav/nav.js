Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    'state': {
      type: Boolean, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: true
    },
    "activeIndex": {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: 0
    },
    'venue_id': {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: ''
    },
    'is_order': {
      type: null, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: 0
    }
  },
  data: {
    // 这里是一些组件内部数据
    list: [{
      'name': '基础信息'
    }, {
      'name': '课程管理'
    }]
  },
  methods: {
    // 这里是一个自定义方法
    //场地管理
    onTapChild: function (event) {
      // detail对象，提供给事件监听函数
      var myEventDetail = {
        index: event.target.dataset.index
      }
      // 使用 triggerEvent 方法触发自定义组件事件，指定事件名、detail对象和事件选项
      this.triggerEvent('backindexto', myEventDetail)
    },
    bindsetting: function (e) {
      var index = e.currentTarget.dataset.index;
      if (this.properties.activeIndex != index) {
        if (this.properties.is_order != '1') {
          wx.showToast({
            title: '请先填写教练信息',
            mask: true,
            icon: 'none'
          })
          return;
        }
        if (index == 0) {
          wx.redirectTo({
            url: 'pages/index/pages/register/register'
          })
        } else if (index == 1) {
          wx.redirectTo({
            url: '../reserve/reserve?venue_id=' + e.currentTarget.dataset.venue + '&is_order=' + this.properties.is_order,
          })
        }
      }
    },
  }
})