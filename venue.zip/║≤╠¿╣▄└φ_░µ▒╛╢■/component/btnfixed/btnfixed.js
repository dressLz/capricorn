Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  properties:{
    'btntext': {
      type: String, //必填，目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value:'提交',
    },
  },
  data: {
    // 这里是一些组件内部数据
  },
  methods:{
    obtainfun:function(e){

    }
  }
})