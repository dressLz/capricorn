var util = require('../../../utils/util.js');
var setIn
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingStatus:false,
    imgUrl:'',
    user:{},
    count_down: '5:00',
    scrollX: true,
    sLeft: 0, //横向滚动距离
    tapindex: 0, //当前第几个
    deputyIndex:0,
    page_count:0,  //总页数
    page_index:1,
    page_size:20,
    navactive: [{
        'name': '全部订单',
        'news': false,
        'status':0,
        'news':0
      },
      {
        'name': '待确认',
        'news': false,
        'status': 1,
        'news': 0
      },
      {
        'name': '订单取消',
        'news': false,
        'status': 2,
        'news': 0
      },
      {
        'name': '待消费',
        'news': false,
        'status': 3,
        'news': 0
      },
      {
        'name': '已完成',
        'news': false,
        'status': 4,
        'news': 0
      },
    ],
    deputy: [{ 'name': '用户已取消', 'news': 0 }, { 'name': '商户已取消', 'news': 0 }, { 'name': '超时确认失败', 'news': 0 }],
    orderList: [],
    status_o:false,  //没有订单
    cancel:false,   //订单取消切换类
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    /**********************************************************************/ 
    var _this = this.data;
    this.setData({
      imgUrl: util.imgUrl(),
      user: util.get('user')
    })
    var data = {
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        userKey: util.get('user').userKey,
    }
  },
  //状态
  stausRequst:function(_this){
    for (let i = 0; i < 5; i++) {
      var data={
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        userKey: util.get('user').userKey,
        sub_type: util.get('user').sub_type,
        status: i,
      }
      util.requestGroups('supp/order/isNewOrderByStatus', data).then(
        (res) => {
          _this.navactive[i].news = res.data
          this.setData({
            navactive: _this.navactive
          })
          if (i == 0) {
            if (res.data == 1) {
              wx.showTabBarRedDot({
                index: 1
              })
            } else {
              wx.hideTabBarRedDot({
                index: 1
              })
            }
          }
        }
      )
    }
  },
  cancelRequst: function (_this) {
    for (let i = 0; i < 3; i++) {
      var data={
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        userKey: util.get('user').userKey,
        sub_type: util.get('user').sub_type,
        status: '2'+(i + 1),
        };
      util.requestGroups('supp/order/isNewOrderByStatus', data).then(
        (res) => {
          _this.deputy[i].news = res.data
          this.setData({
            deputy: _this.deputy
          })
        }
      )
    }
  },
  //取消的订单
  deputycancel:function(e){
    var index = e.currentTarget.dataset.index,_this=this.data;
    var frontIndex = '2' + (_this.deputyIndex + 1)
    if (index == _this.deputyIndex) { return }
    this.initial(this)
    util.requestGroups('supp/order/isNewOrderModify', {
      shop_id: util.get('user').shop_id,
      venue_id: util.get('user').venue_id,
      status: frontIndex,
      userKey: util.get('user').userKey,
      sub_type: util.get('user').sub_type,
    }).then((res) => {
      _this.deputy[_this.deputyIndex].news = 0
    })
    this.setData({
      deputyIndex:index,
      orderList: [],
      deputy: _this.deputy
    })
    if (util.getcache(util, '../../login/login')) {
      // wx.showLoading({ title: '加载中...', mask: true })
      this.orderList(this, _this.navactive[_this.tapindex].status,index+1)
    }
  },
  //一级菜单切换
  selectMeal: function(e) {
    var _this = this.data,
        index = e.currentTarget.dataset.index,
        frontIndex=_this.tapindex;
        this.setData({
          status_o:false
        })
    //是否是当前显示的项.
    if (index == _this.tapindex){return}
    this.initial(this)
    if(index==2){
      this.setData({cancel:true});
      var refund_status=1;
      this.cancelRequst(_this)  //查询二级菜单是否有新订单
    }else{
      this.setData({ cancel:false})  
    }
    this.setData({ loadingStatus: true })
    if (_this.tapindex != 0){
      var isOrder = {
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        status: _this.tapindex,
        userKey: util.get('user').userKey,
      };
      util.requestGroups('supp/order/isNewOrderModify', isOrder).then((res) => {
        _this.navactive[frontIndex].news = 0
        this.setData({
          navactive: _this.navactive,
          loadingStatus: false
        })
      })
    }
    this.setData({
      tapindex: index,
      orderList: [],
      navactive: _this.navactive
    })
    if (util.getcache(util, '../../login/login')) {
      // wx.showLoading({title:'加载中...',mask:true})
      this.orderList(this, _this.navactive[index].status, refund_status)
    }
  },
  //初始化函数
  initial:function(tant){
    tant.setData({
      page_count: 0,  //总页数
      page_index: 1,
      page_size: 20,
      orderList: [],
    })
  },
  // 订单详情
  orderDetails: function(e) {
    var index = e.currentTarget.dataset.index, _this = this.data;
    this.data.orderList[index].new_supp = 0
    this.setData({
      orderList: this.data.orderList
    })
    wx.navigateTo({
      url: '../../order/pages/details/details?order_id=' + e.currentTarget.dataset.id,
    })
  },
  //订单确认
  orderconfirm: function(e) {
    var index = e.currentTarget.dataset.index, _this=this.data;
    console.log(index)
    if (util.getcache(util, '../../login/login')) {
      wx.request({
        url: util.prefixUrl()+'supp/order/accept',
        method: 'POST',
        data:{
          userKey: util.get('user').userKey,
          order_id: e.currentTarget.dataset.id
        },
        success: (res) => {
          if (res.data.code == 0) {
            util.iconnone('确认成功')
            _this.orderList[index].status='3'
            this.setData({
              orderList: _this.orderList
            })
          }
        }
      })
    }
  },
  //订单取消
  ordercancel: function(e) {
    var index = e.currentTarget.dataset.index,_this=this.data;
    if (util.getcache(util, '../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/order/refuse',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          order_id: e.target.dataset.id
        },
        success: (res) => {
          if (res.data.code == 0) {
            util.iconnone('取消成功')
            _this.orderList[index].status = '4'
            _this.orderList[index].refund_status='2'
            this.setData({
              orderList: _this.orderList
            })
          }
        }
      })
    }
  },
  //备注
  navremarks: function(e) {
    wx.navigateTo({
      url: '../../order/pages/remarks/remarks?order_id=' + e.currentTarget.dataset.id,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // /**
    //    * Scoket链接
    //    * 
    //    */
    // wx.connectSocket({
    //   url: 'wss://shop.4into.com/wss',
    //   header: {
    //     'content-type': 'application/json'
    //   },
    //   method: 'POST',
    //   success(res) {
    //     console.log("--------------------连接成功了---------------------")
    //     console.log(res)
    //     console.log("--------------------连接成功了---------------------")
    //   }
    // })
    // /**
    //  * 
    //  * 监听 WebSocket 连接打开事件
    //  */
    // wx.onSocketOpen(function (res) {
    //   console.log("--------------------监听成功了---------------------")
    //   console.log(res)
    //   console.log("--------------------监听成功了---------------------")
    // })
    // /**** 监听 WebSocket 接受到服务器的消息事件**/
    // wx.onSocketMessage(function (res) {
    //   console.log(res)
    //   console.log("--------------------接受消息成功了---------------------")
    //   // console.log(JSON.parse(res.data))
    //   let client_id = JSON.parse(res.data).client_id; //通道号
    //   console.log("--------------------接受消息成功了---------------------")
    //   wx.request({
    //     url: 'https://shop.4into.com/index.php/supp/Supplier/bind',
    //     method: 'POST',
    //     data: {
    //       uid: util.get('user').supplier_id,
    //       client_id, //通道号
    //       utype: 's',
    //     },
    //     success: (res) => {
    //       console.log("----------------------绑定-----------------")
    //       console.log(res)
    //     }
    //   })
    // })
    // util.requestGroups('supp/Order/test',{userKey:util.get('user').userKey}).then((res)=>{
    //   console.log(res)
    // })
    /***********************************/ 
    var _this = this.data;
    if (_this.user.sub_type == '3') {
      util.iconnone('账号无权限')
      return;
    }
    if (util.getcache(util, '../../login/login')) {
      // wx.showLoading({ title: '加载中...', mask: true })
      _this.page_index=1;
      _this.orderList=[];
      this.setData({ loadingStatus: true })
      if (_this.tapindex=='2'){
        this.orderList(this, _this.navactive[_this.tapindex].status, _this.deputyIndex + 1);
        this.cancelRequst(_this);
      }else{
        this.orderList(this, _this.navactive[_this.tapindex].status);
      }
    }
    this.stausRequst(_this)
    setIn = setInterval(() => {
      this.stausRequst(_this)
    }, 60000)
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    clearInterval(setIn)
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  //触底加载
  bottomTouch:function(){
     var _this=this.data,tant=this;
    if (_this.page_index<_this.page_count){
       _this.page_index++
       wx.showLoading({ title: '加载中...', mask: true })
       tant.orderList(tant, _this.navactive[_this.tapindex].status, _this.deputyIndex + 1) 
      }
  },
  /*****/
  //状态
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  orderList: function (tant, status, refund_status) {
    if (status == 0) {
      var data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        page_index: tant.data.page_index,
        page_size: tant.data.page_size,
        sub_type: util.get('user').sub_type,
      }
    } else if (status != 2){
      var data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        page_index: tant.data.page_index,
        page_size: tant.data.page_size,
        status: status,
        sub_type: util.get('user').sub_type,
      }
    }else{
      var data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        page_index: tant.data.page_index,
        page_size: tant.data.page_size,
        status: status,
        refund_status: refund_status,
        sub_type: util.get('user').sub_type
      }
    }
    if (tant.data.user.sub_type=='4'){
      data.order_type=2
    }else{
      data.order_type = 1
    }
    wx.request({
      url: util.prefixUrl() +'supp/order/list',
      method: 'POST',
      data: data,
      success: (res) => {
        if (!res.data.code) {
          res.data.data.map((value,index)=>{
            if (value.use_time!=0){
              value.use_time=this.formatDate(new Date(value.use_time * 1000))
            }
          })
          tant.data.orderList=tant.data.orderList.concat(res.data.data)
          tant.setData({
            page_count: res.data.page_count,
            orderList: tant.data.orderList,
            loadingStatus:false
          })
        }
        tant.data.orderList.length == [] ? tant.setData({ status_o: true }) : tant.setData({ status_o: false })
        wx.hideLoading();
      },
      complete:()=>{
        wx.hideLoading()
      }
    })
  },
  formatDate:function(now) {
     var y,m,d;
      y = now.getFullYear(),
      m = now.getMonth() + 1,
      d = now.getDate();
      return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + now.toTimeString().substr(0,5);
  } 
})