var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
  },
  formSubmit:function(e){
    var _this = this.data,submit=true;
    var data = e.detail.value
    //表单是否为空
    submit=util.formdata(util, e.detail.value)
    if (e.detail.value.newpass.length < 8 || e.detail.value.newpass.length > 16){
        util.iconnone('长度必须大于8小于16')
       return
    }
    //两次输入密码是否一致
    if (e.detail.value.newpass_o != e.detail.value.newpass){
      util.iconnone('两次输入不一致')
      return;
    }
    delete data.newpass_o 
    data.userKey = util.get('user').userKey
    data.supplier_id = util.get('user').supplier_id
    data.operator_id = util.get('user').supplier_id
    data.username = util.get('user').username
    if (util.getcache(util, '../../../login/login') && submit){
      wx.request({
        url: util.prefixUrl() +'supp/supplier/modifypass',
        method:'POST',
        data:data,
        success:(res)=>{
          util.invalid(res.data,util,'../../../login')
          if(res.data.code==0){
            util.iconnone('修改成功')
            setTimeout(()=>{
              wx.navigateBack({})
            },1000)
          }else{
            util.iconnone(res.data.code)
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})