var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    imgUrl: '',
    disabled:false,
    user: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      user: util.get('user')
    })
  },
  //提现
  addWithdraw:function(){
    if (util.get('user').sub_type != 2) {
      util.iconnone('没有提现权限')
      return;
  }
  wx.request({
    url: util.prefixUrl() + 'supp/order/addWithdraw',
    method: 'POST',
    data:{
      userKey:util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_id: util.get('user').venue_id,
      operator_id: util.get('user').supplier_id,
      sub_type: util.get('user').sub_type
    },
    success:(res)=>{
      if(res.data.code==0){
        util.iconnone('已提交申请提现')
       this.data.info.all=0
        this.setData({
          info:this.data.info
        })
      }else{
        util.iconnone(res.data.msg)
      }
    }
  })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.request({
      url: util.prefixUrl() + 'supp/order/incomeInfo',
      method:'POST',
      data:{
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        operator_id: util.get('user').supplier_id,
        sub_type: util.get('user').sub_type
      },
      success:(res)=>{
        if (res.data.is_withdraw==0){
           this.data.disabled=true
        }else{
           this.data.disabled = false
        }
        this.setData({
          info:res.data,
          disabled: this.data.disabled
        }) 
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})