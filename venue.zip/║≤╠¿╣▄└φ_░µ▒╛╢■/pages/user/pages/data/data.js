var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    time:60,
    obtain:'获取验证码',
    timeBtn:false,
    newmunber:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  watchnumber:function(e){
    this.data.newmunber=e.detail.value
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data
    console.log(util.get('user'))
  },
  //验证码输入监听
  verification:function(e){
    if (e.detail.value.length==6){
      wx.request({
        url: util.prefixUrl() +'supp/supplier/chageTel',
        method:'POST',
        data:{
          supplier_id: util.get('user').supplier_id,
          tel: this.data.newmunber,
          codekey: e.detail.value
        },
        success:(res)=>{
          if (res.data.code == 0){
            wx.showToast({
              title: '修改成功',
              icon: 'loading',
              duration: 1000,
              success:()=>{
              }
            })
            util.set('user').tel = this.data.newmunber
            setTimeout(()=>{
              wx.navigateBack({})
            },1000)
          }else{
            wx.showToast({
              title: '验证码输入错误',
              image: '../../../image/wrong.png',
              duration: 1000,
              mask: true
            })
          }
        },
        fail:(fail)=>{

        }
      })
    }
  },
  submission:function(){
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },
  obtain:function(){
    if (this.data.newmunber.length==11){
      this.setData({
        timeBtn: true
      })
      var timeInt = setInterval(() => {
        if (this.data.time == 0) {
          clearInterval(timeInt)
          this.setData({
            timeBtn: false,
            time: 60,
            obtain: '重新获取'
          })
        }
        this.data.time--
        this.setData({
          time: this.data.time
        })
      }, 1000)
      console.log('获取')
      wx.request({
        url: util.prefixUrl() +'supp/supplier/sendBindCode',
        data: { tel: this.data.newmunber},
        method:'POST',
        success:(res)=>{
          console.log(res)
        },
        fail:(fail)=>{
        }
      }) 
    }else{
      wx.showToast({
        title: '请输入正确手机号',
        icon:'loading',
        duration:1000
      })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})