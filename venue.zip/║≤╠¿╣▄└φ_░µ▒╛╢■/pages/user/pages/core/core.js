var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page:true,
    first_brand:0,
    imgUrl:'',
    newMerchant: false,
    page_index: 1,
    page_size: 10,
    brandArray: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
    wx.showLoading({
      title: '加载中...',
    })
  },
  //品牌列表请求
  brandrequest: function() {
    var _this = this.data;
    if (util.get('user')) {
      var data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        page_index: _this.page_index,
        page_size: _this.page_size
      }
      util.requestGroup(util.prefixUrl() +'supp/supplier/brandlist', data).then((res) => {
          if (res.data.data) {
            this.setData({
              newMerchant: false,
              brandArray: res.data.data
            })
          } else {
            this.setData({
              newMerchant: true
            })
          }
        },
        (res) => {
          util.iconnone('网络故障')
        }
      )
    } else {
      wx.reLaunch({
        url: '../../login/login',
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /*添加品牌商户*/
  addbrandBtn: function() {
    if (this.data.first_brand == 0 && this.data.newMerchant==false){
      util.iconnone('等待第一个品牌审核')
      return;
    }
    wx.navigateTo({
      url: '../brand/brand?state=' + 'add',
    })
  },
  // 商户详情
  seebrandBtn: function(e) {
    wx.navigateTo({
      url: '../brand/brand?brand_id=' + e.currentTarget.dataset.id,
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.brandrequest()
    util.requestGroups('supp/Supplier/brandShop', { shop_id: util.get('user').shop_id}).then(
      (res) => {
        this.setData({
          first_brand: res.data.is_visible,
          page:false
        })
        wx.hideLoading()
      }
    )
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})