var o = function(o) {
    return o && o.__esModule ? o : {
      default: o
    };
  }(require("../../utils/weCropper.js")),
  e = wx.getSystemInfoSync(),
  t = e.windowWidth,
  r = e.windowHeight - 50;
var app = getApp();
Page({
  data: {
    rotateI:0,
    cropperOpt: {
      id: "cropper",
      width: t,
      height: r,
      scale: 2.5,
      zoom: 8,
      cut: {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      }
    },
  },
  rotateImg:function(){
    const self = this;
    let rotateI = this.data.rotateI + 1;
    this.setData({
      rotateI: rotateI
    })
    this.wecropper.updateCanvas(rotateI)
  },
  touchStart: function(o) {
    this.wecropper.touchStart(o);
  },
  touchMove: function(o) {
    this.wecropper.touchMove(o);
  },
  touchEnd: function(o) {
    this.wecropper.touchEnd(o);
  },
  getCropperImage: function() {
    this.wecropper.getCropperImage(function(o) {
      var pages = getCurrentPages();
      var currPage = pages[pages.length - 1];   //当前页面
      var prevPage = pages[pages.length - 2];  //上一个页面
      //直接调用上一个页面对象的setData()方法，把数据存到上一个页面中去
      prevPage.setData({
        urlImg:o
      });
      wx.navigateBack({
        delta: 1
      })
    });
  },
  uploadTap: function() {
    var o = this;
    wx.chooseImage({
      count: 1,
      sizeType: ["original", "compressed"],
      sourceType: ['camera', 'album'],
      success: function(e) {
        var t = e.tempFilePaths[0];
        o.wecropper.pushOrign(t);
      }
    });
  },
  onLoad: function(e) {
    var isChoose = e.isChoose,tant=this;
    var data=JSON.parse(e.data)
    this.data.cropperOpt.cut.width = data.width;
    this.data.cropperOpt.cut.height = data.height;
    this.data.cropperOpt.cut.x = (this.data.cropperOpt.width - this.data.cropperOpt.cut.width) / 2;
    this.data.cropperOpt.cut.y = (this.data.cropperOpt.height - this.data.cropperOpt.cut.height) / 2;
    var t = this.data.cropperOpt,
      r = e.src;
    r && (Object.assign(t, {
      src: r
    }), new o.default(t).on("ready", function(o) {
      tant.wecropper.updateCanvas(tant.data.rotateI)
    }).on("beforeImageLoad", function(o) {
      console.log("before picture loaded, i can do something"), console.log("current canvas context:", o),
        wx.showToast({
          title: "上传中",
          icon: "loading",
          duration: 2e4
        });
    }).on("imageLoad", function(o) {
      console.log("picture loaded"), console.log("current canvas context:", o), wx.hideToast();
    }));
  }
});