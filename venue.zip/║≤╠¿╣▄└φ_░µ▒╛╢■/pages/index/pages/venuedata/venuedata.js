var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    multiIndex: [],
    vehicle: ['无', '有'],
    decoration: '', //最新装修时间
    vehicleIndex: 0,
    multiArray: [], //营业时间
    /***是否填写***/
    venue_id: '',
    disabled: false,
    attr: '', //包含服务
    attr_value: '', //包含服务
    img_id_arr: '', //上传的图片id
    venue_pic: '', //场馆的第一张图
    img_list: '', //场馆图片数组
    videoPic: '',
    videoSrc: '',
    venue_info: {},
    regionOriginal: [],
    region: [
      ['-'],
      ['-'],
      ['-']
    ],
    region_index: [0, 0, 0], //城市选择的下标
    region_id: {},
    venue_address: '', //详细地址
    province_id: 0, //省id
    city_id: 0,
    district_id: 0,
    img_no: 0, //图片数量
    video_no: 0, //视频数量
    show_attr: '',
    introd_state: '',
    warning_state: '',
    timeEnd:'',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      timeEnd: util.timestampToTime((new Date()).getTime() / 1000)
    })
    var _this = this.data;
    if (options.venue_id) {
      this.data.venue_id = options.venue_id
    }
    this.setData({
      multiArray: util.multiArray(),
      imgUrl: util.imgUrl(),
    })
    //场馆信息
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/venue/venueInfo',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          _this.multiArray[0].map((value, index) => {
            if (value == res.data.open_time) {
              _this.multiIndex[0] = index
            }
            if (res.data.close_time=='00:00'){
              _this.multiIndex[1] = _this.multiArray[0].length-1
            } else if (value == res.data.close_time){
              _this.multiIndex[1] = index
            }
          })
          if (res.data.attr.length > 0) {
            _this.show_attr = res.data.attr[0].attr_name + '...'
          }
          _this.province_id = res.data.province_id
          _this.city_id = res.data.city_id
          _this.district_id = res.data.district_id
          if (res.data.introduction.length > 0) {
            _this.introd_state = '查看'
          }
          if (res.data.warning.length > 0) {
            _this.warning_state = '查看'
          }
          this.setData({
            venue_info: res.data,
            multiIndex: _this.multiIndex,
            img_no: res.data.img_no,
            video_no: res.data.video_no,
            vehicleIndex:res.data.park,
            show_attr: _this.show_attr,
            introd_state: _this.introd_state,
            warning_state: _this.warning_state,
            decoration: res.data.decoration
          })
        }
      })
    }
    this.province(this)
  },
  //营业时间
  bindMultiPickerChange: function(e) {
    this.setData({
      multiIndex: e.detail.value
    })
  },
  //是否有停车位
  vehiclePickerChange: function(e) {
    this.setData({
      vehicleIndex: e.detail.value
    })
  },
  /**上传图片,视频跳转**/
  bindUpload: function() {
    var _this = this.data;
    wx.navigateTo({
      url: '../upload/upload?venue_id=' + _this.venue_id + '&videoPic=' + _this.videoPic + '&videoSrc=' + _this.videoSrc + '&img_id_arr=' + _this.img_id_arr + '&img_list=' + JSON.stringify(_this.img_list),
    })
  },
  template: function() {
    wx.navigateTo({
      url: '../template/template?venue_id=' + this.data.venue_id,
    })
  },
  /**/
  introductionnav: function(e) {
    wx.navigateTo({
      url: '../brief/brief?venue_id=' + this.data.venue_id,
    })
  },
  warningnav: function(e) {
    wx.navigateTo({
      url: '../warning/brief?venue_id=' + this.data.venue_id,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/venue/venueInfo',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          if (res.data.attr.length > 0) {
            _this.show_attr = res.data.attr[0].attr_name + '...'
          }
          _this.province_id = res.data.province_id,
            _this.city_id = res.data.city_id,
            _this.district_id = res.data.district_id

          if (res.data.introduction.length > 0) {
            _this.introd_state = '查看'
          }
          if (res.data.warning.length > 0) {
            _this.warning_state = '查看'
          }
          this.setData({
            img_no: res.data.img_no,
            video_no: res.data.video_no,
            show_attr: _this.show_attr,
            introd_state: _this.introd_state,
            warning_state: _this.warning_state,
            venue_address: res.data.venun_address
          })
          this.province(this)
        }
      })
    }
  },
  // 选择省市区函数
  changeRegin(e) {
    this.setData({
      region_index: e.detail.value
    })
  },
  columnregin: function(e) {
    if (e.detail.column == 0) {
      this.data.regionOriginal[0][e.detail.value].province_id
      this.city(this, this.data.regionOriginal[0][e.detail.value].province_id, this.data)
    } else if (e.detail.column == 1) {
      this.area(this, this.data.regionOriginal[1][e.detail.value].city_id, this.data)
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  //填写详细地址
  navregion: function() {
    wx.navigateTo({
      url: '../region/region?venue_id=' + this.data.venue_id
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},
  //提交
  formSubmit: function(e) {
    var _this = this.data,
      submission = true;
    if (_this.multiIndex[0]>_this.multiIndex[1]){
      util.iconnone('营业时间有误')
      return
    }
    if (util.getcache(util, '../../../login/login')) {
      var data = e.detail.value;
      data.venue_id = _this.venue_id
      data.shop_id = util.get('user').shop_id
      data.operator_id = util.get('user').supplier_id
      data.userKey = util.get("user").userKey;
      data.is_order = 0;
      wx.showLoading({
        mask: true
      })
      var url = "";
      if (this.data.venue_info.is_order_a == '1') {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      wx.request({
        url: util.prefixUrl() + url,
        method: 'POST',
        data: data,
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          if (res.data.code == 0) {
            util.iconnone('保存成功')
            setTimeout(() => {
              wx.navigateBack({})
            }, 1000)
          }
        },
        complete: () => {
          wx.hideLoading({})
        }
      })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  //验证
  subm: function(data_from, submission) {
    for (var i in data_from) {
      if (data_from[i].replace(/\s*/g, "").length == 0) {
        submission = false
      }
    }
    return submission;
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  /***/
  serviceNav: function() {
    wx.navigateTo({
      url: '../service/service?venue_id=' + this.data.venue_id + '&venue_info=' + JSON.stringify(this.data.venue_info),
    })
  },
  //最新装修时间
  renovation: function(e) {
    this.setData({
      decoration: e.detail.value
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  rendering: function(regionOriginal, _this, tant) {
    _this.region_index
    _this.province_id
    _this.city_id
    _this.district_id
    regionOriginal[0].map((value, index) => {
      if (value.province_id == _this.province_id) {
        _this.region_index[0] = index
      }
    })
    regionOriginal[1].map((value, index) => {
      if (value.city_id == _this.city_id) {
        _this.region_index[1] = index
      }
    })
    regionOriginal[2].map((value, index) => {
      if (value.district_id == _this.district_id) {
        _this.region_index[2] = index
      }
    })
    tant.setData({
      region_index: _this.region_index
    })
  },
  province: function(tant) {
    var _this = this.data;
    //省市区
    wx.request({
      url: util.prefixUrl() +'supp/venue/getprovincelist',
      method: 'POST',
      async: false,
      data: {
        userKey: util.get('user').userKey
      },
      success: (res) => {
        _this.regionOriginal[0] = res.data
        _this.regionOriginal[0].map((value, index) => {
          _this.region[0][index] = value.province_name
        })
        tant.setData({
          region: _this.region
        })
        tant.city(tant, _this.regionOriginal[0][_this.region_index[0]].province_id, _this)
      }
    })
  },
  city: function(tant, province_id, _this) {
    wx.request({
      url: util.prefixUrl() +'supp/venue/getcitylist',
      method: 'POST',
      async: false,
      data: {
        userKey: util.get('user').userKey,
        province_id: province_id
      },
      success: (res) => {
        _this.regionOriginal[1] = res.data
        _this.regionOriginal[1].map((value, index) => {
          _this.region[1][index] = value.city_name
        })
        tant.setData({
          region: _this.region
        })
        tant.area(tant, _this.regionOriginal[1][_this.region_index[1]].city_id, _this)
      }
    })
  },
  area: function(tant, city_id, _this) {
    wx.request({
      url: util.prefixUrl() +'supp/venue/getdistrictlist',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        city_id: city_id
      },
      success: (res) => {
        _this.regionOriginal[2] = res.data
        _this.regionOriginal[2].map((value, index) => {
          _this.region[2][index] = value.district_name
        })
        tant.setData({
          region: _this.region
        })
        tant.rendering(_this.regionOriginal, _this, tant)
      }
    })
  }
})