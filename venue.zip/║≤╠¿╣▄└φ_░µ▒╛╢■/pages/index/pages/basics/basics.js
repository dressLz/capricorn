var util = require('../../../../utils/util.js')
var longTime;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    initial_multiIndex:[0,0],
    imgUrl: '',
    is_point: 0,
    priceText: '价格/小时',
    choiceTime: false, //选择时间蒙层
    spec_id: '',
    stencil_id: 0, //是否最新创建
    venue_id: '',
    multiArray: [], //时间数组
    initial_Array:[],//营业时间的时间数组
    multiIndex: [0, 0], //下标
    paragraph: [{
      open_time: '',
      close_time: '',
      num: '',
      price: ''
    }],
    paraIndex: [
      [0, 0]
    ],
    spot: {},
    num: '',
    datasetindex: 0,
    txtStyle: '',
    delBtnWidth: 200,
    startX: 0,
    lao_point: 0,
  },
  //营业时间选择,
  bindinitialtime:function(e){
    this.setData({
      initial_multiIndex:e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this=this.data,
        endsum=0;
    _this.multiArray = util.multiArray();
    _this.initial_Array = util.multiArray();
    endsum = this.data.multiArray[0].length - 1;
    this.setData({
      multiArray: _this.multiArray,
      initial_multiIndex: [0,endsum],
      initial_Array: _this.initial_Array,
      imgUrl: util.imgUrl(),
    })
    this.data.venue_id = options.venue_id;
  },
  choiceDate: function() {
    this.setData({
      choiceTime: true
    })
  },
  numinputwatch: function(e) {
    this.data.num = e.detail.value
  },
  numinputPara: function(e) {
    this.data.paragraph[e.currentTarget.dataset.index].num = e.detail.value
    this.setData({
      paragraph: this.data.paragraph
    })
  },
  priceinputPara: function(e) {
    this.data.paragraph[e.currentTarget.dataset.index].price = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
  },
  //失去焦点时截取
  priceinputblur: function(e) {
    e.detail.value = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
    var value = parseFloat(e.detail.value);
    this.data.paragraph[e.currentTarget.dataset.index].price = value.toFixed(2)
    this.setData({
      paragraph: this.data.paragraph
    })
  },
  bindMultiPickerChange: function(e) {
    if (parseInt(e.detail.value[0]) >= parseInt(e.detail.value[1])) {
      util.iconnone('起始时间超过截止时间')
      return;
    }
    this.data.paraIndex[e.currentTarget.dataset.index] = e.detail.value
    this.data.paragraph[e.currentTarget.dataset.index].open_time = this.data.multiArray[0][e.detail.value[0]]
    this.data.paragraph[e.currentTarget.dataset.index].close_time = this.data.multiArray[0][e.detail.value[1]]
    console.log(e.detail.value)
    this.setData({
      paraIndex: this.data.paraIndex,
      multiIndex: e.detail.value
    })
    console.log(this.data.paraIndex)
  },
  addDate: function() {
    var _this = this.data,
        length = _this.paraIndex.length;
    _this.paragraph.push({
      open_time: _this.multiArray[0][_this.paraIndex[length-1][1]],
      close_time: _this.multiArray[0][_this.paraIndex[length - 1][1]],
      num: '',
      price: ''
    })
    _this.paraIndex.push([_this.paraIndex[length - 1][1], _this.paraIndex[length - 1][1]+2])
    this.setData({
      paragraph: _this.paragraph,
      paraIndex: _this.paraIndex
    })
  },
  formSubmit: function(e) {
    var _this = this.data,
      dissubmit = true,
      paraData = {
        price: '',
        close_time: '',
        open_time: '',
        num: '',
      };
    if (_this.is_point == 0) {
      if (_this.paragraph.length==0){
        util.iconnone('必须设置基础模板')
        return;
      }
      if (_this.paragraph[0].open_time == '') {
        _this.paragraph[0].open_time = _this.multiArray[0][_this.paraIndex[0][0]]
        _this.paragraph[0].close_time = _this.multiArray[0][_this.paraIndex[0][1]]
      }
      var dateList = [],
        dateList2 = [],
        isRepeat = false,  //模板设置时间冲突
        business=true,     //模板与营业时间冲突
        is_price = true;
      _this.paragraph.map((value, index) => {
        if (value.price == 0 || value.price.length == 0) {
          is_price = false
        }
        dateList2.push([])
        dateList.push([_this.multiArray[0].indexOf(value.open_time), _this.multiArray[0].indexOf(value.close_time)])
      })
      if (!is_price) {
        util.iconnone("价格不可为0")
        return
      }
      wx.showLoading({
        title: '审查中..',
        mask: true
      })
      dateList.map((value, index) => {
        if (value[0] < _this.initial_multiIndex[0] || value[1] > _this.initial_multiIndex[1]){
          business=false;
        }
        var sum = (value[1] - value[0]) + 1
        for (var i = 1; i < sum; i++) {
          dateList2[index].push(value[0] + i)
        }
      })
      if (!business){
         util.iconnone('营业时间和模板时间冲突');
         return;
      }
      dateList2.map((value, index) => {
        dateList2.map((value2, index2) => {
          if (index != index2) {
            var array1 = value
            var array2 = value2
            var tempArray1 = []; //临时数组1
            var tempArray2 = []; //临时数组2
            for (var i = 0; i < array2.length; i++) {
              tempArray1[array2[i]] = true; //将数array2 中的元素值作为tempArray1 中的键，值为true；
            }
            for (var i = 0; i < array1.length; i++) {
              if (tempArray1[array1[i]]) {
                tempArray2.push(array1[i]); //过滤array1 中与array2 相同的元素；
              }
            }
            if (tempArray2.length > 0) {
              isRepeat = true;
            }
          }
        })
      })
      wx.hideLoading({})
      if (isRepeat) {
        util.iconnone('时间冲突,请重选')
        return;
      }
      _this.paragraph.map((value, index) => {
        paraData.open_time += value.open_time + ','
        paraData.close_time += value.close_time + ','
        paraData.num += value.num.toString() + ','
        paraData.price += value.price.toString() + ','
      })
      paraData.stencil_id = _this.stencil_id
      paraData.venue_id = _this.venue_id
      paraData.spec_id = _this.spec_id
      paraData.is_point = _this.is_point
      paraData.supplier_id = util.get('user').supplier_id
      paraData.userKey = util.get('user').userKey
      paraData.start_time = _this.initial_Array[0][_this.initial_multiIndex[0]]
      paraData.end_time = _this.initial_Array[0][_this.initial_multiIndex[1]]
      if (dissubmit) {
        wx.showLoading({
          mask: true
        })
        wx.request({
          url: util.prefixUrl() + 'supp/venue/stencilsave',
          method: 'POST',
          data: paraData,
          success: (res) => {
            if (!res.code) {
              util.iconnone('保存成功')
              wx.navigateBack({})
            }
          },
          complete: () => {
            wx.hideLoading({})
          }
        })
      }
    } else if (_this.is_point == 1) {
      for (var k in e.detail.value) {
        if (e.detail.value[k].length == 0) {
          dissubmit = false
        }
      }
      if (e.detail.value.price == 0 || e.detail.value.price.length == 0) {
        util.iconnone("价格不可为0")
        return
      }
      if (util.get('user').userKey == undefined) {
        return
      }
      var data = e.detail.value;
      data.venue_id = this.data.venue_id
      data.spec_id = this.data.spec_id
      data.supplier_id = util.get('user').supplier_id
      data.userKey = util.get('user').userKey
      data.stencil_id = this.data.stencil_id
      if (dissubmit) {
        wx.showLoading({
          mask: true
        })
        wx.request({
          url: util.prefixUrl() + 'supp/venue/stencilsave',
          method: 'POST',
          data: data,
          success: (res) => {
            if (!res.code) {
              util.iconnone('保存成功')
              wx.navigateBack({})
            }
          },
          complete: () => {
            wx.hideLoading({})
          }
        })
      }
    }
  },
  //
  paragraphnav: function() {
    var _this = this.data;
    this.setData({
      is_point: 0,
      multiIndex: [0, parseInt(_this.multiArray[1].length - 1)],
      priceText: '价格/次'
    })
    if (_this.paragraph.length == 1 && _this.paragraph[0].open_time == "") {
      this.setData({
        paraIndex: [
          [0, parseInt(_this.multiArray[1].length - 1)]
        ],
      })
      _this.paragraph[0] = {
        open_time: _this.multiArray[1][0],
        close_time: _this.multiArray[1][_this.multiArray[1].length - 1],
        num: '',
        price: ''
      }
    }
    if (this.data.stencil_id == 0) {
      this.setData({
        paraIndex: [
          [0, parseInt(this.data.multiArray[1].length - 1)]
        ],
      })
    }
  },
  spotnav: function() {
    this.setData({
      is_point: 1,
      multiIndex: [0, parseInt(this.data.multiArray[1].length - 1)],
      priceText: '价格/小时'
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data;
    wx.request({
      url: util.prefixUrl() + 'supp/venue/spec',
      method: 'POST',
      data: {
        venue_id: this.data.venue_id,
        userKey: util.get('user').userKey
      },
      success: (res) => {
        this.setData({
          spec_id: res.data[0].spec_id
        })
        wx.request({
          url: util.prefixUrl() + 'supp/venue/stencil',
          method: 'POST',
          data: {
            venue_id: _this.venue_id,
            spec_id: _this.spec_id,
            userKey: util.get('user').userKey
          },
          success: (res) => {
            _this.stencil_id = res.data.stencil_id
            // _this.multiArray[0] = res.data.default_time.split(',')
            // _this.multiArray[1] = res.data.default_time.split(',')
            if (res.data.info_array){
              _this.initial_multiIndex = [_this.initial_Array[0].indexOf(res.data.open_time), _this.initial_Array[0].indexOf(res.data.close_time)];
            }
            _this.multiIndex = [0, parseInt(_this.multiArray[1].length - 1)]
            if (res.data.is_point == '1') {
              if (res.data.stencil_id == 0) {
                this.setData({
                  multiArray: _this.multiArray,
                  initial_Array: _this.initial_Array,
                  // is_point: res.data.is_point,
                  lao_point: res.data.is_point,
                  multiIndex: _this.multiIndex,
                  initial_multiIndex: _this.initial_multiIndex
                })
              } else {
                _this.spot = res.data
                this.setData({
                  multiArray: _this.multiArray,
                  initial_Array: _this.initial_Array,
                  is_point: res.data.is_point,
                  multiIndex: _this.multiIndex,
                  spot: _this.spot,
                  initial_multiIndex: _this.initial_multiIndex,
                  num: parseInt(_this.spot.num)
                })
              }
            } else if (res.data.is_point == '0') {
              _this.is_point = res.data.is_point
              this.setData({
                priceText: '价格',
                is_point: _this.is_point,
                multiArray: _this.multiArray
              })
              if (res.data.info_array){
                this.setData({ paragraph: res.data.info_array})
                if (res.data.info_array[0].open_time != '') {
                  _this.paraIndex = []
                  _this.paragraph.map((value, index) => {
                    _this.paraIndex.push([_this.multiArray[0].indexOf(value.open_time), _this.multiArray[0].indexOf(value.close_time)]);
                  })
                } else {
                  _this.paraIndex.push([0, parseInt(this.data.multiArray[1].length - 1)])
                } 
              }
              this.setData({
                paraIndex: _this.paraIndex,
                initial_multiIndex: _this.initial_multiIndex
              })
            }
          }
        })
      }
    })
  },
  //加
  addnumtime: function(e) {
    var _this = this.data;
    if (_this.is_point == 1) {
      _this.num++
        this.setData({
          num: _this.num
        })
    } else {
      var index = e.currentTarget.dataset.index;
      parseInt(_this.paragraph[index].num)
      _this.paragraph[index].num++
        this.setData({
          paragraph: _this.paragraph
        })
    }
  },
  reducenumtime: function(e) {
    var _this = this.data;
    if (_this.is_point == 1) {
      _this.num > 0 ? _this.num-- : '';
      this.setData({
        num: _this.num
      })
    } else {
      var index = e.currentTarget.dataset.index;
      parseInt(_this.paragraph[index].num)
      _this.paragraph[index].num > 0 ? _this.paragraph[index].num-- : '';
      this.setData({
        paragraph: _this.paragraph
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  touchS: function(e) {
    this.data.datasetindex = e.currentTarget.dataset.index
    if (e.touches.length == 1) {
      this.setData({
        //设置触摸起始点水平方向位置
        startX: e.touches[0].clientX,
        datasetindex: this.data.datasetindex
      });
    }
  },
  touchM: function(e) {
    if (e.touches.length == 1) {
      //手指移动时水平方向位置
      var moveX = e.touches[0].clientX;
      //手指起始点位置与移动期间的差值
      var disX = this.data.startX - moveX;
      var delBtnWidth = this.data.delBtnWidth;
      this.data.txtStyle = '';
      if (disX == 0 || disX < 0) { //如果移动距离小于等于0，说明向右滑动，文本层位置不变
        this.data.txtStyle = "left:0rpx";
      } else if (disX > 0) { //移动距离大于0，文本层left值等于手指移动距离
        this.data.txtStyle = "left:-" + disX + "rpx";
        if (disX >= delBtnWidth) {
          //控制手指移动距离最大值为删除按钮的宽度
          this.data.txtStyle = "left:-" + delBtnWidth + "rpx";
        }
      }
      //获取手指触摸的是哪一项
      //更新列表的状态
      this.setData({
        txtStyle: this.data.txtStyle
      });
    }
  },
  touchE: function(e) {
    if (e.changedTouches.length == 1) {
      //手指移动结束后水平位置
      var endX = e.changedTouches[0].clientX;
      //触摸开始与结束，手指移动的距离
      var disX = this.data.startX - endX;
      var delBtnWidth = this.data.delBtnWidth;
      //如果距离小于删除按钮的1/2，不显示删除按钮
      var txtStyle = disX > delBtnWidth / 2 ? "left:-" + delBtnWidth + "rpx" : "left:0rpx";
      //获取手指触摸的是哪一项
      var index = e.currentTarget.dataset.index;
      var list = this.data.list;
      this.data.txtStyle = txtStyle;
      //更新列表的状态
      this.setData({
        txtStyle: this.data.txtStyle
      });
    }
  },
  delItem: function(e) {
    var _this=this.data;
    _this.paragraph.splice(e.currentTarget.dataset.index, 1)
    _this.paraIndex.splice(e.currentTarget.dataset.index, 1)
    this.setData({
      paragraph: _this.paragraph,
      paraIndex: _this.paraIndex,
      datasetindex:'Q'
    })
    util.iconnone('删除成功')
  },
  reducelongTap:function(e){
    var index = e.currentTarget.dataset.index,
      _this = this.data;
    longTime = setInterval(() => {
      if (_this.is_point == 1) {
        _this.num--
        this.setData({
          num: _this.num
        })
      } else {
        if (parseInt(_this.paragraph[index].num)==0){
          clearInterval(longTime)
          return;
        }
        parseInt(_this.paragraph[index].num)
        _this.paragraph[index].num--
        this.setData({
          paragraph: _this.paragraph
        })
      }
    },200)
  },
  addlongTap: function(e) {
    var index = e.currentTarget.dataset.index,
    _this = this.data;
      longTime = setInterval(() => {
        if (_this.is_point == 1) {
            _this.num++
            this.setData({
              num: _this.num
            })
        } else {
          parseInt(_this.paragraph[index].num)
          _this.paragraph[index].num++
            this.setData({
              paragraph: _this.paragraph
            })
        }
      },200)
  },
  leave: function(e) {
    clearInterval(longTime)
  }
})