var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    venue_id:0,
    coach_info:'',
    disabled:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.venue_id){
      this.data.venue_id = options.venue_id
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /*提交*/
  formSubmit:function(e){
    var data = e.detail.value, _this = this.data,submission=true;
    if (data.coach_username.length!=0){
      if (!util.checkaccount(data.coach_username)) {
        util.iconnone('账号名称格式有误')
        return;
      }
    }
    if (data.coach_pass.length != 0) {
      if (!util.password(data.coach_pass)) {
        util.iconnone('密码长度大于8小于16')
        submission = false;
        return;
      }
    }
    for( var i in data){
      if (data[i].toString().length==0){
        util.iconnone('请完善信息')
        submission=false
      }
    }
    if (_this.coach_info.coach_username.length==0){
    util.postRequestLoading({
      username: data.coach_username
    },(res) => {
        //res就是返回的数据
        if (submission && util.get('user').userKey) {
          if (res.code == 1) {
            wx.showToast({
              title: '账号已占用',
              image: '../../../image/error.png',
              duration: 1000,
              mask: true,
              success: () => { },
              complete: () => { }
            })
          } else {
            wx.showLoading({ mask: true })
            data.userKey = util.get('user').userKey
            data.venue_id = _this.venue_id
            data.shop_id = util.get('user').shop_id
            if (!util.getcache(util, '../../../login/login')) {
              return;
            }
            wx.request({
              url: util.prefixUrl() +'supp/venue/modify',
              method: 'POST',
              data: data,
              success: (res) => {
                if (res.data.code == 0) {
                  util.iconnone('创建成功');
                  var pages = getCurrentPages();
                  var prevPage = pages[pages.length - 2]; //上一个页面
                  prevPage.setData({
                    coach: "1"
                  })
                  wx.navigateBack();
                } else if (res.data.code == 1) {
                  util.iconnone(res.data.msg);
                  return;
                }
                if (res.data.code == -1) {
                  util.invalid(res.data, util, '../../../login/login')
                }
              },
              complete: () => {
                wx.hideLoading({})
              }
            })
          }
        }
      }, (res) => {
        console.log(res)
      })
    }else{
      wx.showLoading({ mask: true })
      data.userKey = util.get('user').userKey
      data.venue_id = _this.venue_id
      data.shop_id = util.get('user').shop_id
      if (!util.getcache(util, '../../../login/login')) {
        return;
      }
      wx.request({
        url: util.prefixUrl() + 'supp/venue/modify',
        method: 'POST',
        data: data,
        success: (res) => {
          if (res.data.code == 0) {
            util.iconnone('创建成功');
            var pages = getCurrentPages();
            var prevPage = pages[pages.length - 2]; //上一个页面
            prevPage.setData({
              coach: "1"
            })
            wx.navigateBack();
          }
          if (res.data.code == -1) {
            util.invalid(res.data, util, '../../../login/login')
          }
        },
        complete: () => {
          wx.hideLoading({})
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/venue/coach',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          console.log(res)
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          res.data.coach_username.length > 0 ? _this.disabled=true: _this.disabled = false
          this.setData({
            coach_info: res.data,
            disabled:_this.disabled
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})