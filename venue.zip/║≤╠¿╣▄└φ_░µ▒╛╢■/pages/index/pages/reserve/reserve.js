var util = require('../../../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    is_order:0,
    venue_id:0,
    spec_id:'',
    stencil_id:'',
    state:true,
    scrollX:true,
    activeIndex:0,
    rensum:1,
    startTime:'',
    ifadd:true,
    endTime:'',
    settlement:0,//单价
    navList: [],
    initial:1,
    hourone:'',
    hourtow: '',
    para_list:[],
    hour: [],
    houreffect: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this.data;
    this.setData({
      venue_id: options.venue_id,
      is_order: options.is_order
    })
    _this.hour.map((value)=>{
      value['tap'] = false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.navtap = this.selectComponent("#navtap")
  },
  // 导航
  navscroll:function(e){
    var _this=this.data;
    _this.activeIndex = e.currentTarget.dataset.index
    this.setData({
      activeIndex: _this.activeIndex
    })
    this.stencilUpdate(_this, this, _this.spec_id)
  },
  // 选择时间
  bindselect:function(e){
    var _this=this.data;
    _this.hour[e.currentTarget.dataset.index].tap = !_this.hour[e.currentTarget.dataset.index].tap
    this.setData({
      hour: _this.hour
    })
  },
  //时间段选择
  paraSelection: function (e) {
    var _this = this.data
    _this.para_list[e.currentTarget.dataset.index].tap =! _this.para_list[e.currentTarget.dataset.index].tap
    this.setData({
      para_list: _this.para_list
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data
    _this.navList = [];
    var timestamp = (new Date()).getTime() / 1000
    _this.day = util.timestampToTime(timestamp)
    this.setData({
      navList: util.navlist()
    })
    wx.request({
      url: util.prefixUrl() +'supp/venue/spec',
      method:'POST',
      data:{
        venue_id: _this.venue_id,
        userKey: util.get('user').userKey
      },
      success:(res)=>{
        _this.spec_id=res.data[0].spec_id
        this.stencilUpdate(_this,this,_this.spec_id)
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  //预定支付
  checktap: function () {
    var _this = this.data, ornot = false, list = [];
    if (_this.initial==2){
      _this.para_list.map((value) => {
        if (value.tap) {
          ornot = true;
          list.push(value.date)
        }
      })
      if (ornot) {
        wx.navigateTo({
          url: '../setting/setting?para_list=' + JSON.stringify(_this.para_list) + '&week=' + _this.navList[_this.activeIndex].week + '&venue_id=' + _this.venue_id + '&spec_id=' + _this.spec_id + '&stencil_id=' + _this.stencil_id + '&in_day=' + _this.navList[_this.activeIndex].year,
        })
      } else {
        wx.showToast({
          title: '请选择场地',
          icon: 'loading'
        })
        return
      } 
    } else {
      _this.hour.map((value) => {
        if (value.tap) {
          ornot = true;
          list.push(value.date)
        }
      })
      if (ornot) {
        wx.navigateTo({
          url: '../setting/setting?para_list=' + JSON.stringify(_this.hour) + '&week=' + _this.navList[_this.activeIndex].week + '&venue_id=' + _this.venue_id + '&spec_id=' + _this.spec_id + '&stencil_id=' + _this.stencil_id + '&in_day=' + _this.navList[_this.activeIndex].year,
        })
      } else {
        wx.showToast({
          title: '请选择场地',
          icon: 'loading'
        })
        return
      } 
    }
  },
  //
  stencilUpdate: function (_this, tant, spec_id){
    wx.request({
      url: util.prefixUrl() +'supp/venue/stencilUpdate',
      method: "POST",
      data: {
        week: _this.navList[_this.activeIndex].week,
        day: _this.navList[_this.activeIndex].year,
        venue_id: _this.venue_id,
        spec_id:spec_id,
        userKey: util.get('user').userKey,
      },
      success: (res) => {
        if(!res.data.stencilaar){
          util.iconnone('无信息')
          return
        }
        _this.para_list = [];
        _this.hour = [];
        _this.stencil_id = res.data.stencil_id
        res.data.stencilaar.map((value, index) => {
          var initif = ""
          for (let key in value) {
            initif = key
          }
          initif.length > 8 ? _this.initial = '2' : _this.initial = '1';
          if (_this.initial == '2') {
            tant.setData({
              spot: false,
              paragraph: true
            })
            for (let key in value) {
              _this.para_list.push(value[key])
              _this.para_list[index].date = key;
              _this.para_list[index].tap = false;
            }
          } else {
            tant.setData({
              spot: true,
              paragraph: false
            })
            for (let key in value) {
              _this.hour.push(value[key])
              _this.hour[index].date = key;
              _this.hour[index].tap = false;
            }
          }
        })
        _this.hour.map((value) => {
          value['tap'] = false
        })
        tant.setData({
          para_list: _this.para_list,
          hour: _this.hour
        })
      }
    })
  }
})