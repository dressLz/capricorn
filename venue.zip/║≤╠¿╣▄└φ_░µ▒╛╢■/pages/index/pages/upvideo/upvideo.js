var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    autoplay:true,
    venue_id:0,
    coach_id:0,
    imgUrl: '',
    videoArry: [{ 'video_url': '' }],
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      coach_id: options.coach_id,
      venue_id: options.venue_id,
      imgUrl: util.imgUrl()
    })
  },
  coachVideo:function(e){
    wx.navigateTo({
      url: '../coachvideo/coachvideo?video_id=' + e.currentTarget.dataset.video + "&coach_id=" + this.data.coach_id + '&venue_id=' + this.data.venue_id,
    })
  },
  //返回教练列表页
  upresverque:function(){
    wx.navigateBack({ delta:1})
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    wx.request({
      url: util.prefixUrl() +'supp/video/list',
      method:'POST',
      data:{
        coach_id: _this.coach_id,
        userKey:util.get('user').userKey,
        page_index:1,
        page_size:50
      },
      success:(res)=>{
        _this.videoArry=[]
        if (!res.data.code){
          _this.videoArry = res.data.data
          _this.videoArry.push({ 'video_url': '' })
          this.setData({
            videoArry: res.data.data
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },
  //关闭视频
  closevideo:function(e){
    wx.showLoading({
      title:'删除中...',
      mask:true,
    })
    wx.request({
      url: util.prefixUrl() +'supp/video/delete',
      method:'POST',
      data:{
        video_id: e.currentTarget.dataset.id,
        userKey:util.get('user').userKey
      },
      success:(res)=>{
        if(res.data.code==0){
          this.data.videoArry.splice(e.currentTarget.dataset.index, 1)
          this.setData({
            videoArry: this.data.videoArry
          })
        }
      },
      complete:(res)=>{
        wx.hideLoading({})
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})