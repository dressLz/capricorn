var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    user:{},
    state: false,
    add_model:true,
    displays:false,
    venue_id:'',
    coachList:[],
    is_order:0,
    paragraph:['','','','','','','',''],
    dataday:[],
    available:[],
    coach_ava:[],
  },
  //更新
  coachLists:function(id){
    var _this=this.data,indexs;
    _this.coachList.map((value,index)=>{
      if (value.coach_id == id){
         indexs=index
      }
    });
     _this.coachList.splice(indexs, 1);
      this.setData({
        coachList: _this.coachList
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options){
    this.data.venue_id=options.venue_id
    this.setData({
      venue_id: this.data.venue_id,
      user:util.get('user'),
      imgUrl: util.imgUrl(),
      is_order: options.is_order
    })
  },
  //跳转课程预览页面
  catreserve:function(e){
    var index=e.currentTarget.dataset.index,
        coach_id = e.currentTarget.dataset.coach,
        _this=this.data;
        wx.navigateTo({
          url: '../../../coach/pages/reserve/reserve?coach_id=' +coach_id+'&venue_id='+_this.venue_id+'&index='+index
        })
  },
  /*跳转添加教练*/
  addcoach:function(){
     wx.navigateTo({
       url: '../register/register?venue_id=' + this.data.venue_id +'&creator='+true+'&is_one='+true,
     })
  },
  coachinfo:function(e){
    wx.navigateTo({
      url: '../register/register?venue_id=' + this.data.venue_id + '&coach_id=' + e.currentTarget.dataset.id,
    })
  },
  //查看7天
  schedulejump:function(e){
    var _this=this.data,
       index = e.currentTarget.dataset.index,
      id = e.currentTarget.dataset.id ;
      wx.navigateTo({
        url: '../../../coach/pages/schedule/schedule?coach_id=' +id + '&venue_id=' + _this.venue_id + '&name=' + _this.coachList[index].coach_name,
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.navtap = this.selectComponent("#navtap")
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    wx.getStorageSync('whether') == '1' ? this.setData({ state: true }) : this.setData({ state: false })
    if (_this.user.sub_type=='4'){
      this.setData({ state: false })
    }
    wx.request({
      url: util.prefixUrl() +'supp/coach/list',
      method:'POST',
      data:{
        venue_id: _this.venue_id,
        shop_id: util.get('user').shop_id,
        userKey: util.get('user').userKey
      },
      success:(res)=>{
        var is_available=false,
            index_available=0;
        this.setData({
          displays:true
        })
        if(res.data.code==1){
           this.setData({
              add_model:true,
           })
        }else{
          _this.dataday=[];
          _this.available=[];
          _this.coach_ava=[];
            res.data.data.map((values, indexs) => {
              if (values.day0) { 
                is_available=true;
                index_available=indexs;
              }
              values.coach_ava = [[], [], []];
              if (values.day0) {
                values.day0.map((value, index) => {
                  var key = Object.keys(value)[0];
                  values.coach_ava[0].push(value[key]);
                })
                values.day1.map((value, index) => {
                  var key = Object.keys(value)[0];
                  values.coach_ava[1].push(value[key]);
                })
                values.day2.map((value, index) => {
                  var key = Object.keys(value)[0];
                  values.coach_ava[2].push(value[key]);
                })
              }
            })
          var available = [];
           _this.available=[];
          if (is_available){
            res.data.data[index_available].day0.map((value, index) => {
                if (Object.keys(value)[0].substring(3, 5)!='30'){
                  available.push(Object.keys(value)[0].substring(0, 2))
                }
              })
            if (available.length >= 10) {
              _this.available.push(available[0])
              available.map((value, index) => {
                if (index % 2 == 0 && (index != 0 && index != available.length-1) ){
                  _this.available.push(value)
                }
              })
              _this.available.push(available[available.length-1])
            }else{
              _this.available = available
            }
          }
          this.setData({
            add_model: false,
            coachList: res.data.data,
            available: _this.available
          })
          }
        }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})