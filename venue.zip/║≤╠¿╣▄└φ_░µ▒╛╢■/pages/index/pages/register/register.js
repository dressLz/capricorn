var util = require('../../../../utils/util.js')
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    is_one:false,  //是否最新创建的
    goback:true,
    creator:false,
    submit:0,
    urlImg:'',
    imgUrl:'',
    coach_name: '', //教练名称
    coach_info: { open_no: 0, visible_no:0},
    coach_id: 0,
    venue_id: '',
    association: false, //教练联想框
    arraysex: ['女', '男'],
    arrayindex: 0,
    photoindex: 0, //上传图片下标,
    introduce: '', //教练简介
    uploadType: '',
    coach_attr: '', //教练所选标签
    attr: [],
    coach_sum:0,
    name: '',
    // _________________
    imageNum: '', //上传的图片id
    coach_pic: '../../../image/1548386449093679.jpg', //头像上传
    videoArry: [{
      'src': ''
    }],
    ewmImg: '', //二维码上传
    imageFixed: false, //裁剪浮层
    imageSrc: '', //要裁剪的图片
    returnImage: '',
  },
  backindexto: function (event) {
    var _this=this.data;
    // 自定义组件触发事件时提供的detail对象，用来获取子组件传递来的数据
    if (event.detail.index=='0'){
      return;
    }else{
      if (_this.coach_id=='0'){
        util.iconnone('请先创建教练');
        return;
      }
      _this.goback=false;
      wx.redirectTo({
        url: '../../../coach/pages/reserve/reserve?coach_id=' + _this.coach_id+"&venue_id="+_this.venue_id,
      })
    }
  },
  formSubmit: function(e) {
    wx.showLoading({
      title: '',
      mask:true,
    })
    var data = e.detail.value
    data.userKey = util.get('user').userKey
    data.shop_id = util.get('user').shop_id
    data.venue_id = this.data.venue_id
    data.operator_id = util.get('user').supplier_id
    data.coach_id = this.data.coach_id
    data.is_visible=3
    if (data.coach_name.replace(/\s*/g, "").length == 0) {
      util.iconnone('请填写教练姓名')
      return
    } else if (this.data.coach_sum==0){
      util.iconnone('请填选择教练标签')
      return
    } else if (!this.data.coach_info.description.length>0){
      util.iconnone('请填简介')
      return
    } else if (this.data.coach_pic.length==0){
      util.iconnone('请上传教练头像')
      return
    }
    this.data.submit=1;
    var url = "";
    if (this.data.coach_info.is_visible_a == '1') {
      url = 'supp/coach/updateCoach'
    } else {
      url = 'supp/coach/add';
    }
    wx.request({
      url: util.prefixUrl() +url,
      method: 'POST',
      data: data,
      success: (res) => {
        wx.navigateBack({
        })
      },complete:()=>{
        wx.hideLoading()
      }
    })
  },
  //开设课程
  curriculum: function() {
    var _this=this.data;
    if(this.data.coach_id==0){
      util.iconnone('请先填写基本资料');
      return;
    }
    wx.navigateTo({
      url: '../../../coach/pages/curtime/curtime?coach_id=' + _this.coach_id + '&venue_id=' + _this.venue_id,
    })
  },
  //视频
  cantchvideo:function(){
    if(this.data.coach_id==0){
      util.iconnone('请按顺序填写资料')
      return;
    }
    wx.navigateTo({
      url: '../upvideo/upvideo?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
    })
  },
  //性别选择
  bindPickerarray: function(e) {
    this.setData({
      arrayindex: e.detail.value
    })
  },
  //删除教练
  delcantap:function(){
    var _this=this.data;
    var data={
      coach_id: this.data.coach_id,
      userKey: util.get('user').userKey,
    }
    wx.showModal({
      title: '删除教练',
      content: '是否确认删除教练',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定');
          util.requestGroups('/supp/coach/delete', data).then((res)=>{
            util.iconnone('删除成功');
            _this.goback = false;
            wx,wx.navigateBack({
              delta: 1,
            })
          })
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    })
  },
  //擅长领域
  begoodatTap: function() {
    var _this = this.data;
    if (_this.coach_name.length == 0) {
      util.iconnone('请先填写教练名称')
      return;
    }
    var data = {
      coach_id: _this.coach_id,
      coach_name: _this.coach_name,
      venue_id: _this.venue_id,
      coach_sex: _this.arrayindex,
      coach_pic:_this.coach_pic
    };
    wx.navigateTo({
      url: '../begoodat/begoodat?data=' + JSON.stringify(data) + '&coach_pic=' + _this.coach_pic
    })
  },
  // 监听输入
  watchPassWord: function(event) {
    this.data.coach_name = event.detail.value
  },
  // 删除视频
  delectVideo: function(e) {
    this.setData({
      videoArry: this.data.videoArry.splice([e.currentTarget.dataset.index - 1], 1)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this=this.data
    this.setData({
      imgUrl: util.imgUrl(),
    })
    options.is_one ? _this.is_one = true : _this.is_one = false;
    if (options.coach_id) {
      _this.coach_id = options.coach_id
    }
    if (options.creator) {
      _this.creator = options.creator
      this.setData({
        creator: _this.creator
      })
    }
    _this.venue_id = options.venue_id
    if (_this.coach_id != 0) {
      this.setData({
        coach_id: _this.coach_id
      })
      wx.request({
        url: util.prefixUrl() +'supp/coach/info',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          coach_id: _this.coach_id
        },
        success: (res) => {
          if (res.data.coach_pic.length>0){
            this.setData({
              coach_pic: res.data.coach_pic,
            })
          }
          this.setData({
            coach_info: res.data,
            arrayindex: res.data.coach_sex,
            coach_name: res.data.coach_name,
          })
          _this.coach_attr = ''
          _this.attr = res.data.coach_attr
          res.data.coach_attr.map((value, index) => {
            if (value.checked == 1) {
              _this.coach_attr += value.attr_id + ','
            }
          })
          this.coachAttr(this)
          this.setData({
            coach_attr: _this.coach_attr,
            coach_sum: _this.coach_attr.split(',').length - 1
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data, tant = this;
    if (_this.urlImg.length > 0) {
      this.ossrequest(tant, _this.urlImg)
      this.setData({
        urlImg:''
      })
    }
    if (_this.coach_id != 0) {
      this.setData({
        coach_id: _this.coach_id
      })
      wx.request({
        url: util.prefixUrl() +'supp/coach/info',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          coach_id: _this.coach_id
        },
        success: (res) => {
          this.setData({
            coach_info: res.data,
            coach_name: res.data.coach_name,
          })
          _this.coach_attr = ''
          _this.attr = res.data.coach_attr
          res.data.coach_attr.map((value, index) => {
            if (value.checked == 1) {
              _this.coach_attr += value.attr_id + ','
            }
          })
          this.coachAttr(this)
          this.setData({
            coach_attr: _this.coach_attr,
            coach_sum: this.data.coach_attr.split(',').length - 1
          })
        }
      })
    }
    this.coachAttr(this)
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  //跳转简介
  coachbrief: function(e) {
    var _this = this.data;
    if (_this.coach_name.length == 0) {
      util.iconnone('请先填写教练名称')
      return;
    }
    var data = {
      coach_id: _this.coach_id,
      coach_name: _this.coach_name,
      venue_id: _this.venue_id,
      coach_sex: _this.arrayindex
    };
    wx.navigateTo({
      url: '../coachbrief/coachbrief?data=' + JSON.stringify(data)
    })
  },
  ossrequest: function(_this, photo) {
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    wx.showLoading({
      title: '上传中...',
      mask: true,
    })
    wx.request({
      url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey
      },
      success: (res) => {
        var myDate = new Date()
        //  随机生成文件名称
        if (_this.data.uploadType == 'photo') {
          var pathArr = _this.data.coach_pic.split('.')
          var picname = Date.now() + "" + parseInt(Math.random() * 1000)
          var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + _this.data.venue_id + '/' + picname
          var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
          var pic_name = picname + '.' + pathArr[pathArr.length - 1]
          console.log(pathArr)
        } else if (_this.data.uploadType == 'video') {
          var pathArr = _this.data.videoPic.split('.')
          var picname = Date.now() + "" + parseInt(Math.random() * 1000)
          var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + _this.data.venue_id + '/' + picname
          var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
          var pic_name = picname + '.' + pathArr[pathArr.length - 1]
        }
        // 要提交的key
        var fileKey = fileName
        var url = res.data.host
        wx.uploadFile({
          url: url,
          filePath: photo,
          name: 'file',
          formData: {
            name: photo,
            key: fileKey,
            policy: res.data.policy,
            OSSAccessKeyId: res.data.accessid,
            signature: res.data.signature,
            success_action_status: "200"
          },
          success: (res) => {
            if (_this.data.uploadType == 'photo') {
              _this.data.coach_pic = url + '/' + fileKey
              _this.setData({
                coach_pic: _this.data.coach_pic
              })
              wx.request({
                url: util.prefixUrl() +'supp/venue/setAlbum',
                method: 'POST',
                data: {
                  userKey: util.get('user').userKey,
                  pic_cover: _this.data.coach_pic,
                  pic_name: pic_name,
                  pic_size: '320,320'
                },
                success: (res) => {
                  wx.request({
                    url: util.prefixUrl() + 'supp/coach/add',
                    method: 'POST',
                    data: {
                      coach_pic: _this.data.coach_pic,
                      userKey : util.get('user').userKey,
                      shop_id : util.get('user').shop_id,
                      venue_id: _this.data.venue_id,
                      operator_id :util.get('user').supplier_id,
                      coach_id: _this.data.coach_id
                    },
                    success: (res) => {
                      if(res.data.code==1){
                        util.iconnone('网络故障,请重新上传')
                      }
                    }
                  })
                }
              })
            } else if (_this.data.uploadType == 'video') {
              _this.setData({
                videoPic: url + '/' + fileKey
              })
            }
            wx.hideLoading()
          },
          fail: (res) => {
            util.failtips('网络故障')
          }
        })
      }
    })
  },
  //教练视频
  coachVideo: function() {
    wx.navigateTo({
      url: '../coachvideo/coachvideo',
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    wx.removeStorageSync('coach_attr');
    if (this.data.submit==0){
    var _this=this.data,
      data = {
      coach_id: this.data.coach_id,
      userKey: util.get('user').userKey,
    };
      if (_this.coach_id != 0 && _this.coach_info.is_visible != '1' && _this.goback && _this.is_one){
      wx.showModal({
        title: '保存',
        content: '是否保存教练',
        success(res) {
          var pages = getCurrentPages(); // 获取页面栈
          if (res.confirm) {
            //pages/index/pages/coach/coach
            console.log(pages[pages.length - 1].route)
          } else if (res.cancel) {
            util.requestGroups('/supp/coach/delete', data).then((res) => {
              // util.iconnone('删除成功');
              if (pages.length > 1) {
                //上一个页面实例对象
                if (pages[pages.length - 1].route =='pages/index/pages/coach/coach'){
                  var prePage = pages[pages.length - 1];
                }else{
                  var prePage = pages[pages.length - 2];
                }
                //关键在这里  changeData为上一页的方法
                prePage.coachLists(_this.coach_id)
              }
            })
          }
        }
      })
    }
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  /**关闭联想**/
  assTap: function() {
    this.setData({
      association: false
    })
  },
  //回调
  coachAttr: function(tant) {
  },
  bindChooseType(e) {//选择相机还是相册
    var demo = this, _this = this.data;
    if (_this.coach_id == 0) {
      util.iconnone('请按顺序填写')
      return
    }
    _this.uploadType = e.currentTarget.dataset.type;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['camera', 'album'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilesSize = res.tempFiles[0].size
        if (tempFilesSize > 5000000) {
          wx.showToast({
            title: '上传图片不能大于5M!',  //标题
            icon: 'none'       //图标 none不使用图标，详情看官方文档
          })
          return;
        }
        var tempFilePaths = res.tempFilePaths;
        var imgs = app.globalData.imgs;
        var data = {
          width: 375,
          height: 375,
        }
        wx.navigateTo({
          url: "../../../cropper/upload?src=" + tempFilePaths + '&data=' + JSON.stringify(data)
        });
      }
    });
  },
})