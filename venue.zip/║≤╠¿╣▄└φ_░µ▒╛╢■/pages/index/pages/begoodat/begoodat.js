var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    coach_id: 0,
    coach_name: '',
    coach_sex: 0,
    venue_id: 0,
    attr: [],
    attrList: [],
    coach_attr: '',
    coach_pic:'',
    coach_info:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
    var pagevalue = JSON.parse(options.data)
    var _this = this.data
    _this.venue_id = pagevalue.venue_id
    _this.coach_id = pagevalue.coach_id
    _this.coach_name = pagevalue.coach_name
    _this.coach_sex = pagevalue.coach_sex
    _this.coach_pic = pagevalue.coach_pic
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  //报存
  briefrequst: function() {
    var _this = this.data;
    _this.coach_attr = '';
    _this.attrList.map((value, index) => {
      if (value.checked) {
        _this.coach_attr += value.attr_id + ','
      }
    })
    if (_this.coach_attr.length == 0) {
      util.iconnone('请选择标签')
      return;
    }
    var url = "";
    if (_this.coach_info.is_visible == '1') {
      url = 'supp/coach/updateCoach'
    } else {
      url = 'supp/coach/add';
    }
    var data = {
      userKey: util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_id: _this.venue_id,
      operator_id: util.get('user').supplier_id,
      coach_id: _this.coach_id,
      coach_name: _this.coach_name,
      coach_sex: _this.coach_sex,
      coach_attr: _this.coach_attr,
      coach_pic: _this.coach_pic,
      is_visible:0
    }
    if(_this.coach_id==0){
      data.is_visible=0
    }
    wx.request({
      url: util.prefixUrl() + url,
      method: 'POST',
      data: data,
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        } else {
          util.iconnone('保存成功')
          setTimeout(() => {
            let pages = getCurrentPages();
            let prevPage = pages[pages.length - 2];
            prevPage.setData({
              coach_id: res.data.coach_id,
            })
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data
    if (this.data.attr.length > 0) {
      this.data.attrList = this.data.attr
      this.data.attrList.map((value, index) => {
        if (value.checked == 1) {
          value.check = true
        } else {
          value.check = false
        }
      })
      this.setData({
        attrList: this.data.attrList
      })
      return;
    }
   if(_this.coach_id!=0){
     wx.request({
       url: util.prefixUrl() +'supp/coach/info',
       method: 'POST',
       data: {
         userKey: util.get('user').userKey,
         coach_id: _this.coach_id
       },
       success: (res) => {
        _this.coach_info=res.data;
         _this.coach_attr = ''
         _this.attrList = res.data.coach_attr
         res.data.coach_attr.map((value, index) => {
           if (value.checked == 1) {
             _this.coach_attr += value.attr_id + ','
           }
         })
         this.setData({
           attrList: _this.attrList,
           coach_attr: _this.coach_attr,
         })
       }
     })
   } else {
     wx.request({
       url: util.prefixUrl() +'supp/coach/attrList',
       method: 'POST',
       data: {
         userKey: util.get('user').userKey
       },
       success: (res) => {
         _this.coach_attr = '';
         _this.attrList = res.data.data
         this.setData({
           attrList: _this.attrList,
         })
       }
     })
    }
  },
  begoodatcheck: function(e) {
    var attr = 0,
        _this=this.data,
        index=e.currentTarget.dataset.index;
    if (_this.attrList[index].checked){
        _this.attrList[index].checked=false;
      this.setData({
        attrList: _this.attrList
      })
      return;
    }
    _this.attrList.map((value, index) => {
      if (value.checked) {
        attr++
      }
    })
    if (attr >= 6) {
       util.iconnone('最多选择6个标签')
       return;
    }
    _this.attrList.map((value, index) => {
      if (index == e.currentTarget.dataset.index) {
        value.checked = !value.checked
      }
    })
    this.setData({
      attrList: this.data.attrList
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    this.data.coach_attr
    this.data.attrList.map((value, index) => {
      if (value.check) {
        this.data.coach_attr += value.attr_id + ','
      }
    })
    wx.setStorageSync("coach_attr", this.data.coach_attr)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
})