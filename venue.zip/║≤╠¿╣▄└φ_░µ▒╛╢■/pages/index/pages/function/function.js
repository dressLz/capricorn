Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:0,
    obj: { 
      '1': { 'title': '运营管理功能', 'content':'所属场馆用户入场订单核验'},
      '4': { 'title': '教练管理功能', 'content': '所属场馆教练信息管理，私教订单确认和私教订单核验；此账号一旦建立该场馆内的教练预定通知将发送至该账号手机。' },
      '3': { 'title': '核验功能', 'content': '所属场馆基本信息维护，教练信息管理，核验管理；账号一旦建立该场馆内的一切预定确认通知将发送至该账号手机。' }
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id: options.id
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})