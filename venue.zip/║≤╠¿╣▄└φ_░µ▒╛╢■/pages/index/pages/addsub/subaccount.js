var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    accountObj:{},
    account:false,
    switchBtn:true,
    venue_id:'',
    supplier_id:0,
    is_add:false,
    username:'',
    account_focus:false,
    sub_type_obj:{},
    sub_type:0,
    sub_type_name:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this.data;
      // type = JSON.parse(options.type)
    if (options.type){
      var type = JSON.parse(options.type)
      this.setData({
        sub_type_obj: type,
        sub_type: type.sub_type_id,
        sub_type_name: type.sub_type_name
      })
    }
    _this.venue_id=options.venue_id
    if (options.supplier_id){
      this.setData({
        supplier_id: options.supplier_id
      })
      this.setData({ is_add:false})
    }else{
      this.setData({ is_add: true, account_focus:true})
    }
  },
  // changeData: function (type) {
  //   this.setData({
  //     sub_type_obj: type,
  //     sub_type: type.sub_type_id,
  //     sub_type_name: type.sub_type_name
  //   })
  // },
  //名称检索
  bindnameinput:function(e){
   this.data.username=e.detail.value
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  navJurisdiction:function(){
    var _this=this.data,url="";
    if (_this.sub_type==0){
      url='../jurisdiction/jurisdiction?venue_id=' + this.data.venue_id;
    }else{
      url='../jurisdiction/jurisdiction?venue_id=' + this.data.venue_id + '&sub_type=' + _this.sub_type;
    }
   wx.navigateTo({
     url: url,
   })
 },
  wxswitchinput:function(e){
    if (e.detail.value){
      this.data.accountObj.is_use='1'
    }else{
      this.data.accountObj.is_use= '0'
    }
    this.setData({
      switchBtn: e.detail.value
    })
  },
  formSubmit:function(e){
    var data = e.detail.value, submission=true;
    data.shop_id = util.get('user').shop_id
    data.venue_id = this.data.venue_id
    data.operator_id = util.get('user').supplier_id
    data.supplier_id = this.data.supplier_id
    data.userKey=util.get('user').userKey;
    data.sub_type = this.data.sub_type
    if (this.data.switchBtn){
      data.is_use='1'
    }else{
      data.is_use = '0'
    }
    for (var i in data) {
      if (data[i].toString().length == 0 || data.sub_type=='0') {
        util.iconnone('请完善信息')
        submission = false
      }
    }
    if (!util.checkaccount(data.username)) {
      util.iconnone('账号名称格式有误')
      return;
    }
    if (data.password.length != 0) {
      if (!util.password(data.password)) {
        util.iconnone('密码长度大于8小于16')
        submission = false;
        return;
      }
    }
    if (submission && util.getcache(util, '../../login/login')) {
      if (this.data.supplier_id==0){     
        wx.showLoading({ mask: true })
        wx.request({
          url: util.prefixUrl() +'supp/supplier/check',
          method: 'POST',
          data: {
            username: this.data.username,
            userKey: util.get('user').userKey
          },
          success: (res) => {
            if (res.data.code == '1') {
              wx.showToast({
                title: '账号已占用',
                image: '../../../image/error.png',
                duration: 1000,
                mask: true,
                success: () => { },
                complete: () => {
                  this.setData({
                    account_focus: true
                  })
                }
              })
            }
            if (res.data.code == '0'){
                wx.request({
                  url: util.prefixUrl() +'supp/venue/addSubSupplier',
                  method: 'POST',
                  data: data,
                  success: (res) => {
                    if (res.data.code == 0) {
                      wx.navigateBack()
                    } else if (res.data.code == 1) {
                      util.iconnone(res.data.msg);
                      return;
                    }
                  }
                })
            }
          },complete:()=>{
            wx.hideLoading()
          }
        })
      }else{
        wx.showLoading({ mask: true })
        wx.request({
          url: util.prefixUrl() +'supp/venue/addSubSupplier',
          method: 'POST',
          data: data,
          success: (res) => {
            if (res.data.code == 0) {
              wx.navigateBack()
            }
          },
          complete: () => {
            wx.hideLoading({})
          }
        })
      }
    }  
    if(!this.data.is_add){
      data.supplier_id = this.data.supplier_id
    }
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(!this.data.is_add){
    wx.request({
      url: util.prefixUrl() +'supp/venue/subSupplierinfo',
      method:'POST',
      data:{
        supplier_id: this.data.supplier_id,
        userKey:util.get('user').userKey
      },
      success:(res)=>{
        if (res.data.is_use==1){
          this.data.switchBtn=true
        }else{
          this.data.switchBtn =false
        }
        this.setData({
          accountObj: res.data,
          switchBtn: this.data.switchBtn,
          sub_type_name: res.data.sub_type_name,
          sub_type: res.data.sub_type
        })
      }
    })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})