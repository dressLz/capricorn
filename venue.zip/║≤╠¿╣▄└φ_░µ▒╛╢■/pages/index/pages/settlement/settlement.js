var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    finance_info:{},
    imgUrl: '',
    bankList: [],
    bankList_handle: [],
    natureIndex: 0,  //选择的银行id
    alipay: true,
    withdraw_type:1,
    venue_id:0,
  },
  // bindPickernature: function (e) {
  //   this.setData({
  //     natureIndex: e.detail.value
  //   })
  //   this.data.bankList_handle.map((value, index) => {
  //     if (index == this.data.natureIndex) {
  //       this.setData({
  //         bank_id: value.bank_id
  //       })
  //     }
  //   })
  // },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this.data;
    _this.venue_id = options.venue_id
    this.setData({
      imgUrl: util.imgUrl(),
    })
    var data = {
      finance_card_bank: '1',
      userKey: util.get('user').userKey
    }
    // util.requestGroup(util.prefixUrl() + 'supp/venue/bankList', data).then(
    //   (res) => {
    //     _this.bankList_handle = res.data;
    //     _this.bankList = [''];
    //     _this.bankList_handle.map((value, index) => {
    //       _this.bankList.push(value.bank_name)
    //     })
    //     this.setData({
    //       bankList: _this.bankList,
    //       bankList_handle:_this.bankList_handle
    //     })
    //   }
    // )
  },
  formSubmit: function (e) {
    var data = e.detail.value,_this=this.data;
    data.userKey = util.get('user').userKey
    data.shop_id = util.get('user').shop_id
    data.venue_id = _this.venue_id
    data.operator_id = util.get('user').supplier_id
    data.withdraw_type = _this.withdraw_type
    wx.request({
      url: util.prefixUrl() + 'supp/venue/modify',
      method: 'POST',
      data: data,
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        }
        if (res.data.code == 0) {
          util.iconnone('操作成功');
          setTimeout(() => {
            wx.navigateBack({})
          }, 1000)
        }
      },
      complete: () => {
        wx.hideLoading({})
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  //切换结算方式
  setmode:function(e){
    var index = e.currentTarget.dataset.index,_this=this.data;
    _this.withdraw_type=index;
    index == 1 ? this.setData({ alipay: true }) : this.setData({ alipay: false })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() + 'supp/venue/finance',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          console.log(res)
          if (res.data.code == -1){
            util.invalidNew(util, '../../../login/login')
            return;
          }
          if (res.data.withdraw_type == 2){
            this.setData({
              alipay:false
            })
          }else{
            this.setData({
              alipay: true
            })
          }
          if (res.data.withdraw_type!=0){
           _this.withdraw_type=res.data.withdraw_type
          }
          this.setData({
            finance_info: res.data,
            withdraw_type: _this.withdraw_type
          })
          // _this.bankList_handle.map((value, index)=>{
          //   if (res.data.bank_oper == value.bank_id){
          //     this.setData({
          //       natureIndex: index+1
          //     })
          //   }
          // })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})