var util = require('../../../../utils/util.js');
var preservation=true;
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    urlImg: '',  //接受裁剪过的图片
    imgUrl:'',
    venue_id:0,
    photoindex:0, //上传图片下标,
    uploadType:'',
    name: '',
    img_list:[], //场馆图片
    // _________________
    imageNum: '', //上传的图片id
    headImg: [''], //头像上传
    headImg_id:'', //上传过的头像id
    videoPic:'', //视频封面
    videoSrc: '', //视频路径
    ewmImg: '', //二维码上传
    imageFixed: false, //裁剪浮层
    imageSrc: '', //要裁剪的图片
    returnImage: '',
    venue_info:{}
  },
  // 图片上传
  upresverque: function () {
    var _this=this.data;
    if (util.getcache(util, '../../../login/login')) {
      if (_this.videoPic.length!=0){
        if (_this.videoSrc.length==0){
             util.iconnone('请上传视频')
             return;
          }
        }
        if (_this.videoSrc.length != 0) {
          if (_this.videoPic.length == 0) {
           util.iconnone('请上传视频封面');
           return;
         }
        }
        var data ={};
        data.venue_id = _this.venue_id
        data.shop_id = util.get('user').shop_id
        data.operator_id = util.get('user').supplier_id
        data.userKey = util.get("user").userKey
        data.video_url = _this.videoSrc
        data.video_img_url = _this.videoPic
        data.venue_pic = _this.headImg_id.split(",")[0]
        data.img_id_arr = _this.headImg_id;
        data.is_order=0;
        var url="";
        if (this.data.venue_info.is_order_a == '1') {
          url = "supp/venue/updateVenue";
        } else {
          url = 'supp/venue/modify';
        }
        wx.request({
          url: util.prefixUrl() +url,
          method: 'POST',
          data: data,
          success: (res) =>{
            if (res.data.code == -1) {
              util.invalidNew(util, '../../../login/login')
              return;
            }
            if (res.data.code == 0) {
              util.iconnone('保存成功')
              preservation=false;
              wx.navigateBack({})
            }
          }
        })
      }
  },
  presupload: function (_this, util) {
    if (util.getcache(util, '../../../login/login')) {
      var data = {};
      data.venue_id = _this.venue_id
      data.shop_id = util.get('user').shop_id
      data.operator_id = util.get('user').supplier_id
      data.userKey = util.get("user").userKey
      data.video_url = _this.videoSrc
      data.video_img_url = _this.videoPic
      data.venue_pic = _this.headImg_id.split(",")[0]
      data.img_id_arr = _this.headImg_id;
      data.is_order = 0;
      var url = "";
      if (this.data.venue_info.is_order_a == '1') {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      wx.request({
        url: util.prefixUrl() + url,
        method: 'POST',
        data: data,
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          if (res.data.code == 0) {
            util.iconnone('保存成功')
          }
        }
      })
    }
  },
  venuePhotoclose:function(e){
    var _this=this.data;
    if (util.getcache(util,'../../../login/login')){
      wx.request({
        url: util.prefixUrl() +'supp/venue/reAlbum',
        method:'POST',
        data:{
          pic_id: e.currentTarget.dataset.id,
          userKey:util.get('user').userKey
        },
        success:(res)=>{
          if (res.data==1){
            util.iconnone('删除成功')
            _this.headImg.splice(e.currentTarget.dataset.index, 1);
            _this.headImg_id=_this.headImg_id.replace(e.currentTarget.dataset.id + ',', "")
            this.setData({
              headImg: this.data.headImg
            })
            if (util.getcache(util, '../../../login/login')) {
              var data = {};
              data.venue_id = _this.venue_id
              data.shop_id = util.get('user').shop_id
              data.operator_id = util.get('user').supplier_id
              data.userKey = util.get("user").userKey
              data.video_url = _this.videoSrc
              data.video_img_url = _this.videoPic
              data.venue_pic = _this.headImg_id.split(",")[0]
              data.img_id_arr = _this.headImg_id
              data.is_order = 0;
              var url = "";
              if (_this.venue_info.is_order_a == '1') {
                url = "supp/venue/updateVenue";
              } else {
                url = 'supp/venue/modify';
              }
              wx.request({
                url: util.prefixUrl() +url,
                method: 'POST',
                data: data,
                success: (res) => {
                  if (res.data.code == -1) {
                    util.invalidNew(util, '../../../login/login')
                    return;
                  }
                  if (res.data.code == 0) {
                    util.iconnone('删除成功')
                  }
                }
              })
            }
          }
        }
      })
    }
  },
  //视频上传
  chooseVideo: function (e) {
    var that = this.data, thisa=this;
    that.photoindex=e.currentTarget.dataset.index
    wx.chooseVideo({
      success:(res)=> {
       that.videoSrc= res.tempFilePath
        if (res.duration > 90) {
          util.iconnone('时长最大1分30秒')
          return;
        }
        wx.showLoading({
          title:'上传中....',
          mask: true,
        })
        wx.request({
          url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
          method: 'POST',
          data: {
            userKey: util.get('user').userKey
          },
          success: (res) => {
            var myDate = new Date()
            //  随机生成文件名称
            var pathArr = that.videoSrc.split('.')
            var picname = Date.now() + "" + parseInt(Math.random() * 1000)
            var fileRandName = 'upload/venue_video/' + util.get('user').shop_id + '/' + that.venue_id + '/' + picname
            var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
            var pic_name = picname + '.' + pathArr[pathArr.length - 1]
            // 要提交的key
            var fileKey = fileName
            var url = res.data.host
            wx.uploadFile({
              url: url,
              filePath: that.videoSrc,
              name: 'file',
              formData: {
                name: that.videoSrc,
                key: fileKey,
                policy: res.data.policy,
                OSSAccessKeyId: res.data.accessid,
                signature: res.data.signature,
                success_action_status: "200"
              },
              success: (res) => {
                var str = fileKey
                  wx.request({
                    url: 'https://fitness.fengdutiyu.com/supp/base/transVideo',
                    method: 'POST',
                    data: {
                      userKey: util.get('user').userKey,
                      object: str
                    },
                    success: (res) => {
                      wx.hideLoading()
                      thisa.setData({
                        videoSrc: url + '/' + str.substring(0, str.lastIndexOf('.') + 1) + 'mp4'
                      })
                    }
                  })
              }, fail: (res) => {
                util.failtips('网络故障')
              }
            })
          }
        })
      }
    })
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
    options.venue_id.length > 0 ? this.setData({ venue_id: options.venue_id }):'';   
    var _this = this.data;
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/venue/videoImgList',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          _this.venue_info=res.data
          if (res.data.img_list) {
            _this.headImg = [];
            res.data.img_list.map((value, index) => {
              _this.headImg.push(value.pic_cover)
            })
            _this.headImg.push('')
            _this.headImg_id = res.data.img_id_arr + ','
           }
           if (res.data.img_list){
             res.data.img_list=_this.img_list;
           }
            this.setData({
              headImg: _this.headImg,
              img_list: _this.img_list,
              videoPic: res.data.video_img_url,
              videoSrc: res.data.video_url,
              headImg_id: _this.headImg_id
            })
        }
      })
    } 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data,tant=this;
    if (_this.urlImg.length > 0) {
      console.log(_this.urlImg)
      this.ossrequest(tant, _this.urlImg)
      this.setData({
        urlImg: ''
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // if (preservation){
    //   var _this = this.data;
    //   this.presupload(_this, util)
    // }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function (){

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  ossrequest: function (_this, photo) {
    if (util.get('user')==undefined){
      util.invalidNew(util,'../../../login/login')
      return; 
    }
    wx.showLoading({
      title: '上传中...',
      mask: true,
    })
    wx.request({
      url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey
      },
      success: (res) => {
        var myDate = new Date()
        //  随机生成文件名称
        if (_this.data.uploadType =='photo'){
          var pathArr = photo.split('.')
          var picname = Date.now() + "" + parseInt(Math.random() * 1000)
          var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + _this.data.venue_id + '/' + picname
          var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
          var pic_name = picname + '.' + pathArr[pathArr.length - 1]
        }else if (_this.data.uploadType == 'video') {
          var pathArr = _this.data.videoPic.split('.')
          var picname = Date.now() + "" + parseInt(Math.random() * 1000)
          var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + _this.data.venue_id + '/' + picname
          var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
          var pic_name = picname + '.' + pathArr[pathArr.length-1]
        }
        // 要提交的key
        var fileKey = fileName
        var url = res.data.host
        wx.uploadFile({
          url: url,
          filePath: photo,
          name: 'file',
          formData: {
            name: photo,
            key: fileKey,
            policy: res.data.policy,
            OSSAccessKeyId: res.data.accessid,
            signature: res.data.signature,
            success_action_status: "200"
          },
          success:(res)=> {
            if (_this.data.uploadType == 'photo') {
              _this.data.headImg[_this.data.photoindex] = url + '/' + fileKey
              _this.data.headImg.push('')
              _this.setData({
                headImg: _this.data.headImg
              })
              wx.request({
                url: util.prefixUrl() +'supp/venue/setAlbum',
                method:'POST',
                data:{
                  userKey:util.get('user').userKey,
                  pic_cover: _this.data.headImg[_this.data.photoindex],
                  pic_name: pic_name,
                  pic_size: '220,166'
                },
                success:(res)=>{
                  _this.data.headImg_id += res.data.toString() +','
                }
              })
            } else if (_this.data.uploadType == 'video'){
              _this.setData({
                videoPic: url + '/' + fileKey
              })
            }
            wx.hideLoading()
          }, fail: (res) => {
            util.failtips('网络故障')
          }
        })
      }
    })
  },
  bindChooseType(e) {//选择相机还是相册
    var demo = this, _this = this.data;
    _this.uploadType = e.currentTarget.dataset.type;
    _this.photoindex = e.currentTarget.dataset.index;
    if (_this.uploadType == 'video') {
      var data = {
        width: 375,
        height: 227.625,
      }, proportion=1.645;
    } else {
      var data = {
        width: 375,
        height: 283.125,
      }, proportion =1.3245;
    }
    wx.navigateTo({
      url: '../../../cutFace/index?cuttype=1&proportion=' + proportion,
    });
  },
})