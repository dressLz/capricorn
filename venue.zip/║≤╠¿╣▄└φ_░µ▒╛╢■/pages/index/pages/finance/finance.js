var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    bank_id: 0,
    bankList: [],
    natureIndex: 0,
    bankList_handle: [],
    multiIndex: [],
    finance_info: {},
    withdraw_type:0,
    vehicle: ['有', '无'],
    vehicleIndex: 0,
    multiArray: [
      ['08:00', '09:00'],
      ['08:00', '09:00']
    ], //营业时间
    venue_name: '',
    brand_id: '',
    venue_id: 0,
    venue_info: '',
    disabled: false,
  },
  bindPickernature: function(e) {
    this.setData({
      natureIndex: e.detail.value
    })
    this.data.bankList_handle.map((value, index) => {
      if (index == this.data.natureIndex) {
        this.setData({
          bank_id: value.bank_id
        })
      }
    })
  },
  //结算方式选择
  settlement:function(){
    wx.navigateTo({
      url: '../settlement/settlement?venue_id='+this.data.venue_id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /** 生命周期函数--监听页面加载**/
  onLoad: function(options) {
    var _this = this.data;
    this.setData({
      imgUrl: util.imgUrl(),
    })
    _this.venue_id = options.venue_id;
    if (!util.getcache(util, '../../../login/login')) {
      return;
    }
    wx.request({
      url: util.prefixUrl() +'supp/venue/bankList',
      method: 'POST',
      data: {
        finance_card_bank: '1',
        userKey: util.get('user').userKey
      },
      success: (res) => {
        _this.bankList_handle = res.data;
        _this.bankList = [''];
        _this.bankList_handle.map((value, index) => {
          _this.bankList.push(value.bank_name)
        })
        this.setData({
          bankList: _this.bankList
        })
      }
    })
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() + 'supp/venue/finance',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          // if (res.data.finance_username != 0) {
          //   this.setData({
          //     disabled: true
          //   })
          // }
          _this.bankList_handle.map((value, index) => {
            if (res.data.finance_card_bank == value.bank_id) {
              this.setData({
                natureIndex: index
              })
            }
          })
          this.setData({
            finance_info: res.data,
            withdraw_type: res.data.withdraw_type,
          })
        }
      })
    }
  },
  //营业时间
  bindMultiPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },
  //是否有停车位
  vehiclePickerChange: function(e) {
    this.setData({
      vehicleIndex: e.detail.value
    })
  },
  /**上传图片,视频跳转**/
  bindUpload: function() {
    wx.navigateTo({
      url: '../upload/upload',
    })
  },
  bindCoach: function() {
    wx.navigateTo({
      url: '../coach/coach',
    })
  },
  template: function() {
    wx.navigateTo({
      url: '../template/template',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},
  //
  formSubmit: function(e) {
    var data = e.detail.value,
      _this = this.data,
      submission = true;
    if (data.finance_username!=0){
      if (!util.checkaccount(data.finance_username)) {
        util.iconnone('账号名称格式有误')
        submission = false;
        return;
      } 
    }
    if (data.finance_pass.length != 0) {
      if (!util.password(data.finance_pass)) {
        util.iconnone('密码长度大于8小于16')
        submission = false;
        return;
      }
    }
    for (var i in data) {
      if (data[i].toString().length == 0 || _this.withdraw_type == 0) {
        util.iconnone('请完善信息')
        submission = false
      }
    }
    if (_this.finance_info.finance_username.length == 0){
      util.postRequestLoading({
        username: data.finance_username
      },
        (res) => {
          //res就是返回的数据
          if (submission && util.get('user').userKey) {
            if (res.code == 1) {
              wx.showToast({
                title: '账号已占用',
                image: '../../../image/error.png',
                duration: 1000,
                mask: true,
                success: () => { },
                complete: () => { }
              })
            } else {
              data.userKey = util.get('user').userKey
              data.shop_id = util.get('user').shop_id
              data.venue_id = _this.venue_id
              data.operator_id = util.get('user').supplier_id
              if (!util.getcache(util, '../../../login/login')) {
                return;
              }
              wx.showLoading({
                mask: true
              })
              wx.request({
                url: util.prefixUrl() + 'supp/venue/modify',
                method: 'POST',
                data: data,
                success: (res) => {
                  wx.hideLoading({})
                  if (res.data.code == -1) {
                    util.invalidNew(util, '../../../login/login')
                  }
                  if (res.data.code == 1) {
                    util.iconnone(res.data.msg);
                    return;
                  }
                  if (res.data.code == 0) {
                    util.iconnone('操作成功');
                    setTimeout(() => {
                      wx.navigateBack({})
                    }, 1000)
                  }
                },
                fail:()=>{
                  wx.hideLoading({})
                },
                complete: () => {
                }
              })
            }
          }
        }, (res) => {
          console.log(res)
        })
    }else{
            data.userKey = util.get('user').userKey
            data.shop_id = util.get('user').shop_id
            data.venue_id = _this.venue_id
            data.operator_id = util.get('user').supplier_id
            if (!util.getcache(util, '../../../login/login')) {
              return;
            }
            wx.showLoading({
              mask: true
            })
            wx.request({
              url: util.prefixUrl() + 'supp/venue/modify',
              method: 'POST',
              data: data,
              success: (res) => {
                if (res.data.code == -1) {
                  util.invalidNew(util, '../../../login/login')
                }
                if (res.data.code == 1) {
                  util.iconnone(res.data.msg);
                  return;
                }
                if (res.data.code == 0) {
                  util.iconnone('操作成功');
                  setTimeout(() => {
                    wx.navigateBack({})
                  }, 1000)
                }
              },
              complete: () => {
                wx.hideLoading({})
              }
            })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data;
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() + 'supp/venue/finance',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          this.setData({
            withdraw_type: res.data.withdraw_type,
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})