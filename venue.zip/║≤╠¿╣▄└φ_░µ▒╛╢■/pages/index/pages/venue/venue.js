var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    add:true,
    maytrue:true,
    venue:true,
    imgUrl: '',
    user: {},
    disabled: false,
    venue_info: {},
    is_order: 0,
    state: false,
    venue_submission: '提交保存',
    venue_name: '',
    venue_name_c:'',  //分店名称
    venue_id: 0,
    brand_id: 0,
    multiIndex: [0, 0, 0],
    multiArray: [
      ['08:00', '09:00'],
      ['08:00', '09:00']
    ],
    first_step: true, //第一步
    second_step: false, //第二部
    venueType:['请选择','私教工作室','健身房'],
    venue_type:'',
    typeIndex:0,
    brand: [],
    brandIndex: 0,
    brand_original: []
  },
  //品牌选择
  brandpicker: function(e) {
    this.setData({
      brandIndex: e.detail.value,
      brand_id: this.data.brand_original[e.detail.value - 1].brand_id
    })
  },
  //类型选择
  typepicker:function(e){
    var _this=this.data;
    this.setData({
      typeIndex: e.detail.value,
      venue_type: _this.venueType[e.detail.value],
    })
    _this.venue_info.venue_type = _this.venueType[e.detail.value]
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    this.navtap = this.selectComponent("#navtap")
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
    var _this = this.data;
    this.setData({
      user: util.get('user')
    })
    this.brandrequest();
    [_this.venue_id = 0] = [options.venue_id];
    this.setData({
      venue_id: _this.venue_id
    })
  },
  venuesubname:function(e){
    var _this=this.data;
    _this.venue_name_c = e.detail.value;
    _this.venue_info.venue_name_c = e.detail.value;
  },
  //监听场馆名称
  venueNamechang: function(e) {
    this.data.venue_name = e.detail.value
  },
  //品牌列表请求
  brandrequest: function() {
    var _this = this.data,
      data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id
      };
    if (util.get('user')) {
      util.requestGroups('supp/supplier/brandlist', data).then((res) => {
        if (util.invalid(res.data, util, '../../../login/login')) {
          return
        }
        if (res.data.data) {
          _this.brand_original = res.data.data
          _this.brand = ['请选择']
          res.data.data.map((value, index) => {
            _this.brand.push(value.brand_name)
          })
          this.setData({
            brand: _this.brand,
            brand_id: _this.brand_original[0].brand_id
          })
        }
      }, (res) => {
        util.failtips('网络故障')
      })
    } else {
      wx.reLaunch({
        url: '../../login/login',
      })
    }
  },
  bindsetting() {
    this.navtap.bindsetting()
  },
  //场地管理
  bindsetting: function() {
    wx.navigateTo({
      url: '../reserve/reserve?venue_id=' + this.data.venue_id,
    })
  },
  bindCoach: function() {
    var [isVenueName = true] = [this.isVenueName()];
    if (isVenueName) {
      wx.navigateTo({
        url: '../coach/coach?venue_id=' + this.data.venue_id,
      })
    }
  },
  bindMultiPickerChange: function(e) {
    this.setData({
      multiIndex: e.detail.value
    })
  },
  bindMultiPickerColumnChange: function(e) {},
  //资质证明
  qualifications: function() {
    var [isVenueName = true] = [this.isVenueName()], _this = this.data;
    if (isVenueName) {
      wx.navigateTo({
        url: '../addModify/addModify?venue_id=' + this.data.venue_id,
      })
    }
  },
  //基本信息
  venueData: function() {
    var [isVenueName = true] = [this.isVenueName()], _this = this.data;
    if (isVenueName) {
      wx.navigateTo({
        url: "../venuedata/venuedata?venue_id=" + this.data.venue_id,
      })
    }
  },
  /**上传图片,视频跳转**/
  bindUpload: function() {
    wx.navigateTo({
      url: '../upload/upload',
    })
  },
  //创建子账号
  subaccount: function() {
    var [isVenueName = true] = [this.isVenueName()],
    _this = this.data;
    if (isVenueName) {
      wx.navigateTo({
        url: '../subaccount/subaccount?venue_id=' + this.data.venue_id,
      })
    }
  },
  //基础模板
  bindbasics: function() {
    var [isVenueName = true] = [this.isVenueName()],
    _this = this.data;
    if (_this.venue_info.info_type != '已填写') {
      util.iconnone('请先填写场馆信息')
      return;
    }
    if (isVenueName) {
      wx.navigateTo({
        url: '../basics/basics?venue_id=' + _this.venue_id,
      })
    }
  },
  //财务管理
  financenav: function() {
    var _this = this.data, 
    data={
      userKey: util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_name: _this.venue_name,
      venue_name_c:_this.venue_name_c,
      venue_type:_this.venue_type,
      operator_id: util.get('user').supplier_id,
      brand_id: _this.brand_id,
    };
    if (_this.venue_name.replace(/\s+/g, "").length == 0) {
      util.iconnone('请先填写场馆名称');
    } else if (_this.brandIndex == 0) {
      util.iconnone('请完善场馆名称');
    } else if (_this.typeIndex == 0) {
      util.iconnone('请选择类型');
    } else if (_this.venue_id == 0) {
      if (util.getcache(util, '../../../login/login') && _this.add) {
        _this.add=false;
        util.requestGroups('supp/venue/add', data).then((res) => {
          if (res.data.code == 0) {
            this.setData({
              venue_id: res.data.venue_id
            })
            wx.navigateTo({
              url: '../finance/finance?venue_id=' + _this.venue_id
            })
          }
        })
      }
    } else {
      wx.navigateTo({
        url: '../finance/finance?venue_id=' + _this.venue_id
      })
    }
  },
  //教练管理
  acccoachnav: function() {
    var [isVenueName = true] = [this.isVenueName()];
    if (isVenueName) {
      wx.navigateTo({
        url: '../acccoach/acccoach?venue_id=' + this.data.venue_id
      })
    }
  },
  //运营管理
  operatenav: function() {
    var [isVenueName = true] = [this.isVenueName()];
    if (isVenueName) {
      wx.navigateTo({
        url: '../operate/operate?venue_id=' + this.data.venue_id
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    wx.showLoading({
      title: '拼命加载...',
      mask: true
    })
    var _this = this.data,
      data = {
        userKey: util.get('user').userKey,
        venue_id: _this.venue_id
      };
    //运营管理返回保存成功
    let pages = getCurrentPages();
    let currPage = pages[pages.length - 1];
    wx.getStorageSync('whether') == 1 ? this.setData({
      state: true,
      venue_submission: '提交保存'
    }) : this.setData({
      state: false
    })
    if (_this.venue_id == 0) {
      wx.hideLoading()
      return;
    }
    if (util.getcache(util, '../../../login/login')) {
      util.requestGroups('supp/venue/default_info', data).then((res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
          return;
        }
        _this.venue_info = res.data
        _this.brand_original.map((value, index) => {
          if (value.brand_id == _this.venue_info.brand_id) {
            _this.brandIndex = index + 1;
          }
        })
        if (res.data.venue_type =="健身房"){
          _this.typeIndex=2
        } else if (res.data.venue_type == "私教工作室"){
          _this.typeIndex = 1
        }else{
          _this.typeIndex = 0
        }
        if (res.data.is_order == '3') {
          this.setData({
            disabled: true
          })
        }
        this.setData({
          venue_name: _this.venue_info.venue_name,
          venue_info: _this.venue_info,
          brandIndex: _this.brandIndex,
          is_order: res.data.is_order,
          typeIndex:_this.typeIndex,
          venue_name_c: res.data.venue_name_c,
          venue_type: res.data.venue_type
        })
        wx.hideLoading()
      })
    }else{
      wx.hideLoading()
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
  },
  /*判断是否填写场馆名称*/
  isVenueName: function() {
    var _this = this.data,
      isVenueName;
    if (_this.venue_name.replace(/\s+/g, "").length == 0) {
      util.iconnone('请先填写场馆名称');
      isVenueName = false
    } else if (_this.venue_id == 0) {
      util.iconnone('请先按顺序填写财务信息');
      isVenueName = false
    }
    return isVenueName
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  touchStart: function() {
    var _this = this.data;
  },
  venuesubmission: function() {
    var _this = this.data,
      sumben = true;
    for (var key in _this.venue_info) {
      if (key != 'img_temp_array' && key != 'img_list' && key != 'is_order' && key != 'is_order_a' && key != 'sub_no' && key != 'venue_name_c') {
        if (_this.venue_info[key] == '') {
          sumben = false;
        }
      }
    }
    if (Object.keys(_this.venue_info).length == 0) {
      sumben = false;
    }
    if (util.getcache(util, '../../../login/login') && _this.venue_name.length != 0) {
      if (!sumben) {
        util.iconnone('别调皮,请填写信息再提交')
      }
      if (_this.venue_id == 0) {
        return;
      }
      var adddata = {
        venue_id: _this.venue_id,
        venue_name: _this.venue_name,
        venue_name_c:_this.venue_name_c,
        venue_type:_this.venue_type,
        brand_id: this.data.brand_original[_this.brandIndex - 1].brand_id,
        userKey: util.get('user').userKey,
      };
      var url = "";
      if (_this.venue_info.is_order_a =="1") {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      util.requestGroups(url, adddata).then((res) => {
        if (util.invalid(res.data, util, '../../../login/login')) {
          return
        }
        if (res.data.code == 0) {}
      })
    }
    if (!sumben) {
      util.iconnone('别调皮,请填写信息再提交')
      return
    }
    if (util.getcache(util, '../../../login/login') && sumben) {
      wx.showLoading({
        mask: true
      })
      var modifydata = {
        venue_id: _this.venue_id,
        venue_name: _this.venue_name,
        venue_name_c: _this.venue_name_c,
        venue_type: _this.venue_type,
        brand_id: this.data.brand_original[_this.brandIndex - 1].brand_id,
        userKey: util.get('user').userKey,
        is_order: 3
      };
      var url="";
      if (_this.venue_info.is_order_a == "1") {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      util.requestGroups(url, modifydata).then((res) => {
        wx.hideLoading({})
        if (util.invalid(res.data, util, '../../../login/login')) {
          return;
        }
        if (res.data.code == 0) {
          util.iconnone('提交成功')
          this.setData({
            is_order: 3
          })
          setTimeout(() => {
            wx.navigateBack({})
          }, 1000)
        }
      }, (res) => {
        wx.hideLoading({})
      })
    }
  },
  //失败原因
  failreason:function(){
    wx.navigateTo({
      url: '../failreason/failreason?venue_id=' + this.data.venue_id,
    })
  },
  examinetap: function() {
    util.iconnone('审核中,不可操作')
  },
  //删除场馆
  delvenue:function(){
    wx.showModal({
      title: '删除',
      content: '是否删除该场馆',
      success:(res)=>{
        if (res.confirm) {
          var data={
            venue_id:this.data.venue_id,
            userKey: util.get('user').userKey,
          }
          util.requestGroups('/supp/venue/delete',data).then((res)=>{
            if(res.data.code==0){
              this.setData({
                venue:false
              })
              wx.showToast({
                title: '删除成功',
                duration:600,
                mask:true,
              })
              setTimeout(()=>{
                wx.navigateBack({})
              },600)
            }else{
              util.iconnone(res.data.code)
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  delvenue_adopt:function(){
    util.iconnone('暂无删除上线场馆功能')
  }
})