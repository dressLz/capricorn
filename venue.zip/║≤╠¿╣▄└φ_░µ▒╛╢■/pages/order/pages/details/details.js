var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    order_id:'',
    order_info:{},
    down_time:'',
    settime:{},  //倒计时
    minute:'',
    minute_display:false, //倒计时
    setsecond:{},
    current_time:0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      order_id: options.order_id,
      imgUrl: util.imgUrl(),
    })
  },
  calling: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone,
      success: function () {
        // console.log("拨打电话成功！")
      },
      fail: function () {
        // console.log("拨打电话失败！")
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    if (util.getcache(util, '../../login/login')) {
      this.orderInfo(this,_this)
    }
  },
  //订单确认
  orderconfirm:function(e){
    wx.showLoading({
      title: '确认订单',
      mask: true,
    })
    var _this=this.data;
    if (util.getcache(util, '../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/order/accept',
        method: 'POST',
        data:{
          userKey:util.get('user').userKey,
          order_id: this.data.order_id
        },success:(res)=>{
          if(res.data.code==0){
            util.iconnone('确认成功')
            this.setData({
              minute_display: false,
            })
            clearInterval(_this.settime)
            clearInterval(_this.current_time)
            this.orderInfo(this, _this)
          }
        },complete:(res)=>{
          wx.hideLoading()
        }
      })
    }else{
      wx.hideLoading()
    }
  },
  //订单取消
  ordercancel:function(e){
    wx.showLoading({
      title: '取消订单',
      mask:true,
    })
    var _this = this.data;
    if (util.getcache(util, '../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/order/refuse',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          order_id: this.data.order_id
        }, success: (res) => {
          if (res.data.code == 0) {
            util.iconnone('取消成功')
            this.setData({
              minute_display: false,
            })
            clearInterval(_this.settime)
            clearInterval(_this.current_time)
            this.orderInfo(this, _this)
          }
        },complete:(res)=>{
          wx.hideLoading()
        }
      })
    }else{
      wx.hideLoading()
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(this.data.settime)
    clearInterval(this.data.settime)
    clearInterval(this.data.current_time)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  orderInfo:function(tant,_this){
    wx.request({
      url: util.prefixUrl() +'supp/order/info',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        order_id: _this.order_id,
      },
      success: (res) => {
        if (!res.data.code) {
          tant.setData({
            order_info: res.data
          })
          _this.current_time = res.data.current_time
          _this.setsecond=setInterval(()=>{
            _this.current_time++
          },1000)
          if (_this.order_info.status == '1') {  //支付成功
            if (_this.current_time - _this.order_info.pay_time > 1800) {  //确认超时
              _this.order_info.status == '2'
            } else {
              this.setData({
                minute_display:true
              })
              let let_time =1800 - (_this.current_time- _this.order_info.pay_time);
              _this.settime = setInterval(() => {
                //确认倒计时
                this.setData({
                   minute: this.countDown(let_time--)
                })
                if (let_time <= 0){
                  _this.order_info.status = '2';
                  console.log('1')
                  this.setData({
                    minute_display: false,
                    order_info: _this.order_info
                  })
                  clearInterval(_this.settime)
                  clearInterval(_this.current_time)
                }
              }, 1000)
            }
            this.setData({
              order_info: _this.order_info
            })
          }
        }
      }
    })
  },
  countDown: function (second) {
    var s = second % 60;
    var m = Math.floor(second / 60);
    if (s.toString().length == 1) {
      s = "0" + s
    }
    return m + ':' + s
  },
})