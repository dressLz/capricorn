var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    venue_id:0,
    coach_id:0,
    initial_Array:[],
    initial_multiIndex:[0,0]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var _this=this.data;
    _this.venue_id=options.venue_id;
    _this.coach_id = options.coach_id;
  },
  bindinitialtime:function(e){
    if (e.detail.value[0] > e.detail.value[1]){
      util.iconnone('结束大于开始时间')
      return;
    }
    this.setData({
      initial_multiIndex: e.detail.value
    })
  },
  nextcoach:function(e){
    var _this=this.data,
      open_time = _this.initial_Array[0][_this.initial_multiIndex[0]] ,
      close_time = _this.initial_Array[0][_this.initial_multiIndex[1]],
      data = {
        venue_id: _this.venue_id,
        coach_id: _this.coach_id,
        open_time: open_time,
        close_time: close_time,
        operator_id: util.get('user').supplier_id,
        userKey: util.get('user').userKey
      };
    util.requestGroups('supp/coach/setCourseTime',data).then((res)=>{
      if(res.data.code==0){
        wx.redirectTo({
          url: '../curriculum/curriculum?coach_id=' + _this.coach_id + '&venue_id=' + _this.venue_id,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data,
        data={
          venue_id:_this.venue_id,
          coach_id:_this.coach_id,
          userKey:util.get('user').userKey
        };
    util.requestGroups('supp/coach/getCouresTime',data).then((res)=>{
      _this.initial_Array[0]=res.data.default_time.split(',');
      _this.initial_Array[1] = res.data.default_time.split(',');
      _this.initial_multiIndex[1] = _this.initial_Array[1].length-1;
      if (res.data.close_time.length>0){
        _this.initial_multiIndex = [_this.initial_Array[0].indexOf(res.data.open_time),_this.initial_Array[0].indexOf(res.data.close_time)]
      }
      this.setData({
        initial_Array: _this.initial_Array,
        initial_multiIndex: _this.initial_multiIndex
      })
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})