var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',    
    venue_id:0,
    coach_id:0,
    coach_basic:false,
    coach_attr:'',
    coach_sum:0,
    coach_info:{
      visible_no:0,
      open_no:0,
      video:''
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this.data;
     this.setData({
       imgUrl: util.imgUrl(),
     })
    _this.coach_id = options.coach_id
    _this.venue_id = options.venue_id
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  //基本信息
  basicTap:function(){
    wx.navigateTo({
      url: '../basic/register?venue_id=' + this.data.venue_id + '&coach_id=' + this.data.coach_id,
    })
  },
  //开设课程
  curriculum: function () {
    wx.navigateTo({
      url: '../../../coach/pages/curriculum/curriculum?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this.data;
    if (_this.coach_id != 0) {
      this.setData({
        coach_id: _this.coach_id
      })
      wx.request({
        url: util.prefixUrl() + 'supp/coach/info',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          coach_id: _this.coach_id
        },
        success: (res) => {
          this.setData({
            coach_info: res.data,
          })
          _this.coach_attr = ''
          _this.attr = res.data.coach_attr
          res.data.coach_attr.map((value, index) => {
            if (value.checked == 1) {
              _this.coach_attr += value.attr_id + ','
            }
          })
          this.setData({
            coach_attr: _this.coach_attr,
            coach_sum: this.data.coach_attr.split(',').length - 1
          })
          if (res.data.description.length > 0 && res.data.coach_name.length > 0  && _this.coach_sum>0){
            this.setData({
              coach_basic:true
            })
          }
        }
      })
    }
  },
  cantchvideo: function () {
    wx.navigateTo({
      url: '../../../index/pages/upvideo/upvideo?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
    })
  },
  submission:function(){
    var _this=this.data;
    if (!_this.coach_basic){
      util.iconnone('请完善基本信息')
      return;   
    }
    var url = "";
    if (this.data.coach_info.is_visible_a == '1') {
      url = 'supp/coach/updateCoach'
    } else {
      url = 'supp/coach/add';
    }
    wx.request({
      url: util.prefixUrl() + url,
      method: 'POST',
      data: {
        is_visible:3,
        coach_id:_this.coach_id,
        shop_id :util.get('user').shop_id,
        venue_id :_this.venue_id,
        userKey: util.get('user').userKey,
        operator_id:util.get('user').supplier_id
      },
      success: (res) => {
        wx.navigateBack({
        })
      }, complete: () => {
        wx.hideLoading()
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },
  //失败原因
  failreason: function () {
    wx.navigateTo({
      url: '../failreason/failreason?coach_id=' + this.data.coach_id,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})