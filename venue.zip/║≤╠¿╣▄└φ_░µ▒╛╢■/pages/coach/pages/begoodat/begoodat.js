var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    coach_id: 0,
    venue_id: 0,
    course: [],
    cour_list:[],
    is_initial:true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('加课程')
    var _this = this.data
    _this.coach_id = options.coach_id
    _this.venue_id = options.venue_id
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  //添加课程
  briefrequst: function() {
    var _this = this.data, 
        course='';
    _this.course.map((value,index)=>{
      if (value.checked==1){
        course += value.course_id+',';
      }
    })
    if (course.length == 0) {
      util.iconnone('请选择课程')
      return;
    }
    var data = {
      userKey: util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_id: _this.venue_id,
      operator_id: util.get('user').supplier_id,
      coach_id: _this.coach_id,
      course: course
    }
    wx.request({
      url: util.prefixUrl() +'supp/coach/addCoachCourse',
      method: 'POST',
      data: data,
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        } else {
          util.iconnone('保存成功')
          setTimeout(() => {
            // wx.redirectTo({
            //   url: '../curriculum/curriculum?venue_id=' + _this.venue_id + '&coach_id=' + _this.coach_id,
            // })
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      }
    })
  },
  /*** 生命周期函数--监听页面显示*/
  onShow: function() {
    var _this = this.data;
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    wx.request({
      url: util.prefixUrl() +'supp/coach/coachCourse',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id
      },
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
          return;
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
        } else {
          _this.course = res.data;
          _this.cour_list = res.data;
          this.setData({
            course: _this.course,
            cour_list: _this.cour_list
          })
          _this.cour_list.map((value,index)=>{
              if(value.checked==1){
                _this.is_initial=false;
              }
          })
        }
      }
    })
  },
  begoodatcheck: function(e) {
    var startIndex = e.currentTarget.dataset.index,
        _this=this.data,
        sum=0;
    _this.course.map((value, index) => {
       if(value.checked==1){
         sum++;
       }
    })
    if (_this.course[startIndex].checked == 0 && sum >= 2){
        util.iconnone('最多选两种课程');
        return;
    }
    _this.course[startIndex].checked == 0 ? _this.course[startIndex].checked = 1 : _this.course[startIndex].checked = 0;
    this.setData({
      course: this.data.course
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
})