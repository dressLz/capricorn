var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    data_info: {},
    startTime: [],
    startIndex: 0,
    endTime: [],
    endIndex: 0,
    venue_id: 0,
    coach_id: 0,
    course_id_old: 0,  //老课程id
    course_id:0,//最新更改
    course_name:'',//类型名称
    price:'',
    open_time:'',
    close_time:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var temp = JSON.parse(options.data),
        _this=this.data;
    this.setData({
      imgUrl: util.imgUrl(),
      coach_id: temp.coach_id,
      venue_id: temp.venue_id,
      course_id: temp.course_id,
      course_id_old: temp.course_id
    })
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    var ajaxData = {
      venue_id: _this.venue_id,
      coach_id: _this.coach_id,
      course_id: _this.course_id,
      userKey: util.get('user').userKey,
    }
    util.requestGroups('supp/coach/stencil', ajaxData).then((res) => {
      var timeArry = res.data.default_time
      _this.data_info = res.data;
      if (res.data.price == 0.00) {
        _this.price = '';
      } else {
        _this.price = res.data.price
      }
      this.setData({
        data_info: _this.data_info,
        startTime: _this.startTime,
        course_name: _this.data_info.course_name,
        endTime: _this.endTime,
        endIndex: _this.endIndex,
        startIndex: _this.startIndex,
        price: _this.price,
        open_time: res.data.open_time,
        close_time: res.data.close_time
      })
    })
  },
  //更新数据.
  changepage: function (course){
    var _this=this.data;
    console.log()
    this.setData({
      course_id: course.course_id,
      course_name: course.course_name
    })
  },
  //更新介绍和简介
  changwrang: function (change){
    if (change.type =="warning"){
      this.data.data_info.warning = change.content;
    }else{
      this.data.data_info.introduction = change.content;
    }
    this.setData({
      data_info: this.data.data_info
    })
  },
  //修改课程类型
  modifycat:function(){
    var _this=this.data;
    wx.navigateTo({
      url: '../modify/begoodat?venue_id=' + _this.venue_id + '&coach_id=' + _this.coach_id + '&course_id=' + _this.course_id_old,
    })
  },
  //开始时间
  bindtimeChange: function(e) {
    if (e.detail.value == this.data.startTime.length-1){
      util.iconnone('此时间不可选')
      return
    }
    this.setData({
      startIndex: e.detail.value
    })
  },
  //简介
  introductionClass:function(){
    var _this = this.data,
      data = {
        venue_id: _this.venue_id,
        coach_id: _this.coach_id,
        course_id: _this.course_id,
        type: "introduction",
      };
    wx.navigateTo({
      url: '../remarks/remarks?data=' + JSON.stringify(data),
    })
  },
  //警告
  warningClass:function(){
    var _this=this.data,
        data={
          venue_id:_this.venue_id,
          coach_id:_this.coach_id,
          course_id:_this.course_id,
          type:"warning",
        }
    wx.navigateTo({
      url: '../remarks/remarks?data=' + JSON.stringify(data),
    })
  },
  //结束时间
  bindendChange: function(e) {
    var _this=this.data;
    _this.endIndex=e.detail.value;
    if (parseInt(_this.endIndex) <= parseInt(_this.startIndex)) {
      util.iconnone('截止不可小于开始');
      this.setData({
        endIndex: parseInt(_this.startIndex)+1
      })
    }else{
      this.setData({
        endIndex: _this.endIndex
      })
    }
  },
  priceinputblur:function(e){
    var value = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
    this.setData({
      price: parseFloat(value).toFixed(2)
    })
  },
  //提交保存
  settemp: function() {
    var _this = this.data;
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    if (_this.price == 0 || _this.price.replace(/\s*/g, "").length==0){
      util.iconnone("价格不可为0")
      return
    }
    var data = {
      userKey: util.get('user').userKey,
      operator_id: util.get('user').supplier_id,
      stencil_id: _this.data_info.stencil_id,
      venue_id: _this.venue_id,
      coach_id: _this.coach_id,
      course_id_old: _this.course_id_old,
      course_id: _this.course_id,
      is_point: _this.data_info.is_point,
      open_time: _this.open_time,
      close_time: _this.close_time,
      price: _this.price,
      num: '1',
      unit: 0
    }
    wx.request({
      url: util.prefixUrl() +'supp/coach/stencilSave',
      method: 'POST',
      data: data,
      success: (res) => {
        wx.navigateBack({})
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
  //   var ajaxData = {
  //     venue_id: _this.venue_id,
  //     coach_id: _this.coach_id,
  //     course_id: _this.course_id,
  //     userKey: util.get('user').userKey,
  //   }
  //   util.requestGroups('supp/coach/stencil', ajaxData).then((res) => {
  //     this.setData({
  //       data_info: _this.data_info,
  //     })
  //   })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})