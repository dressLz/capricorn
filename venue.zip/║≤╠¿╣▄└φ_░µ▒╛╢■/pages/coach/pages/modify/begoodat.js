var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    coach_id: 0,
    venue_id: 0,
    course_id:0,
    course: [],
    cour_list:[],
    is_initial:true,
    startIndex:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this = this.data
    if (options.course_id){
      this.setData({
        course_id: options.course_id
      })
    }
    _this.coach_id = options.coach_id;
    _this.venue_id = options.venue_id;
    console.log()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
  },
  /*** 生命周期函数--监听页面显示*/
  onShow: function() {
    var _this = this.data;
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    wx.request({
      url: util.prefixUrl() +'supp/coach/coachCourse',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id
      },
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
          return;
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
        } else {
          _this.course = res.data;
          _this.cour_list = res.data;
          this.setData({
            course: _this.course,
            cour_list: _this.cour_list
          })
          _this.cour_list.map((value,index)=>{
              if(value.checked==1){
                _this.is_initial=false;
              }
          })
        }
      }
    })
  },
  begoodatcheck: function(e) {
    var startIndex = e.currentTarget.dataset.index,
        _this=this.data,
        page_up_index=0,
        sum=0;
    _this.startIndex = startIndex;
    _this.course.map((value, index) => {
      if (value.checked == 1) {
        sum++;
      }
    })
    if (_this.course[startIndex].checked == 1 && _this.course[startIndex].course_id != _this.course_id) {
      util.iconnone('此处课程不可修改');
      return;
    }
    if(_this.course[startIndex].checked==1){
      console.log('return')
      return;
    }
    if (sum==1){
      _this.course[startIndex].checked == 0 ? _this.course[startIndex].checked = 1 : '';
      _this.course_id = _this.course[startIndex].course_id;
    }else{
      _this.course.map((value, index) => {
        if (_this.course_id == value.course_id) {
          page_up_index = index;
        }
      })
      _this.course[page_up_index].checked = 0;
      _this.course[startIndex].checked == 0 ? _this.course[startIndex].checked = 1 : '';
      _this.course_id = _this.course[startIndex].course_id;
    }
    this.setData({
      course: this.data.course,
      course_id: _this.course_id
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  navbackto:function(){
      var _this=this.data;
      util.iconnone('修改');
      var pages = getCurrentPages(); // 获取页面栈
      if (pages.length > 1) {
        //上一个页面实例对象
        var prePage = pages[pages.length - 2];
        var course = {
          course_name: _this.course[_this.startIndex].course_name,
          course_id: _this.course_id
        }
        //关键在这里  changeData为上一页的方法
        prePage.changepage(course)
        //返回上一页
        wx.navigateBack({
          delta: 1
        })
      }
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
})