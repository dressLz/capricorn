var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    data_info: {},
    startTime: [],
    startIndex: 0,
    endTime: [],
    endIndex: 0,
    venue_id: 0,
    coach_id: 0,
    course_id: 0,
    price: '',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var temp = JSON.parse(options.data)
    this.setData({
      imgUrl: util.imgUrl(),
      coach_id: temp.coach_id,
      venue_id: temp.venue_id,
      course_id: temp.course_id
    })
  },
  //开始时间
  bindtimeChange: function (e) {
    if (e.detail.value == this.data.startTime.length - 1) {
      util.iconnone('此时间不可选')
      return
    }
    this.setData({
      startIndex: e.detail.value
    })
  },
  //结束时间
  bindendChange: function (e) {
    var _this = this.data;
    _this.endIndex = e.detail.value;
    if (parseInt(_this.endIndex) <= parseInt(_this.startIndex)) {
      util.iconnone('截止不可小于开始');
      this.setData({
        endIndex: parseInt(_this.startIndex) + 1
      })
    } else {
      this.setData({
        endIndex: _this.endIndex
      })
    }
  },
  //价格
  pricechange: function (e) {
    e.detail.value = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
    this.setData({
      price: e.detail.value
    })
  },
  //保存
  settemp: function () {
    var _this = this.data;
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    if (_this.price == 0 || _this.price.replace(/\s*/g, "").length == 0) {
      util.iconnone("价格不可为0")
      return
    }
    var data = {
      userKey: util.get('user').userKey,
      operator_id: util.get('user').supplier_id,
      stencil_id: _this.data_info.stencil_id,
      venue_id: _this.venue_id,
      coach_id: _this.coach_id,
      course_id: _this.course_id,
      is_point: _this.data_info.is_point,
      open_time: _this.startTime[_this.startIndex],
      close_time: _this.startTime[_this.endIndex],
      price: _this.price,
      num: '1',
      unit: 0
    }
    wx.request({
      url: util.prefixUrl() + 'supp/coach/stencilSave',
      method: 'POST',
      data: data,
      success: (res) => {
        wx.navigateBack({})
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this.data
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    wx.request({
      url: 'https://fitness.fengdutiyu.com/index.php/supp/coach/stencil',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id,
        venue_id: _this.venue_id,
        course_id: _this.course_id
      },
      success: (res) => {
        var timeArry = res.data.default_time
        timeArry = timeArry.split(',')
        _this.startTime = timeArry;
        _this.endTime = timeArry
        _this.data_info = res.data;
        _this.startTime.map((value, index) => {
          if (value == res.data.close_time) {
            _this.endIndex = index
          }
          if (value == res.data.open_time) {
            _this.startIndex = index
          }
        })
        if (res.data.price == 0.00) {
          _this.price = '';
          console.log('0')
        } else {
          _this.price = res.data.price
        }
        this.setData({
          startTime: _this.startTime,
          endTime: _this.endTime,
          endIndex: _this.endIndex,
          startIndex: _this.startIndex,
          price: _this.price
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})