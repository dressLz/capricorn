var dtime = '_deadtime';
function put(k, v, t) {
  wx.setStorageSync(k, v)
  var seconds = parseInt(t);
  if (seconds > 0) {
    var timestamp = Date.parse(new Date());
    timestamp = timestamp / 1000 + seconds;
    wx.setStorageSync(k + dtime, timestamp + "")
  } else {
    wx.removeStorageSync(k + dtime)
  }
}
function prefixUrl(){
  return 'https://fitness.fengdutiyu.com/index.php/';
}
function imgUrl() {
  return 'https://fitness.fengdutiyu.com/';
}
//封装request
function requestGroups(url, data) {
  var data = new Promise(function (resolve, reject) {
    wx.request({
      url: 'https://fitness.fengdutiyu.com/index.php/'+url,
      method: 'POST',
      data: data,
      success: function (res) {
        resolve(res)
      },
      fail: function (res) {
        reject("系统异常，请重试！")
      },
      complete: function (res) {
        wx.hideLoading()
      },
    })
  })
  return data
}
//封装request
function requestGroup(url, data){
  var data = new Promise(function (resolve, reject) {
    wx.request({
      url:url,
      method: 'POST',
      data:data,
      success: function (res) { 
        resolve(res) 
      },
      fail: function (res) {
        reject("系统异常，请重试！")
      },
      complete: function (res) {
        wx.hideLoading()
      },
    })
  })
  return data 
}
function get(k, def) {
  var deadtime = parseInt(wx.getStorageSync(k + dtime))
  if (deadtime) {
    if (parseInt(deadtime) < Date.parse(new Date()) / 1000) {
      if (def) {
        return def;
      } else {
        return;
      }
    }
  }
  var res = wx.getStorageSync(k);
  if (res) {
    return res;
  } else {
    return def;
  }
}
//密码验证
function password(password) {
  if (password.length > 7 && password.length < 16){
    return true
  }else{
    return false
  }
}
//账号验证
function verification(username){
  wx.request({
    url: 'https://fitness.fengdutiyu.com/index.php/supp/supplier/check',
    method: 'POST',
    data: {
      username: username
    },
    success: (res) => {
      if (res.data.code == '1') {
        wx.showToast({
          title: '账号已占用',
          image: '../image/error.png',
          duration: 1000,
          mask: true,
          success: () => {
          },
          complete: () => {}
        })
      }
    }
  })
}
//post请求
function postRequest(params, success, fail) {
  this.postRequestLoading(params, success, fail)
}
//根据判断message 是否显示loading
function postRequestLoading(params,success, fail) {
  const postRequestTask = wx.request({
    url: 'https://fitness.fengdutiyu.com/index.php/supp/supplier/check',
    data: params,
    method: 'POST',
    success: function (res) {
      if (res.statusCode == 200) {
        success(res.data)
      } else {
        fail(res)
      }
    },
    fail: function (res) {
      fail(res)
    }
  })
}
//取消post请求
function abortPostRequest(url, params, success, fail) {
  postRequestTask.abort()
}
// 字符串加密成 hex 字符串
function sha1(s) {
  var data = new Uint8Array(encodeUTF8(s))
  var i, j, t;
  var l = ((data.length + 8) >>> 6 << 4) + 16, s = new Uint8Array(l << 2);
  s.set(new Uint8Array(data.buffer)), s = new Uint32Array(s.buffer);
  for (t = new DataView(s.buffer), i = 0; i < l; i++)s[i] = t.getUint32(i << 2);
  s[data.length >> 2] |= 0x80 << (24 - (data.length & 3) * 8);
  s[l - 1] = data.length << 3;
  var w = [], f = [
    function () { return m[1] & m[2] | ~m[1] & m[3]; },
    function () { return m[1] ^ m[2] ^ m[3]; },
    function () { return m[1] & m[2] | m[1] & m[3] | m[2] & m[3]; },
    function () { return m[1] ^ m[2] ^ m[3]; }
  ], rol = function (n, c) { return n << c | n >>> (32 - c); },
    k = [1518500249, 1859775393, -1894007588, -899497514],
    m = [1732584193, -271733879, null, null, -1009589776];
  m[2] = ~m[0], m[3] = ~m[1];
  for (i = 0; i < s.length; i += 16) {
    var o = m.slice(0);
    for (j = 0; j < 80; j++)
      w[j] = j < 16 ? s[i + j] : rol(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1),
        t = rol(m[0], 5) + f[j / 20 | 0]() + m[4] + w[j] + k[j / 20 | 0] | 0,
        m[1] = rol(m[1], 30), m.pop(), m.unshift(t);
    for (j = 0; j < 5; j++)m[j] = m[j] + o[j] | 0;
  };
  t = new DataView(new Uint32Array(m).buffer);
  for (var i = 0; i < 5; i++)m[i] = t.getUint32(i << 2);

  var hex = Array.prototype.map.call(new Uint8Array(new Uint32Array(m).buffer), function (e) {
    return (e < 16 ? "0" : "") + e.toString(16);
  }).join("");

  return hex;
};
//营业时间选择
function multiArray(){
  var timeList = ['00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30',
    '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30',
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
    '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30',
    '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30', '24:00']
  multiArray = [timeList, timeList];
  return multiArray
}
function formdata(util,data){
  var submit=true;
  for (var k in data) {
    if (data[k].length == 0) {
      submit = false
      util.iconnone('请填写完整')
    }
  }
  return submit;
}
function remove(k) {
  wx.removeStorageSync(k);
  wx.removeStorageSync(k + dtime);
}

function clear() {
  wx.clearStorageSync();
}
//弹框(警告)
function frametips(title) {
  wx.showToast({
    title: title,
    image: '../image/error.png',
    duration: 1000,
    mask: true,
    success: () => {},
    complete: () => {}
  })
}
function encodeUTF8(s) {
  var i, r = [], c, x;
  for (i = 0; i < s.length; i++)
    if ((c = s.charCodeAt(i)) < 0x80) r.push(c);
    else if (c < 0x800) r.push(0xC0 + (c >> 6 & 0x1F), 0x80 + (c & 0x3F));
    else {
      if ((x = c ^ 0xD800) >> 10 == 0) //对四字节UTF-16转换为Unicode
        c = (x << 10) + (s.charCodeAt(++i) ^ 0xDC00) + 0x10000,
          r.push(0xF0 + (c >> 18 & 0x7), 0x80 + (c >> 12 & 0x3F));
      else r.push(0xE0 + (c >> 12 & 0xF));
      r.push(0x80 + (c >> 6 & 0x3F), 0x80 + (c & 0x3F));
    };
  return r;
};
//无图标
function iconnone(title){
  wx.showToast({
    title: title,
    mask:true,
    icon: 'none',
    duration:1000
  })
}
//弹框(错误)
function failtips(title) {
  wx.showToast({
    title: title,
    image: '../image/error.png',
    duration: 1000,
    mask: true,
    success: () => {
    },
    complete: () => {}
  })
}
//弹框(成功)
function successtips(title) {
  wx.showToast({
    title: title,
    duration: 1000,
    mask: true,
    success: () => {},
    complete: () => {}
  })
}
//会话失效
function invalid(data, util,url){
  if(data.code==-1){
    util.remove('user')
    util.iconnone('登录失效')
    wx.reLaunch({
      url: url,
    })
  }
}
function invalidNew(util, url) {
    util.remove('user')
    util.iconnone('登录失效')
    wx.reLaunch({
      url: url,
    })
}
function getcache(util, url) {
  if (util.get('user')==undefined){
    util.iconnone('登录失效')
    util.remove('user') 
    wx.reLaunch({
      url: url,
    })
    return false;
  }else{
    return true;
  }
}
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()
  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}
function navlist() {
  var navList = [];
  for (var i = 0; i < 7; i++) {
    var day3 = new Date();
    day3.setTime(day3.getTime() + (24 * 60 * 60 * 1000 * i));
    var Y = day3.getFullYear();
    var M = (day3.getMonth() + 1);
    var D = day3.getDate()
    var weekday = day3.getDay()
    if (M < 10) {
      M = '0' + M;
    }
    if (D < 10) {
      D = '0' + D;
    }
    var s3 = M + '月' + D + '日'
    var year = Y + '-' + M + '-' + D;
    var week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'], weekname = "";
    if (i < 3) {
      i == 0 ? weekname = '今天' : i == 1 ? weekname = '明天' : i == 2 ? weekname = '后天' : '';
    } else {
      weekname = week[new Date(day3).getDay()]
    }
    navList.push({ 'name': weekname, 'date': s3, "year": year, "week": weekday })
  }
  return navList
}
function navlistCoach() {
  var navList = [];
  for (var i = 0; i < 7; i++) {
    var day3 = new Date();
    day3.setTime(day3.getTime() + (24 * 60 * 60 * 1000 * i));
    var Y = day3.getFullYear();
    var M = (day3.getMonth() + 1);
    var D = day3.getDate()
    var weekday = day3.getDay()
    if (M < 10) {
      M = '0' + M;
    }
    if (D < 10) {
      D = '0' + D;
    }
    var s3 = M + '/' + D
    var year = Y + '-' + M + '-' + D;
    var week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'], weekname = "";
    if (i < 3) {
      i == 0 ? weekname = '今天' : i == 1 ? weekname = '明天' : i == 2 ? weekname = '后天' : '';
    } else {
      weekname = week[new Date(day3).getDay()]
    }
    navList.push({ 'name': weekname, 'date': s3, "year": year, "week": weekday })
  }
  return navList
}
function settime() {
  var countdown = 60;
  var timer = setInterval(() => {
    if (countdown == 0) {
      clearInterval(timer)
    } else {
      countdown--;
    }
    return countdown;
  }, 1000)
}
//验证账户昵称
function checkaccount(account) { //必须为字母加数字且长度不小于6位
  var str = account;
  var regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
    regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;
  if (regEn.test(account) || regCn.test(account)) {
    return false;
  }else{
    if (str == null || str.length < 6) {
      return false;
    }else{
      return true;
    }
  }
}
function calculateDiffTime(start_time, end_time) {
  var startTime = 0, endTime = 0
  if (start_time < end_time) {
    startTime = start_time
    endTime = end_time
  } else {
    startTime = end_time
    endTime = start_time
  }
  var timeDiff = endTime - startTime
  var hour = Math.floor(timeDiff / 3600);
  timeDiff = timeDiff % 3600;
  var minute = Math.floor(timeDiff / 60);
  timeDiff = timeDiff % 60;
  var second = timeDiff;
  return [hour, minute, second]
}
//时间戳转换
function timestampToTime(timestamp) {
  var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
  var Y = date.getFullYear() + '-';
  var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
  var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
  return Y + M + D;
}
//验证手机号码
function number(str) {
  var reg = /^\d{1,}$/
  var pattern = new RegExp(reg);
  pattern.test(str);
}
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
module.exports = {
  formatTime: formatTime,
  checkaccount: checkaccount,
  put: put,
  get: get,
  remove: remove,
  clear: clear,
  frametips: frametips,
  successtips: successtips,
  failtips: failtips,
  iconnone: iconnone,
  timestampToTime: timestampToTime,
  invalid: invalid,
  multiArray: multiArray,  //抛出营业时间
  invalidNew: invalidNew,
  navlist: navlist,
  sha1: sha1,
  getcache: getcache,
  formdata: formdata,  //表单值是否为空
  postRequest: postRequest,
  postRequestLoading: postRequestLoading,
  requestGroup: requestGroup,
  requestGroups: requestGroups,
  prefixUrl: prefixUrl,    //域名
  imgUrl: imgUrl,
  password: password,  //密码验证
  calculateDiffTime: calculateDiffTime,
  navlistCoach: navlistCoach,  //教练课程时间
}