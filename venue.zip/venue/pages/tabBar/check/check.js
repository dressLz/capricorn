var util = require('../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    order_info: {},
    inputLen: 7,
    query: true,
    fail: false,
    orderexamine: false, //核销的订单
    iptValue: "",
    isFocus: false,
  },
  onLoad: function () {
    var _this = this.data;
    this.setData({
      imgUrl: util.imgUrl(),
      user: util.get('user')
    })
  },
  onShow: function () {
    var _this = this.data;
    if (_this.user.sub_type == '2') {
      util.iconnone('账号无权限')
    }
  },
  onFocus: function (e) {
    var that = this;
    that.setData({
      isFocus: true
    });
  },
  setValue: function (e) {
    var that = this;
    that.setData({
      iptValue: e.detail.value
    });
    console.log(e.detail.value)
  },
  // 审核
  examine: function () {
    var _this = this.data,
      arrKey = [],
      sign = "";
    var data = {
      userKey: util.get('user').userKey,
      use_key: _this.iptValue,
      shop_id: util.get('user').shop_id
    };
    for (var key in data) {
      arrKey.push(key)
    }
    arrKey.sort()
    arrKey.map((value, index) => {
      sign += value + '=' + data[value]
    })
    sign = sign.toLowerCase() + "q4lK5S1MU#LGCnHT"
    sign = util.sha1(sign);
    var data = {
      userKey: util.get('user').userKey,
      use_key: _this.iptValue,
      shop_id: util.get('user').shop_id,
      sign: sign,
      sub_type: util.get('user').sub_type,
    };
    if (_this.iptValue.length == 7) {
      wx.request({
        url: util.prefixUrl() + 'supp/order/writeoff',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          use_key: _this.iptValue,
          shop_id: util.get('user').shop_id,
          sign: sign,
          sub_type: util.get('user').sub_type,
        },
        success: (res) => {
          if (res.data.code == 1) {
            util.iconnone(res.data.msg)
            this.setData({
              iptValue: ''
            })
          }
          if (!res.data.code) {
            this.setData({
              order_info: res.data,
              orderexamine: true
            })
          }
        }
      })
    }
  },
  //返回核验
  backcheck: function () {
    this.setData({
      imgUrl: '',
      order_info: {},
      inputLen: 7,
      query: true,
      fail: false,
      orderexamine: false,
      iptValue: "",
      isFocus: false,
    })
  },
  //跳转详情
  navdetails: function (e) {
    wx.navigateTo({
      url: '../../order/pages/details/details?order_id=' + e.currentTarget.dataset.id,
    })
  },
})