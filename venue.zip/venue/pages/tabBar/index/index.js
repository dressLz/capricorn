//index.js
//获取应用实例
const app = getApp()
var util = require('../../../utils/util.js')
Page({
  data: {
    first_brand:0,
    display: false,
    imgUrl: '',
    user: {},
    is_brand: true,
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    venue: true,
    venue_case:false,
    venue_list: [],
  },
  onLoad: function () {
/********************************************************************************/ 
    wx.hideTabBar({
      success: function (res) {
      }
    })
    wx.showLoading({
      title: '拼命加载...',
      mask: true
    })
    var _this = this.data;
    this.setData({
      imgUrl: util.imgUrl(),
      user: util.get('user')
    })
    var data = {
      shop_id: util.get('user').shop_id,
      venue_id: util.get('user').venue_id,
      userKey: util.get('user').userKey,
    };
    util.requestGroups('supp/order/isNewOrder', data).then(
      (res) => {
        if (res.data == 1) {
          wx.showTabBarRedDot({
            index: 1
          })
        } else {
          wx.hideTabBarRedDot({
            index: 1
          })
        }
      },
      (res) => {
        util.iconnone('网络故障')
      }
    )
  },
  onShow: function() {
    var _this = this.data;
    if (_this.user.sub_type == '3') {
      util.iconnone('账号无权限')
    }
    util.requestGroups('supp/Supplier/brandShop', { shop_id: util.get('user').shop_id }).then(
      (res) => {
        this.setData({
          first_brand: res.data.is_visible
        })
      }
    )
    var tant = this,
      data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id
      }
    if (!util.getcache(util, '../../../login/login')) {
      return;
    }
    // this.brandrequest(_this, util).then((res) => {
    //     if (res) {
    //       this.setData({
    //         display: true
    //       })
    //       wx.showTabBar({
    //         success: function (res) {
    //           console.log(res)
    //         }
    //       })
    //       return util.requestGroups('supp/venue/list', data)
    //     } else {
    //       util.iconnone('请先创建品牌')
    //       this.setData({
    //         display: false
    //       })
    //       setTimeout((res) => {
    //         wx.navigateTo({
    //           url: '../../user/pages/core/core',
    //         })
    //       }, 1500)
    //     }
    //   },
    //   (res) => {
    //     util.iconnone('网络故障')
    //   }
    // ).then((res) => {
    //   if (res) {
    //     if (util.invalid(res.data, util, '../../login/login')) {
    //       return
    //     }
    //     if (res.data.code == 1) {
    //       tant.setData({
    //         venue: true,
    //         venue_case:true
    //       })
    //     } else {
    //       if (res.data.data){
    //         _this.venue_list=res.data.data;
    //       }
    //       tant.setData({
    //         venue_list:_this.venue_list,
    //         venue: false
    //       })
    //     }
    //   }
    // })
    this.brandrequest(_this, util).then((res) => {
      if (res) {
        this.setData({
          display: true
        })
        return util.requestGroups('supp/Supplier/brandShop', { shop_id: util.get('user').shop_id })
      } else {
        util.iconnone('请先创建品牌')
        this.setData({
          display: false
        })
        setTimeout((res) => {
          wx.navigateTo({
            url: '../../user/pages/core/core',
          })
        }, 1500)
      }
    },
      (res) => {
        util.iconnone('网络故障')
      }
    ).then((res)=>{
      if (res.data.is_visible==0){
        util.iconnone('等待品牌审核')
        this.setData({
          display: false
        })
        setTimeout((res) => {
          wx.navigateTo({
            url: '../../user/pages/core/core',
          })
        }, 1500)
      }else{
        wx.showTabBar({
          success:(res)=>{}
        })
        return util.requestGroups('supp/venue/list', data)
      }
    }).then((res) => {
      if (res) {
        if (util.invalid(res.data, util, '../../login/login')) {
          return
        }
        if (res.data.code == 1) {
          tant.setData({
            venue: true,
            venue_case: true
          })
        } else {
          if (res.data.data) {
            _this.venue_list = res.data.data;
          }
          tant.setData({
            venue_list: _this.venue_list,
            venue: false
          })
        }
      }
    })
    wx.hideLoading()
  },
  ordertips: function() {
    util.iconnone('需场馆通过审核')
  },
  coachedit:function(e){
    if (util.get('user').sub_type == '2' || util.get('user').sub_type == '3') {
      util.iconnone('无此权限');
      return;
    }
     wx.navigateTo({
       url: '../../index/pages/coach/coach?venue_id=' + e.currentTarget.dataset.id + '&is_order=' + '1',
     })
  },
  /***编辑场馆信息***/
  bindEdit: function(e) {
    var _this = this.data;
    wx.setStorageSync('whether', '1')
    if (util.get('user').sub_type == '2') {
      util.iconnone('无此权限');
      return;
    }
    if (_this.user.sub_type == '4') {
      wx.navigateTo({
        url: '../../index/pages/coach/coach?venue_id=' + e.currentTarget.dataset.id
      })
    } else {
      wx.navigateTo({
        url: '../../index/pages/venue/venue?venue_id=' + e.currentTarget.dataset.id
      })
    }
  },
  /*添加场馆**/
  addVenue: function() {
    if (!this.data.is_brand) {
      util.iconnone('请先创建品牌')
      setTimeout((res) => {
        wx.switchTab({
          url: '../core/core',
        })
      }, 800)
      return
    }
    if (this.data.first_brand == 0) {
      util.iconnone('请等待品牌审核通过')
      return;
    }
    wx.setStorageSync('whether', '0')
    wx.navigateTo({
      url: '../../index/pages/venue/venue'
    })
  },
  //品牌列表请求
  brandrequest: function(_this, util) {
    var brandlist = new Promise(function(resolve, reject) {
      wx.request({
        url: util.prefixUrl() + 'supp/supplier/brandlist',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          shop_id: util.get('user').shop_id
        },
        success: (res) => {
          if (util.invalid(res.data, util, '../../login/login')) {
            return
          }
          if (res.data.code == 1) {
            resolve(false)
          } else {
            resolve(true)
          }
        },
        fail: (res) => {
          reject("系统异常，请重试！")
        }
      })
    });
    return brandlist;
  },
  /*场地管理*/
  orderedit: function(e) {
    if (util.get('user').sub_type == '2') {
      util.iconnone('无此权限');
      return;
    }
    wx.navigateTo({
      url: '../../index/pages/reserve/reserve?venue_id=' + e.currentTarget.dataset.id + '&is_order=' + '1'
    })
  },
  getUserInfo: function(e) {
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})