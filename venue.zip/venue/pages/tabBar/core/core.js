var util=require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{},
    brandnum:0,
    price:0,
    brand_name:'',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  // 活动
  catactivity:function(){
   util.iconnone('暂未开启,敬请期待')
  },
  modifynav:function(){
  wx.navigateTo({
    url: '../../user/pages/modify/modify',
  })
  },
  walletnav:function(){
    if (util.get('user').sub_type==3){
      util.iconnone('没有提现权限')
     return;
    }
    wx.navigateTo({
      url: '../../user/pages/wallet/wallet',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  calling: function (e) {
    wx.makePhoneCall({
      phoneNumber:'029-928493295',
      success: function () {
        // console.log("拨打电话成功！")
      },
      fail: function () {
        // console.log("拨打电话失败！")
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (util.getcache(util, '../../login/login')){
      this.setData({
        user: util.get('user')
      })
      var infoData={
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: util.get('user').venue_id,
        sub_type: util.get('user').sub_type
      },
      brandData={
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        page_index: 1,
        page_size: 100
      };
      util.requestGroups('supp/supplier/suppInfo', infoData).then(
        (res) => {
          this.setData({
            price: res.data.today,
            brand_name: res.data.brand_name
          })
        }
      )
      util.requestGroups('supp/supplier/brandlist', brandData).then(
        (res) => {
          if (res.data.data) {
            this.setData({
              brandnum: res.data.data.length
            })
          }
        },
        (res) => {
          util.failtips('网络故障')
        }
      )
    }
  },
  mybrandnav:function(){
    if (this.data.user.is_sub==0){
      wx.navigateTo({
        url: '../../user/pages/core/core',
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})