var util = require('../../../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    displays:false,
    imgUrl:'',
    venue_id:0,
    coach_id:0,
    course_id:0,
    course:[], //课程列表
    spec_id:'',
    stencil_id:'',
    scrollX:true,
    activeIndex:0,
    rensum:1,
    startTime:'',
    ifadd:true,
    endTime:'',
    settlement:0,//单价
    navList: [{ 'name': '今天' }, { 'name': '明天' }, { 'name': '后天' }, { 'name': '周六' }, { 'name': '周日' }],
    initial:1,
    hourone:'',
    hourtow: '',
    para_list:[],
    hour: [],
    houreffect: []
  },
  backindexto: function (event) {
    var _this = this.data;
    // 自定义组件触发事件时提供的detail对象，用来获取子组件传递来的数据
    if (event.detail.index == '1') {
      return;
    } else {
      wx.redirectTo({
        url: '../../../index/pages/register/register?coach_id=' + _this.coach_id + "&venue_id=" + _this.venue_id,
      })
    }
  },
  addcourse:function(){
    wx.navigateTo({
      url: '../curriculum/curriculum?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id+'&jump='+'1',
    })
  },
  /*** 生命周期函数--监听页面加载*/
  onLoad: function (options) {
    var _this = this.data,
        tant=this;
    wx.setNavigationBarTitle({
      title: '课时预览'
    })
    this.setData({
      imgUrl: util.imgUrl()
    })
    if (options.index){
      _this.activeIndex = options.index;
    }
    this.setData({
      venue_id: options.venue_id,
      coach_id: options.coach_id
    })
    _this.hour.map((value)=>{
      value['tap'] = false
    })
    var _this = this.data,
      tant = this;
    _this.navList = [];
    var timestamp = (new Date()).getTime() / 1000
    _this.day = util.timestampToTime(timestamp)
    this.setData({
      navList: util.navlist(),
      activeIndex:_this.activeIndex
    })
   
  },
  //课程模板详情
  basicsNav: function (e) {
    var _this = this.data;
    var data = {
      coach_id: _this.coach_id,
      venue_id: _this.venue_id,
      course_id: _this.course_id
    };
    wx.navigateTo({
      url: '../setup/setup?data=' + JSON.stringify(data),
    })
  },
  coursemodify:function(){
      wx.navigateTo({
        url: '../curriculum/curriculum?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.navtap = this.selectComponent("#navtap")
  },
  // 导航
  navscroll:function(e){
    var _this=this.data;
    _this.activeIndex = e.currentTarget.dataset.index
    this.setData({
      activeIndex: _this.activeIndex
    })
    this.stencilUpdate(_this, this, _this.spec_id)
  },
  // 选择时间
  bindselect:function(e){
    var _this=this.data,
        index = e.currentTarget.dataset.index;
    if (_this.hour[index].txt.length > '3' || _this.hour[index].txt=='已有课'){
      util.iconnone('已占用无法修改')
      return;
    }
    _this.hour[index].tap = !_this.hour[index].tap
    this.setData({
      hour: _this.hour
    })
  },
  //时间段选择
  paraSelection: function (e) {
    var _this = this.data
    _this.para_list[e.currentTarget.dataset.index].tap =! _this.para_list[e.currentTarget.dataset.index].tap
    this.setData({
      para_list: _this.para_list
    })
  },
  //课程切换
  coursetap:function(e){
    var _this=this.data;
    if (_this.course_id == e.target.dataset.course) {
       return;
    }
    this.setData({
      course_id:e.target.dataset.course,
      hour:[],
    })
    this.stencilUpdate(_this, this, _this.spec_id)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this.data, tant = this, is_del=false;
    this.setData({
      course:[],
      displays:false,
      para_list: [],
    })
    //课程列表
    util.requestGroups(
      'supp/coach/listCoachStencil',
      {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id
      }
    ).then((res) => {
      _this.course = []
      if (res.data.code == -1) {
        util.invalidNew(util, '../../../login/login')
        return;
      }
      if (res.data.code == 1) {
        util.iconnone(res.data.msg);
      } else {
        let length = res.data.data.length;
        _this.course = res.data.data;
        for (var i = length - 1; i >= 0; i--) {
          if (_this.course[i].course_open == 0) {
             _this.course.splice(i, 1);        //执行后aa.length会减一
            }
          }
        if (res.data.total_count == 0 || _this.course.length==0) {
          _this.initial = true;
        } else {
          _this.initial = false;
        }
        _this.initial ? '' : _this.course_id = _this.course[0].course_id;
        tant.setData({
          initial: _this.initial,
          course: _this.course,
          course_id: _this.course_id,
          displays: true
        })
        if (_this.initial) {
          util.iconnone('暂无课程')
          return;
        }
      }
      //场馆规格
      return util.requestGroups('/supp/venue/spec', {
        venue_id: _this.venue_id,
        userKey: util.get('user').userKey
      });
    }).then((res) => {
      if (res) {
        _this.spec_id = res.data[0].spec_id;
        this.stencilUpdate(_this, this, _this.spec_id)
      }
    })
  //  if(_this.hour.length==0 && _this.course_id!=0){
  //    util.requestGroups('/supp/venue/spec', {
  //      venue_id: _this.venue_id,
  //      userKey: util.get('user').userKey
  //    }).then((res) => {
  //     this.setData({
  //       displays:true
  //     })
  //      _this.spec_id = res.data[0].spec_id;
  //      this.stencilUpdate(_this, this, _this.spec_id)
  //    })
  //  }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    this.setData({
      hour: []
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  //预定支付
  checktap: function () {
    var _this = this.data, ornot = false, list = [];
      _this.hour.map((value) => {
        if (value.tap) {
          ornot = true;
          list.push(value.date)
        }
      })
      if (ornot) {
        wx.navigateTo({
          url: '../setting/setting?hour=' + JSON.stringify(_this.hour) + '&week=' + _this.navList[_this.activeIndex].week + '&venue_id=' + _this.venue_id + '&spec_id=' + _this.spec_id + '&stencil_id=' + _this.stencil_id + '&in_day=' + _this.navList[_this.activeIndex].year + '&coach_id=' + _this.coach_id + '&course_id=' + _this.course_id,
        })
      } else {
        wx.showToast({
          title: '请选择场地',
          icon: 'loading'
        })
        return
    }
  },
  stencilUpdate: function (_this, tant, spec_id){
    wx.request({
      url: util.prefixUrl() +'supp/coach/stencilUpdate',
      method: "POST",
      data: {
        week: _this.navList[_this.activeIndex].week,
        day: _this.navList[_this.activeIndex].year,
        venue_id: _this.venue_id,
        course_id: _this.course_id,
        coach_id: _this.coach_id,
        spec_id:spec_id,
        userKey: util.get('user').userKey,
      },
      success: (res) => {
        _this.para_list = [];
        _this.hour = [];
        if(!res.data.stencilaar){
          util.iconnone('无信息')
          return
        }
        _this.stencil_id = res.data.stencil_id
        res.data.stencilaar.map((value, index) => {
          var initif = ""
          for (let key in value) {
            initif = key
          }
          initif.length > 8 ? _this.initial = '2' : _this.initial = '1';
          if (_this.initial == '2') {
            tant.setData({
              spot: false,
              paragraph: true
            })
            for (let key in value) {
              _this.para_list.push(value[key])
              _this.para_list[index].date = key;
              _this.para_list[index].tap = false;
            }
          } else {
            tant.setData({
              spot: true,
              paragraph: false
            })
            for (let key in value) {
              _this.hour.push(value[key])
              _this.hour[index].date = key;
              _this.hour[index].tap = false;
            }
          }
        })
        _this.hour.map((value) => {
          value['tap'] = false
        })
        tant.setData({
          para_list: _this.para_list,
          hour: _this.hour
        })
      }
    })
  },
  currrequst: function (_this, tant, util) {
    wx.request({
      url: util.prefixUrl() + 'supp/coach/listCoachStencil',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id,
      },
      success: (res) => {
        _this.course = []
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
          return;
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
        } else {

          _this.course = res.data.data;
          if (res.data.total_count != 0) {
            _this.initial = false
          } else {
            _this.initial = true
          }
          tant.setData({
            initial: _this.initial,
            course: _this.course
          })
          console.log(_this.course)
          console.log(_this.initial)
        }
      }
    })
  },
})