var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    coach_id:0,
    venue_id:0,
    dateTime:[],   //当天的时间点
    paragraph: [],  //进度条
    dateArray:[],    
    navDate:[],     //七天日期数组
  },
  //跳转课程预览页面
  catreserve: function (e) {
    var index = e.currentTarget.dataset.index,
      _this = this.data;
    wx.navigateTo({
      url: '../../../coach/pages/reserve/reserve?coach_id=' +_this.coach_id + '&venue_id=' + _this.venue_id + '&index=' + index
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this.data,
        name = options.name;
        wx.setNavigationBarTitle({
          title: name,
        })
    _this.coach_id = options.coach_id;
    _this.venue_id = options.venue_id;
    _this.dateArray = util.navlistCoach()
    _this.dateArray.map((value,index)=>{
      if(index<=2){
        _this.navDate.push(value.name)
      }else{
        _this.navDate.push(value.date)
      }
    })
    this.setData({
      navDate:_this.navDate
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data,
        data={
          shop_id:util.get('user').shop_id,
          venue_id:_this.venue_id,
          coach_id:_this.coach_id,
          userKey:util.get('user').userKey
        };
    util.requestGroups('/supp/Coach/courseforsevenday',data).then((res)=>{
        _this.paragraph = []; 
        _this.dateTime=[];
        var list=[];
        for (var key in res.data) {
          list.push(res.data[key])
        }
        res.data.day0.map((value, index) => {
          _this.dateTime.push(Object.keys(value)[0])
        })
      var available = [];
      _this.dateTime = [];
      if (res.data.day0) {
        res.data.day0.map((value, index) => {
          if (Object.keys(value)[0].substring(3, 5) == '30') {
            available.push(Object.keys(value)[0].substring(0, 2))
          }
        })
        if (available.length >= 10) {
          _this.dateTime.push(available[0])
          available.map((value, index) => {
            if (index % 2 == 0 && (index != 0 && index != available.length - 1)) {
              _this.dateTime.push(value)
            }
          })
          _this.dateTime.push(available[available.length - 1])
        } else {
          _this.dateTime = available
        }
      }
        list.map((value, index)=>{
          _this.paragraph[index]=[];
          value.map((value_sub,index_sub)=>{
            _this.paragraph[index].push(value_sub[Object.keys(value_sub)[0]])
          })
        })
        this.setData({
          paragraph:_this.paragraph,
          dateTime: _this.dateTime
        })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})