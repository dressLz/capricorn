var util = require('../../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    venue_id:0,
    in_day: '',
    spec_id: '',
    week: '',
    stencil_id: '',
    para_list: [],
    array: ['08:00', '09:00', '10:00'],
    course_id:0,
    coach_id:0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      para_list: JSON.parse(options.hour),
      imgUrl: util.imgUrl(),
      venue_id: options.venue_id,
      spec_id: options.spec_id,
      week: options.week,
      stencil_id: options.stencil_id,
      in_day: options.in_day,
      course_id: options.course_id,
      coach_id: options.coach_id,
    })
  },
  bindPickerarray: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
  },
  priceinput: function(e) {
    var _this = this.data;
    e.detail.value = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
    
  },
  priceinputblur: function (e) {
    var _this = this.data,
        value = e.detail.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
        _this.para_list[e.currentTarget.dataset.index].price = parseFloat(value).toFixed(2)
        this.setData({
          para_list: _this.para_list
        })
  },
  numinput: function(e) {
    var _this = this.data;
    _this.para_list[e.currentTarget.dataset.index].num = e.detail.value
  },
  addmodelbtn: function() {
    var _this = this.data;
    var data = {
      hour_minute: '',
      num:'',
      price:'',
      is_open:'',
      in_day: _this.in_day,
      stencil_id: _this.stencil_id,
      venue_id: _this.venue_id,
      spec_id: _this.spec_id,
      week: _this.week,
      operator_id: util.get('user').supplier_id,
      userKey: util.get('user').userKey,
      course_id: _this.course_id,
      coach_id: _this.coach_id,
    }
    this.data.para_list.map((value, index) => {
      if (value.tap) {
        data.hour_minute += value.date + ','
        data.num += value.num + ','
        data.price += value.price + ','
        data.is_open += value.is_open + ','
      }
    })
    wx.request({
      url: util.prefixUrl() +'/supp/coach/stencilUpdateSave',
      method: 'POST',
      data: data,
      success: (res) => {
        if(res.code!='1'){
          wx.navigateBack()
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data;
  },
  switch1Change: function(e) {
    var index = e.target.dataset.index
    var _this = this.data;
    if (e.detail.value) {
      _this.para_list[index].is_open = 1
    } else {
      _this.para_list[index].is_open = 0
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
})