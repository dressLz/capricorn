var util = require('../../../../utils/util.js')
Page({
  /**
   * delBtnWidth: 删除按钮的宽度单位
   * startX: 收支触摸开始滑动的位置
   */
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    coach_id: 0,
    venue_id: 0,
    course: [],
    total_count:0,  //总条数； 
    initial: true,
    delBtnWidth: 150,
    startX: '',
    touchSIndex: 0,
    txtStyle:'',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.data.coach_id = options.coach_id
    this.data.venue_id = options.venue_id
    if(options.jump==1){
      if (util.get('user') == undefined) {
        util.invalidNew(util, '../../../login/login')
        return;
      }
      wx.navigateTo({
        url: '../begoodat/begoodat?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
      })
    }
    this.setData({
      imgUrl: util.imgUrl()
    })
  },
  changepage:function(data){
    var _this = this.data,
      course = '';
    _this.course.map((value, index) => {
      if (value.checked == 1) {
        course += value.course_id + ',';
      }
    })
    course=course + data.course_id+','
    if (course.length == 0) {
      util.iconnone('请选择课程')
      return;
    }
    var data = {
      userKey: util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_id: _this.venue_id,
      operator_id: util.get('user').supplier_id,
      coach_id: _this.coach_id,
      course: course
    }
    wx.request({
      url: util.prefixUrl() + 'supp/coach/addCoachCourse',
      method: 'POST',
      data: data,
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        } else {
          util.iconnone('保存成功')
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  //添加课程
  addcourse: function() {
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    if (this.data.total_count==0){
      wx.navigateTo({
        url: '../begoodat/begoodat?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
      })
    }else{
      wx.navigateTo({
        url: '../modify/begoodat?coach_id=' + this.data.coach_id + '&venue_id=' + this.data.venue_id,
      })
    }
  },
  //时间展示页面
  navreserve: function(e) {
    var _this = this.data;
    var data = {
      coach_id: _this.coach_id,
      venue_id: _this.venue_id,
      course_id: e.currentTarget.dataset.couse
    }
    wx.navigateTo({
      url: '../reserve/reserve?data=' + JSON.stringify(data),
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data, tant=this;
    if (util.get('user') == undefined) {
      util.invalidNew(util, '../../../login/login')
      return;
    }
    this.currrequst(_this, tant, util)
  },
  //课程模板详情
  basicsNav: function(e) {
    var _this = this.data;
    var data = {
      coach_id: _this.coach_id,
      venue_id: _this.venue_id,
      course_id: e.currentTarget.dataset.couse
    }
    wx.navigateTo({
      url: '../setup/setup?data=' + JSON.stringify(data),
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    var _this=this.data,is_del=false;
    _this.course.map((value,index)=>{
      if (value.course_open==0){
          is_del=true
      }
    })
    if (is_del){
      var data={
        venue_id: this.data.venue_id,
        coach_id: this.data.coach_id,
        userKey: util.get('user').userKey,
      };
      util.requestGroups('supp/coach/delCoachCourse', data).then((res)=>{
        console.log(res)
      })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //手指触摸
  touchS: function(e) {
    this.data.touchSIndex = e.currentTarget.dataset.index
    if (e.touches.length == 1) {
      this.setData({
        //设置触摸起始点水平方向位置
        startX: e.touches[0].clientX
      });
    }
  },
  touchM: function(e) {
    if (e.touches.length == 1) {
      //手指移动时水平方向位置
      var moveX = e.touches[0].clientX;
      //手指起始点位置与移动期间的差值
      var disX = this.data.startX - moveX;
      var delBtnWidth = this.data.delBtnWidth;
      var txtStyle = this.data.txtStyle;
      if (disX == 0 || disX < 0) { //如果移动距离小于等于0，说明向右滑动，文本层位置不变
        txtStyle = "left:0rpx";
      } else if (disX > 0) { //移动距离大于0，文本层left值等于手指移动距离
        txtStyle = "left:-" + disX + "rpx";
        if (disX >= delBtnWidth) {
          //控制手指移动距离最大值为删除按钮的宽度
          txtStyle = "left:-" + delBtnWidth + "rpx";
        }
      }
      //获取手指触摸的是哪一项
      this.setData({
        touchSIndex: this.data.touchSIndex,
        txtStyle: txtStyle
      });
    }
  },
  touchE: function(e) {
    if (e.changedTouches.length == 1) {
      //手指移动结束后水平位置
      var endX = e.changedTouches[0].clientX;
      //触摸开始与结束，手指移动的距离
      var disX = this.data.startX - endX;
      var delBtnWidth = this.data.delBtnWidth;
      //如果距离小于删除按钮的1/2，不显示删除按钮
      this.data.txtStyle = disX > delBtnWidth / 2 ? "left:-" + delBtnWidth + "rpx" : "left:0rpx";
      //获取手指触摸的是哪一项
      var index = this.data.touchSIndex
      //更新列表的状态
      this.setData({
        touchSIndex: this.data.touchSIndex,
        txtStyle: this.data.txtStyle
      });
    }
  },
  //删除
  delcourse: function(e) {
    var _this = this.data,tant=this;
    wx.request({
      url: util.prefixUrl() +'supp/coach/coachCourseDelete',
      method: 'POST',
      data: {
        venue_id:_this.venue_id,
        coach_id:_this.coach_id,
        course_id: e.currentTarget.dataset.course,
        userKey: util.get('user').userKey
      },
      success:(res)=>{
        console.log(res)
        if(res.data.code==0){
          util.successtips('删除成功');
          this.setData({
            txtStyle:'',
            touchSIndex:0
          })
          this.currrequst(_this, tant,util)
        }
      }
    })
  },
  //列表
  currrequst: function (_this, tant, util){
    wx.request({
      url: util.prefixUrl() +'supp/coach/listCoachStencil',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        coach_id: _this.coach_id,
      },
      success: (res) => {
        _this.course=[]
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
          return;
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
        } else {
            _this.course = res.data.data;
          _this.total_count = res.data.total_count;
            if (res.data.total_count != 0) {
              _this.initial = false
            }else{
              _this.initial=true
            }
            tant.setData({
              initial: _this.initial,
              course: _this.course
            })
          }
      }
    })
  },
  navbackto:function(){
    wx.navigateBack({
      delta:1
    })
  }
})