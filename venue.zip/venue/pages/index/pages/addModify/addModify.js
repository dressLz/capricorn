var util = require('../../../../utils/util.js');
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    urlImg: '',
    imgUrl: '',
    date: '',
    nature: ['--', '企业', '个体'],
    natureIndex: 0,
    timestap: 0,
    /****图片裁剪******/
    uploadType: 'identity_one', //
    identity_one: 'http://fitness.fengdutiyu.com/public/xcxC/houtai/ID_L.png',
    identity_tow: 'http://fitness.fengdutiyu.com/public/xcxC/houtai/ID_Z.png',
    license: 'http://fitness.fengdutiyu.com/public/xcxC/houtai/new/license.png',
    license_pic: '',
    crad_one: '',
    crad_tow: '',
    prove: '',
    imageFixed: false, //裁剪浮层
    imageSrc: '', //要裁剪的图片
    /***是否填写***/
    venue_id: 0,
    qual_info: {},
    disabled: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      imgUrl: util.imgUrl(),
    })
    var _this = this.data;
    if (options.venue_id) {
      this.data.venue_id = options.venue_id
    }
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() + 'supp/venue/qual',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          _this.qual_info = res.data;
          if (res.data.card_pic.length > 0) {
            this.setData({
              identity_one: res.data.card_pic,
              crad_one: res.data.card_pic
            })
          }
          if (res.data.card_pic1.length > 0) {
            this.setData({
              identity_tow: res.data.card_pic1,
              crad_tow: res.data.card_pic1
            })
          }
          if (res.data.prove_pic.length > 0) {
            this.setData({
              license: res.data.prove_pic,
              license_pic: res.data.prove_pic
            })
          }
          if (res.data.prove_type) {
            _this.natureIndex = res.data.prove_type
          }
          this.setData({
            qual_info: _this.qual_info,
            natureIndex: _this.natureIndex
          })
        }
      })
    }
  },
  //企业性质
  // bindPickernature:function(e){
  //    this.setData({
  //      natureIndex: e.detail.value
  //    })
  // },
  //提交保存
  formSubmit: function(e) {
    var data = e.detail.value,
      submission = true,
      _this = this.data;
    data.userKey = util.get('user').userKey
    data.shop_id = util.get('user').shop_id
    data.operator_id = util.get('user').supplier_id
    data.venue_id = _this.venue_id;
    data.is_order = 0;
    if (submission) {
      wx.showLoading({
        mask: true
      })
      var url = "";
      if (this.data.qual_info.is_order_a == '1') {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      wx.request({
        url: util.prefixUrl() + url,
        method: 'POST',
        data: data,
        success: (res) => {
          if (res.data.code == 0) {
            util.iconnone('保存成功')
            wx.navigateBack({})
          }
        },
        fail: (res) => {
          console.log(res)
        },
        complete: () => {
          wx.hideLoading({})
        }
      })
    }
  },
  //有效期
  changeDate(e) {
    var _this = this.data,
      timestap = 0;
    wx.getSystemInfo({
      success: (res) => {
        if (res.platform == "ios") {
          timestap = new Date((e.detail.value + ' ' + '00:00:00').replace(/-/g, '/')).getTime()
        } else {
          timestap = new Date(e.detail.value + ' ' + '00:00:00').getTime();
        }
      }
    })
    this.setData({
      date: e.detail.value,
      timestap: timestap / 1000
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data,
      tant = this;
    if (_this.urlImg.length > 0) {
      this.ossrequest(tant, _this.urlImg)
      this.setData({
        urlImg: ''
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  changeDate(e) {
    var _this = this.data,
      timestap = 0;
    wx.getSystemInfo({
      success: (res) => {
        if (res.platform == "ios") {
          timestap = new Date((e.detail.value + ' ' + '00:00:00').replace(/-/g, '/')).getTime()
        } else {
          timestap = new Date(e.detail.value + ' ' + '00:00:00').getTime();
        }
      }
    })
    this.setData({
      date: e.detail.value,
      timestap: timestap / 1000
    });
  },
  eliminateImg: function() {
    this.setData({
      imageFixed: false
    })
  },
  ossrequest: function(_this, photo) {
    wx.showLoading({
      title: '上传中...',
      mask: true,
    })
    wx.request({
      url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey
      },
      success: (res) => {
        var myDate = new Date()
        var pathArr = photo.split('.')
        //  随机生成文件名称
        var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + Date.now() + "" + parseInt(Math.random() * 1000)
        var fileName = fileRandName + '.' + pathArr[pathArr.length - 1]
        // 要提交的key
        var fileKey = fileName
        var url = res.data.host
        wx.uploadFile({
          url: url,
          filePath: photo,
          name: 'file',
          formData: {
            name: photo,
            key: fileKey,
            policy: res.data.policy,
            OSSAccessKeyId: res.data.accessid,
            signature: res.data.signature,
            success_action_status: "200"
          },
          success: function(res) {
            if (_this.data.uploadType == 'identity_one') {
              _this.setData({
                identity_one: url + '/' + fileKey,
                crad_one: url + '/' + fileKey
              })
            } else if (_this.data.uploadType == 'identity_tow') {
              _this.setData({
                identity_tow: url + '/' + fileKey,
                crad_tow: url + '/' + fileKey,
              })
            } else if (_this.data.uploadType == 'license') {
              _this.setData({
                license: url + '/' + fileKey,
                license_pic: url + '/' + fileKey,
              })
            }
            wx.hideLoading()
          },
          fail: (res) => {
            util.failtips('网络故障')
          }
        })
      }
    })
  },
  bindChooseType(e) { //选择相机还是相册
    var demo = this,
      _this = this.data;
    _this.uploadType = e.currentTarget.dataset.type;
    if (_this.uploadType == 'license') {
      var data = {
          width: 375,
          height: 555,
        },
        proportion = 0.675675675
    } else {
      var data = {
          width: 375,
          height: 262.9,
        },
        proportion = 1.426
    }
    this.setData({
      urlImg: ''
    })
    wx.navigateTo({
      url: '../../../cutFace/index?cuttype=1&proportion=' + proportion,
    })
  },
})