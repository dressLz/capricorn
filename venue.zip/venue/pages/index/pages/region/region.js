var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    venue_id:'',
    regionOriginal: [[],[],[]],
    region: [['-'], ['-'], ['-']],
    region_index: [0, 0, 0],  //城市选择的下标
    venun_address:'',
    province_id:'',
    city_id:'',
    district_id:'',
    region_id: { province_id: '', city_id: '', district_id:''},
    venue_info:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this.data;
    _this.venue_id = options.venue_id;
    this.setData({
      imgUrl: util.imgUrl(),
    })
    this.province(this)     //省市区
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() + 'supp/venue/venueInfo',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          this.setData({
            venue_info: res.data,
            province_id: res.data.province_id,
            city_id: res.data.city_id,
            district_id: res.data.district_id,
            venun_address: res.data.venun_address
          })
          this.province(this)
        }
      })
    }
  },
  /****/
  textareainput:function(e){
    this.data.venun_address = e.detail.value
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  rendering: function (regionOriginal, _this, tant) {
    _this.region_index
    _this.province_id
    _this.city_id
    _this.district_id
    regionOriginal[0].map((value, index) => {
      if (value.province_id == _this.province_id) {
        _this.region_index[0] = index
      }
    })
    regionOriginal[1].map((value, index) => {
      if (value.city_id == _this.city_id) {
        _this.region_index[1] = index
      }
    })
    regionOriginal[2].map((value, index) => {
      if (value.district_id == _this.district_id) {
        _this.region_index[2] = index
      }
    })
    tant.setData({
      region_index: _this.region_index
    })
  },
  // 选择省市区函数
  changeRegin(e) {
    this.setData({
      region_index: e.detail.value
    })
  },
  columnregin: function (e) {
    if (e.detail.column == 0) {
      this.data.regionOriginal[0][e.detail.value].province_id
      this.city(this, this.data.regionOriginal[0][e.detail.value].province_id, this.data)
    } else if (e.detail.column == 1) {
      this.area(this, this.data.regionOriginal[1][e.detail.value].city_id, this.data)
    }
  },
  province: function (tant) {
    var _this = this.data;
    //省市区
    wx.request({
      url: util.prefixUrl() +'supp/venue/getprovincelist',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey
      },
      success: (res) => {
        _this.regionOriginal[0] = res.data
        _this.regionOriginal[0].map((value, index) => {
          _this.region[0][index] = value.province_name
        })
        tant.setData({
          region: _this.region
        })
        tant.city(tant, _this.regionOriginal[0][0].province_id, _this)
      }
    })
  },
  city: function (tant, province_id, _this) {
    wx.request({
      url: util.prefixUrl() +'supp/venue/getcitylist',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        province_id: province_id
      },
      success: (res) => {
        _this.regionOriginal[1] = res.data
        _this.regionOriginal[1].map((value, index) => {
          _this.region[1][index] = value.city_name
        })
        tant.setData({
          region: _this.region
        })
        tant.area(tant, _this.regionOriginal[1][0].city_id, _this)
      }
    })
  },
  area: function (tant, city_id, _this) {
    wx.request({
      url: util.prefixUrl() +'supp/venue/getdistrictlist',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        city_id: city_id
      },
      success: (res) => {
        _this.regionOriginal[2] = res.data
        _this.regionOriginal[2].map((value, index) => {
        _this.region[2][index] = value.district_name
        })
        tant.setData({
          region: _this.region
        })
        tant.rendering(_this.regionOriginal, _this, tant)
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  regionnav:function(){
    var _this=this.data
    if (!util.getcache(util, '../../../login/login')) {
      return;
    }
    var url = "";
    if (this.data.venue_info.is_order_a == '1') {
      url = "supp/venue/updateVenue";
    } else {
      url = 'supp/venue/modify';
    }
    wx.request({
      url: util.prefixUrl() +url,
      method: 'POST',
      data: {
        userKey : util.get('user').userKey,
        shop_id : util.get('user').shop_id,
        venue_id: _this.venue_id,
        operator_id :util.get('user').supplier_id,
        province_id : _this.regionOriginal[0][_this.region_index[0]].province_id,
        city_id : _this.regionOriginal[1][_this.region_index[1]].city_id,
        district_id : _this.regionOriginal[2][_this.region_index[2]].district_id,
        venun_address: _this.venun_address.replace(/\s*/g, ""),
        is_order:0,
      },
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        }
        if (res.data.code == 0) {
          util.iconnone('操作成功');
          setTimeout(() => { wx.navigateBack({}) }, 1000)
        }
      }
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})