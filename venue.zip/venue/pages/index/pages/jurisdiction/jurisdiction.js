var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sub_type: 0,
    venue_id: 0,
    list: [],
    textList: ['所属场馆用户入场订单…', '所属场馆基本信息维护…', '教练信息管理、私教订单…'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.data.venue_id = options.venue_id
    if (options.sub_type) {
      this.data.sub_type = options.sub_type;
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data,
      data = {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        venue_id: _this.venue_id
      }
    util.requestGroups('supp/venue/subTypeList', data).then(
      (res) => {
        res.data.map((value, index) => {
          if (_this.sub_type != 0 && value.sub_type_id == _this.sub_type) {
            value.active = true
          } else {
            value.active = false
          }
        })
        this.setData({
          list: res.data
        })
      }
    )
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  catchtaptype: function(e) {
    var index = e.currentTarget.dataset.index,
      pages = getCurrentPages(),
      _this = this.data,
      value = e.currentTarget.dataset.value;
    if (index == 0 || index == 1) {
      if (value == 1) {
        util.iconnone('已有该账号')
        return
      }
    }
    _this.list.map((value, inx) => {
      if (inx == index) {
        value.active = true;
      } else {
        value.active = false;
      }
    })
    this.setData({
      list: _this.list
    })
    wx.showToast({
      title: _this.list[index].sub_type_name,
      mask: true,
      duration: 600
    })
    setTimeout(() => {
      wx.redirectTo({
        url: '../addsub/subaccount?venue_id=' + this.data.venue_id + '&type=' + JSON.stringify(this.data.list[index]),
      })
    }, 600)
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    console.log('返回')
    var pages = getCurrentPages(); // 获取页面栈
    if (pages.length > 1) {
      //上一个页面实例对象
      var prePage = pages[pages.length - 2];
      prePage.setData({
        //直接给上一个页面赋值
        negative: 1
      });
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  navfunction: function(e) {
    wx.navigateTo({
      url: '../function/function?id=' + e.target.dataset.id,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})