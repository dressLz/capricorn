var util = require('../../../../utils/util.js')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    venue_id:'',
    videoinfo:{},
    video_title:'',
    video_attr:'',
    coach_id:'',
    video_id:0,
    videoArray:[{'src':''}],   //视频数组
    brand:[],
    brandList:[],
    brandIndex:0,
    videoSrc:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.video_id != 'undefined')
    if (options.video_id != 'undefined'){
     this.setData({
       video_id: options.video_id,
     })
    }
    this.setData({
      coach_id: options.coach_id,
      venue_id: options.venue_id,
      imgUrl: util.imgUrl(),
    })
  },
  //brandpicker
  brandpicker:function(e){
    this.setData({
      brandIndex: e.detail.value
    })
   this.data.video_attr = this.data.brandList[this.data.brandIndex].attr_id
  },
  //视频标签输入
  coachNamechang:function(e){
     this.data.video_title=e.detail.value
  },
  //删除视频
  closeVideo:function(){
     var _this=this.data;
     wx.request({
       url: util.prefixUrl() + 'supp/video/deleteVideo',
       method:'POST',
       data:{
         video_id:_this.video_id,
         operator_id: util.get('user').supplier_id,
         userKey:util.get('user').userKey
       },
       success:(res)=>{
         if(res.data.code==0){
           util.iconnone('删除成功')
           _this.videoSrc=""
           this.setData({
             videoSrc:_this.videoSrc
           })
         }
       }
     })
  },
  //视频上传
  chooseVideo: function (e) {
    var that = this.data,thisa=this;
    // if (that.video_title.replace(/\s/g, "").length==0){
    //   util.iconnone('请按顺序填写')
    //   return;
    // }
    wx.chooseVideo({
      success: (res) => {
        that.videoSrc = res.tempFilePath
        console.log('初次选择' + res.tempFilePath)
        if (res.duration>30){
          util.iconnone('时长最大30秒')
          return;
        }
        wx.showLoading({
          title: '上传中....',
          mask:true
        })
        wx.request({
          url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
          method: 'POST',
          data: {
            userKey: util.get('user').userKey
          },
          success: (res) => {
            var myDate = new Date()
            //  随机生成文件名称
            var pathArr = that.videoSrc.split('.');
            console.log('pathArr' + pathArr)
            var picname = Date.now() + "" + parseInt(Math.random() * 1000)
            var fileRandName = 'upload/venue_video/' + util.get('user').shop_id + '/' + that.venue_id + '/' +that.coach_id+'/'+ picname
            var fileName = fileRandName + '.' + pathArr[pathArr.length-1]
            var pic_name = picname + '.' + pathArr[pathArr.length-1]
            // 要提交的key
            var fileKey = fileName
            var url = res.data.host
            wx.uploadFile({
              url: url,
              filePath: that.videoSrc,
              name: 'file',
              formData: {
                name: that.videoSrc,
                key: fileKey,
                policy: res.data.policy,
                OSSAccessKeyId: res.data.accessid,
                signature: res.data.signature,
                success_action_status: "200"
              },
              
              success: (res) => {
                // var str = url + '/' + fileKey
                var str = fileKey;
                console.log(url + '/' + fileKey)
                // if (str.substring(str.lastIndexOf('.') + 1, str.length).toLowerCase() == 'mov') {
                    wx.request({
                      url: 'https://fitness.fengdutiyu.com/supp/base/transVideo',
                      method:'POST',
                      data:{
                        userKey:util.get('user').userKey,
                        object: str
                      },
                      success:(res)=>{
                        wx.hideLoading()
                        thisa.setData({
                          videoSrc: url + '/'+ str.substring(0, str.lastIndexOf('.') + 1) + 'mp4'
                        })
                      }
                    })
                // }else{
                //   wx.hideLoading()
                //   this.setData({
                //     videoSrc: url + '/' + str
                //   })
                //   console.log(url + '/' + str)
                // }
              }, fail: (res) => {
                util.failtips('网络故障')
              }
            })
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    if (_this.video_id!=''){
      wx.request({
        url: util.prefixUrl() +'supp/video/info',
        method:'POST',
        data:{
          userKey: util.get('user').userKey,
          video_id: _this.video_id
        },
        success:(res)=>{
          wx.request({
            url: util.prefixUrl() +'supp/video/attrList',
            method: 'POST',
            data: {
              userKey: util.get('user').userKey
            },
            success: (res) => {
              _this.brand = []; _this.brandList = []
              _this.brandList = res.data.data
              res.data.data.map((value, index) => {
                _this.brand.push(value.attr_name)
              })
              console.log(_this.brandList[_this.brandIndex].attr_id)
              _this.video_attr = _this.brandList[_this.brandIndex].attr_id
              this.setData({
                brand: _this.brand,
                brandIndex: _this.brandIndex,
              })
            }
          })
          res.data.attr_list.map((value,index)=>{
            if (value.checked==1){
              _this.brandIndex=index;
            }
          })
          this.setData({
            videoinfo: res.data,
            videoSrc: res.data.video_url,
            brandIndex: _this.brandIndex,
            video_title:res.data.video_name
          })
        }
      })
    }
    if (_this.video_id == ''){
      if (util.getcache(util, '../../../login/login')) {
        wx.request({
          url: util.prefixUrl() +'supp/video/attrList',
          method: 'POST',
          data: {
            userKey: util.get('user').userKey
          },
          success: (res) => {
            _this.brand = []; _this.brandList = []
            _this.brandList = res.data.data
            _this.video_attr = _this.brandList[0].attr_id
            res.data.data.map((value, index) => {
              _this.brand.push(value.attr_name)
            })
            this.setData({
              brand: _this.brand
            })
          }
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  videoRequst: function (that, video_url, venue_id){
   var video_pic=video_url + '?x-oss-process=video/snapshot,t_3000,f_jpg,w_0,h_0,m_fast';
    console.log(video_pic)
    video_pic=video_pic.replace(/\s*/g, "");
    wx.request({
      url: util.prefixUrl() +'supp/video/add',
      method:'POST',
      data:{
        venue_id: venue_id,
        userKey:util.get('user').userKey,
        video_attr: that.video_attr,
        video_name:that.video_title,
        coach_id: that.coach_id,
        video_id: that.video_id,
        shop_id: util.get('user').shop_id,
        operator_id:util.get('user').supplier_id,
        video_url: video_url,
        video_pic: video_pic,
        is_visible:3,
      },
      success:(res)=>{
        if(res.data.code==0){
         util.iconnone('成功')
         setTimeout(()=>{
           wx.navigateBack({})
         },1000)
        }
      }
    })
  },
  preservation:function(){
    if (this.data.videoSrc.replace(/\s/g, "").length == 0){
      util.iconnone('请上传视频')
      return;
    } else if (this.data.video_title.replace(/\s/g, "").length == 0){
      util.iconnone('请填写标题') 
      return;
    }
    this.videoRequst(this.data,this.data.videoSrc,this.data.venue_id)
  }
})