var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    venue_id:'',
    serviceList:[],
    venue_info:{}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.venue_id=options.venue_id;
    this.data.venue_info = JSON.parse(options.venue_info)
  },
  edit_nav_bottom:function(){
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /****/ 
  venueAttr:function(e){
    var _this=this.data;
    _this.serviceList.map((value,index)=>{
      if (e.currentTarget.dataset.index==index){
          value.checked == 1 ? value.checked = 0 : value.checked=1;
        }
    })
    this.setData({
      serviceList:_this.serviceList
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/venue/attrInfo',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          venue_id: _this.venue_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          this.setData({
            serviceList: res.data
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  serviceattr:function(){
    var venue_attr = "", _this = this.data;
    _this.serviceList.map((value, index) => {
      if (value.checked == 1) {
        venue_attr += value.attr_id + ','
      }
    })
    if (util.getcache(util, '../../../login/login')) {
      var data = {};
      data.attr = venue_attr;
      data.venue_id = _this.venue_id
      data.shop_id = util.get('user').shop_id
      data.operator_id = util.get('user').supplier_id
      data.userKey = util.get("user").userKey
      data.is_order=0
      var url = "";
      if (this.data.venue_info.is_order_a == '1') {
        url = "supp/venue/updateVenue";
      } else {
        url = 'supp/venue/modify';
      }
      wx.request({
        url: util.prefixUrl() +url,
        method: 'POST',
        data: data,
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          if (res.data.code == 0) {
            util.iconnone('保存成功')
            setTimeout(()=>{
              wx.navigateBack({ })
            },1000)
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})