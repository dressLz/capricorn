var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:'',
    description:'',
    venue_id:0,
    coach_id:0,
    sum:0,
    coach_name:'',
    coach_sex:0,
    coach_info:{}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pagevalue = JSON.parse(options.data)
    this.setData({
      imgUrl: util.imgUrl(),
    })
    var _this=this.data
    _this.venue_id = pagevalue.venue_id
    _this.coach_id = pagevalue.coach_id
    _this.coach_name = pagevalue.coach_name
    _this.coach_sex = pagevalue.coach_sex
    if (util.getcache(util, '../../../login/login')) {
      if (_this.coach_id != 0) {
        wx.request({
          url: util.prefixUrl() + 'supp/coach/info',
          method: 'POST',
          data: {
            userKey: util.get('user').userKey,
            coach_id: _this.coach_id
          },
          success: (res) => {
            this.setData({
              coach_info:res.data,
              description: res.data.description
            })
          }
        })
      }
    }
  },
  textareawatch:function(e){  //监听输入
    if (e.detail.value.length > 150) {
      this.data.description = e.detail.value.substring(0, 149);
    } else {
      this.data.description = e.detail.value;
    }
    this.setData({
      description: this.data.description,
      sum: this.data.description.length
    })
  },
  briefrequst:function(){
    var _this=this.data;
    if (!util.getcache(util, '../../../login/login')) {
      return;
    }
    if (_this.description.replace(/(^\s*)|(\s*$)/g, "").length == 0){
      util.iconnone('内容不能为空')
      return;
    }
    var data={
      userKey: util.get('user').userKey,
      shop_id: util.get('user').shop_id,
      venue_id: _this.venue_id,
      operator_id:util.get('user').supplier_id,
      coach_id: _this.coach_id,
      description: _this.description,
      is_visible:0
    }
    var url = "";
    if (this.data.coach_info.is_visible_a == '1') {
      url = 'supp/coach/updateCoach'
    } else {
      url = 'supp/coach/add';
    }
    wx.request({
      url: util.prefixUrl() + url,
      method: 'POST',
      data: data,
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        }else{
          util.iconnone('保存成功')
          setTimeout(()=>{
            let pages = getCurrentPages();
            let prevPage = pages[pages.length - 2];
            prevPage.setData({
              coach_id: res.data.coach_id,
            })
            wx.navigateBack({
              delta: 1,
            })
          },1000)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})