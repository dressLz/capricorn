var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    displays:false,
    negative:0,
    imgUrl: '',
    account:true,
    venue_id:'',
    accountList:[],
    operateList:[], //运营
    coachList:[],
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.venue_id = options.venue_id;
    this.setData({
      imgUrl: util.imgUrl(),
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  //跳转添加子账号
  addsubnav: function (e) {
    var _this = this.data, url = "";
    if (e.currentTarget.dataset.supplierid){
      wx.navigateTo({
        url: '../addsub/subaccount?venue_id=' + this.data.venue_id + '&supplier_id=' + e.currentTarget.dataset.supplierid,
      }) 
    }else{
      wx.navigateTo({
        url: '../jurisdiction/jurisdiction?venue_id=' + this.data.venue_id
      })
    }
  },
  navJurisdiction:function(){
   wx.navigateTo({
     url: '../jurisdiction/jurisdiction',
   })
 },
  wxswitchinput:function(e){
      console.log(e)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this=this.data;
    if (!util.getcache(util,'../../../login/login')){
       return;  
    }
    wx.request({
      url: util.prefixUrl() +'supp/venue/subSupplierlist',
      method:'POST',
      data:{
        shop_id: util.get('user').shop_id,
        venue_id: _this.venue_id,
        userKey: util.get('user').userKey,
      },
      success:(res)=>{
        res.data.map((value,index)=>{
          if (value.data.length==1){
           _this.account=false
          }
        })
        if (_this.account){
          this.setData({
            account: _this.account
          })
          if(_this.negative==0){
            wx.navigateTo({
              url: '../jurisdiction/jurisdiction?venue_id=' + this.data.venue_id
            })
          }else{
            this.setData({ displays: true })
          }
        }else{
          this.setData({
            displays:true,
            account: _this.account,
            accountList: res.data[2].data,
            operateList: res.data[0].data,
            coachList: res.data[1].data,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})