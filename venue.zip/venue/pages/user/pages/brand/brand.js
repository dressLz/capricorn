var util = require('../../../../utils/util.js')
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    first_brand:0,
    urlImg:'',  //接受裁剪过的图片
    imgUrl:'',
    date:'未知',
    is_visible:0,  //btn初始状态
    disabled:false,
    timestap:0,   //时间戳
    /*****************/ 
    state:'',
    brand_name:'',
    brand_id:0,
    formData:{},
    brand_name_num:0,
    btntext: '提交',
    uploadType: '',
    name: '',
    // _________________
    imageNum:'', //上传的图片id
    headImg: '', //头像上传
    prove: '',
    ewmImg: '', //二维码上传
    imageFixed: false, //裁剪浮层
    imageSrc: '', //要裁剪的图片
    returnImage: '',
    statEnd:'',
    // 审核人资料
    identity_one: 'http://fitness.fengdutiyu.com/public/xcxC/houtai/ID_L.png',
    identity_tow: 'http://fitness.fengdutiyu.com/public/xcxC/houtai/ID_Z.png',
    crad_one: '',
    crad_tow: '',
  },
  changeDate(e) {
    var _this = this.data, timestap=0;
    wx.getSystemInfo({
      success:(res)=>{
        if (res.platform == "ios") {
          timestap = new Date((e.detail.value + ' ' + '00:00:00').replace(/-/g, '/')).getTime()
        } else{
          timestap = new Date(e.detail.value + ' ' + '00:00:00').getTime();
        }
      }
    })
    this.setData({ 
      date: e.detail.value,
      timestap:timestap/1000
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this = this.data, tant = this;
    this.setData({
      statEnd: util.timestampToTime((new Date()).getTime() / 1000)
    })
    this.setData({
      imgUrl: util.imgUrl(),
    })
    if (options.brand_id == undefined) {
      this.setData({
        btntext: '提交',
      })
      wx.setNavigationBarTitle({
        title: '创建品牌'
      })
    } else {
      this.setData({
        btntext: '修改',
        brand_id: options.brand_id
      })
      wx.setNavigationBarTitle({
        title: '品牌详情'
      })
    }
    if (_this.urlImg.length > 0) {
      this.ossrequest(tant, _this.urlImg)
      this.setData({
        urlImg: ''
      })
    }
    let data={
      shop_id: util.get('user').shop_id
    };
    util.requestGroups('supp/Supplier/brandShop', data).then(
      (res)=>{
          this.setData({
            first_brand: res.data.is_visible
          })
      }
    )
    if (util.getcache(util, '../../login/login') && _this.brand_id != 0) {
      let data = {
        userKey: util.get('user').userKey,
        brand_id: _this.brand_id
      }
      util.requestGroups('supp/supplier/brandinfo', data).then(
        (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login');
          } else {
            if (res.data.end_time != 0) {
              this.data.date = util.timestampToTime(res.data.end_time)
            }
            if (res.data.card_pic){
              this.setData({
                crad_one: res.data.card_pic,
                crad_tow: res.data.card_pic1,
                identity_one: res.data.card_pic,
                identity_tow: res.data.card_pic1,
              })
            }
            this.setData({
              formData: res.data,
              headImg: res.data.pic,
              prove: res.data.prove_pic,
              date: _this.date,
              is_visible: res.data.is_visible,
            })
          }
        }
      )
    }
  },
  //监听品牌名输入
  watchbrand:function(e){
    this.data.brand_name=e.detail.value
  },
  //品牌名检测
  testingbrand:function(e){
    wx.request({
      url: 'https://fitness.fengdutiyu.com//supp/supplier/brandName',
      method:'POST',
      data:{
        userKey:util.get('user').userKey,
        brand_name: this.data.brand_name
      },
      success:(res)=>{
        if (res.data.code==0){
          this.data.brand_name_num=1
         }
      }
    })
  },
  /**生命周期函数--监听页面初次渲染完成**/
  onReady: function() {
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var _this = this.data, tant = this;
    console.log(_this.urlImg)
    if (_this.urlImg.length > 0) {
      this.ossrequest(tant, _this.urlImg)
      this.setData({
        urlImg: ''
      })
    }
  },
  formSubmit(e) {
    var data = e.detail.value,_this=this.data;
    data.userKey = util.get('user').userKey;
    data.shop_id = util.get('user').shop_id;
    data.brand_id=_this.brand_id;
    data.operator_id = util.get('user').supplier_id;
    data.is_visible=3;
    console.log(data)
    if (data.brand_name.replace(/\s*/g, "").length==0){
      util.iconnone('请填写品牌名称')
      return;
    } else if (_this.headImg.replace(/\s*/g, "")==''){
      util.iconnone('请填上传品牌logo')
      return;
    } 
    else if (_this.brand_name_num == 1 && data.prove_pic.length == 0) {
      util.iconnone('请填证明图片')
      return;
    }
    if (_this.first_brand=='0'){
      if (data.card_pic.length == 0 || data.card_pic1.length == 0) {
        util.iconnone('请上传身份证照片')
        return;
      }
    }
    wx.showLoading({
      mask: true
    })
    if (util.getcache(util,'../../../login/login')){
      var url="";
      if (_this.first_brand==0) {
        if(_this.brand_id==0){
          url = "supp/Supplier/addbrandForOne"
        }else{
          url = "supp/Supplier/updatebrandForOne"
        }
      }else{
        // if (_this.brand_id == 0) {
        //   url = 'supp/supplier/addbrand'
        // } else {
        //   url = "supp/Supplier/updatebrandForOne"
        // }
        url = 'supp/supplier/addbrand'
      }
      util.requestGroups(url, data).then(
        (res) => {
          if(res.data.code==-1){
            util.invalidNew(util,'../../../login/login')
          }else if (res.data.code == 0) {
            util.iconnone('创建成功')
            wx.navigateBack({})
          }
          wx.hideLoading({})
        },
        (fail)=>{
          util.iconnone('网络故障');
          wx.hideLoading({})
        }
      )
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  //品牌详情
  branddetails:function(){
    
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
  },
  ossrequest: function (_this,photo){
    wx.showLoading({
      title: '上传中...',
      mask:true,
    })
   wx.request({
     url: 'https://fitness.fengdutiyu.com/supp/base/getOssSign',
     method: 'POST',
     data: {
       userKey: util.get('user').userKey
     },
     success: (res) => {
       var myDate = new Date()
       var pathArr = _this.data.headImg.split('.')
       //  随机生成文件名称
       var fileRandName = 'upload/venue/' + util.get('user').shop_id + '/' + Date.now() + "" + parseInt(Math.random() * 1000)
       var fileName = fileRandName + '.' + pathArr[3]
       // 要提交的key
       var fileKey = fileName
       var url = res.data.host
       wx.uploadFile({
         url: url,
         filePath: photo,
         name: 'file',
         formData: {
           name: photo,
           key: fileKey,
           policy: res.data.policy,
           OSSAccessKeyId: res.data.accessid,
           signature: res.data.signature,
           success_action_status: "200"
         },
         success: function (res) {
           if (_this.data.uploadType == 'logo'){
             _this.setData({
               headImg: url + '/' + fileKey
             })
           } if (_this.data.uploadType == 'identity_one') {
             _this.setData({
               identity_one: url + '/' + fileKey,
               crad_one: url + '/' + fileKey
             })
           } else if (_this.data.uploadType == 'identity_tow') {
             _this.setData({
               identity_tow: url + '/' + fileKey,
               crad_tow: url + '/' + fileKey,
             })
           }else {
             _this.setData({
               prove: url + '/' + fileKey
             })
           }
           wx.hideLoading({})
         }, fail: (res) => {
           util.failtips('网络故障')
         }
       })
     }
   })
  },
  bindChooseType(e) {//选择相机还是相册
    var demo = this,_this=this.data;
    _this.uploadType = e.currentTarget.dataset.type;
    if (_this.uploadType == 'logo') {
      var data = {
        width: 375,
        height: 375,
      },
        proportion = 1;
    } else {
      var data = {
        width: 375,
        height: 262.9,
      },
        proportion = 1.426
    }
    wx.navigateTo({
      url: '../../../cutFace/index?cuttype=1&proportion=' + proportion,
    })
  },
})
