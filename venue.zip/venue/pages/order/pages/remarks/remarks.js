var util = require('../../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    remarks: '',
    order_id: 0,
    sum:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      order_id: options.order_id
    })
  },
  textareawatch: function (e) {
    if (e.detail.value.length > 150) {
      this.data.remarks = e.detail.value.substring(0, 149);
    } else {
      this.data.remarks = e.detail.value;
    }
    this.setData({
      remarks:this.data.remarks,
      sum: this.data.remarks.length
    })
  },
  briefrequst: function () {
    var _this = this.data;
    if (!util.getcache(util, '../../../login/login')) {
      return;
    }
    if (_this.remarks.length == 0) {
      util.iconnone('内容不能为空')
      return;
    }
    wx.request({
      url: util.prefixUrl() +'supp/order/remarks',
      method: 'POST',
      data: {
        userKey: util.get('user').userKey,
        shop_id: util.get('user').shop_id,
        order_id: _this.order_id,
        remarks: _this.remarks
      },
      success: (res) => {
        if (res.data.code == -1) {
          util.invalidNew(util, '../../../login/login')
        }
        if (res.data.code == 1) {
          util.iconnone(res.data.msg);
          return;
        }
        if (res.data.code == 0) {
          util.iconnone('操作成功');
          setTimeout(() => { wx.navigateBack({}) }, 1000)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this.data;
    if (util.getcache(util, '../../../login/login')) {
      wx.request({
        url: util.prefixUrl() +'supp/order/info',
        method: 'POST',
        data: {
          userKey: util.get('user').userKey,
          order_id: _this.order_id
        },
        success: (res) => {
          if (res.data.code == -1) {
            util.invalidNew(util, '../../../login/login')
            return;
          }
          this.setData({
            remarks: res.data.remarks,
            sum:res.data.remarks.length
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})