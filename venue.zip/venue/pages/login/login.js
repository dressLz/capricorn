var util = require('../../utils/util.js');
var timer;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',
    accountArray: [],
    login: true,
    modify: false,
    register: false,
    forgetaccount:false,
    countdown: 60,
    countdown_state: false,
    accountinput:true,  //查询遗忘账号
    obtain: '获取验证码',
    account: '', //账号
    account_focus: false,
    phone: '', //手机号码
    phone_focus: false,
    codekey_focus: false,
    password: '', //密码
    password_confirm:'',  //确认密码
    codekey: '', //验证码
    login_page: false, //是否显示,跳转
    accactive:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (!util.get('user')) {
      this.setData({
        login_page: true
      })
    } else {
      wx.reLaunch({
        url: '../tabBar/index/index',
      })
    }
    this.setData({
      imgUrl: util.imgUrl(),
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},
  /**获取验证码**/
  obtaintap: function() {
    var patrn = /^[0-9]*$/;
    if (this.data.phone.length == 0) {
      wx.showToast({
        title: '请输入号码',
        image: '../image/error.png',
        duration: 1000,
        mask: true,
        success: () => {},
        complete: () => {
        }
      })
      return;
    } else if (this.data.phone.length < 11 || !patrn.test(this.data.phone)) {
      wx.showToast({
        title: '号码有误',
        image: '../image/error.png',
        duration: 1000,
        mask: true,
        success: () => {},
        complete: () => {
        }
      })
      return;
    }
    this.setData({
      countdown_state: true
    })
    var countdown = 60;
    this.settime(countdown, this)
    wx.request({
      url: util.prefixUrl() +'supp/supplier/sendBindCode',
      method: 'POST',
      data: {
        tel: this.data.phone
      },
      success: (res) => {
        if (res.data.code == 0){
          util.iconnone('发送成功')
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  /****输入监听*****/
  inputaccount: function(e) {
    this.data.account = e.detail.value
  },
  /********账号验证*******/
  bluraccount: function(e) {
    if (!util.checkaccount(this.data.account) && this.data.account.length != 0) {
      if (this.data.account.length<6){
        wx.showToast({
          title: '账号不少于6位',
          icon: 'none',
          duration: 1000,
          mask: true,
          success: () => {
          },
          complete: () => {
          }
        })
      }else{
        wx.showToast({
          title: '账号不能包含特殊字符',
          icon: 'none',
          duration: 1000,
          mask: true,
          success: () => {
            this.setData({
              account: ""
            })
          },
          complete: () => {
          }
        })
      }
    } else if (this.data.account.length == 0){
      
    }else {
      wx.request({
        url: util.prefixUrl() +'supp/supplier/check',
        method: 'POST',
        data: {
          username: this.data.account
        },
        success: (res) => {
          if (res.data.code == '1') {
            wx.showToast({
              title: '账号已占用',
              image: '../image/error.png',
              duration: 1000,
              mask: true,
              success: () => {},
              complete: () => {
                this.setData({
                  account_focus: false
                })
              }
            })
          }
        }
      })
    }
  },
  /*****号码输入******/
  phoneinput: function(e) {
    this.data.phone = e.detail.value
  },
  //倒计时
  settime: function(countdown, tant) {
    tant.data.countdown=60;
    this.setData({
      countdown:60
    })
    timer = setInterval(() => {
      if (countdown == 0) {
        clearInterval(timer)
        this.setData({
          countdown_state: false,
          obtain: '重新获取'
        })
      } else {
        countdown--;
        tant.setData({
          countdown: countdown
        })
      }
    }, 1000)
  },
  //切换密码
  modifydisplay: function() {
    this.setData({
      login: false,
      modify: true,
      register: false,
      forgetaccount:false,
    })
    this.initial()
  },
  //忘记密码
  forgetaccountFun: function () {
    this.setData({
      login: false,
      modify: false,
      register: false,
      forgetaccount: true,
      obtain:'获取验证码',
      countdown_state:false,
    })
    this.initial()
  },
  //切换登录
  logindisplay: function() {
    this.setData({
      login: true,
      modify: false,
      register: false,
      forgetaccount:false,
    })
    this.initial()
  },
  loginaccount:function(e){
    this.setData({
      accactive: e.currentTarget.dataset.index
    })
    setTimeout(()=>{
      this.setData({
        login: true,
        modify: false,
        register: false,
        forgetaccount: false,
      })
      this.initial()
      this.setData({
        account: e.currentTarget.dataset.account
      })
    },700)
  },
  //切换注册
  registerdisplay: function() {
    this.setData({
      login: false,
      modify: false,
      register: true,
      forgetaccount:false,
    })
    this.initial()
  },
  //监听验证码
  verificacode: function(e) {
    this.data.codekey = e.detail.value
  },
  //监听密码
  passwordtake: function(e) {
    this.data.password = e.detail.value
  },
  //确认密码
  passwordconfirm:function(e){
    this.data.password_confirm = e.detail.value
  },
  //注册
  registerMethod: function() {
    var _this = this.data;
    if (_this.account.length != 0 && _this.password.length != 0 && _this.phone.length != 0 && _this.codekey.length != 0) {
      if (!util.password(_this.password)) {
        util.iconnone('密码长度大于8小于16')
        return
      }
      if (_this.account.length<6) {
        util.iconnone('账号长度必须大于6位')
        return
      }
      if (_this.password_confirm != _this.password){
        console.log(_this.password_confirm)
        util.iconnone('两次密码不一致')
        return
      }
      wx.request({
        url: util.prefixUrl() +'supp/supplier/register',
        method: 'POST',
        data: {
          username: _this.account,
          password: _this.password,
          tel: _this.phone,
          codekey: _this.codekey
        },
        success: (res) => {
          if (res.data.code == 0) {
            wx.showToast({
              title: '注册成功',
              duration: 1000,
              mask: true,
              success: (res) => {
                this.setData({
                  login: true,
                  modify: false,
                  register: false,
                  forgetaccount:false,
                })
                this.initial()
              },
            })
          } else {
            wx.showToast({
              title: res.data.msg,
              image: '../image/error.png',
              duration: 1000,
              mask: true,
              success: () => {

              },
              complete: () => {}
            })
          }
        }
      })
    }else{
      util.iconnone('请填写完整') 
    }
  },
  // 登录
  loginMethod: function() {
    var _this = this.data;
    if (_this.account.length == 0) {
      util.frametips('请输入账号')
      return;
    } else if (_this.password.length == 0) {
      util.frametips('请输入密码')
      return;
    }
    wx.showLoading({
      title:'正在登录',
      mask:true,
    })
    wx.request({
      url: util.prefixUrl() +'supp/supplier/login',
      method: 'POST',
      data: {
        username: _this.account,
        password: _this.password
      },
      success: (res) => {
        if (res.data.code == 0) {
          util.put('user', res.data.data, 86400)
          wx.hideLoading({})
          util.successtips('登录成功')
          setTimeout(() => {
            wx.reLaunch({
              url: '../tabBar/index/index',
            })
          }, 700)
        } else{
          wx.hideLoading({})
          util.iconnone(res.data.msg);
        }
      },
      fail: (res) => {
        util.frametips('系统故障')
      }
    })
  },
  //修改密码
  modifyMethod: function() {
    var _this = this.data;
    if (_this.account.length != 0 && _this.password.length != 0 && _this.phone.length != 0 && _this.codekey.length != 0) {
      if (!util.password(_this.password)) {
        util.iconnone('密码长度大于8小于16')
        return
      }
      if (_this.password_confirm != _this.password) {
        console.log(_this.password_confirm)
        util.iconnone('两次密码不一致')
        return
      }
      wx.request({
        url: util.prefixUrl() +'supp/supplier/repass',
        method: 'POST',
        data: {
          username: _this.account,
          password: _this.password,
          tel: _this.phone,
          codekey: _this.codekey
        },
        success: (res) => {
          if (res.data.code == 0) {
            util.successtips('修改成功')
            this.setData({
              login: true,
              modify: false,
              register: false,
              forgetaccount:false
            })
            this.initial()
          } else if (res.data.msg == '验证码错误') {
            _this.failtips('验证码错误')
            _this.account
            this.setData({
              codekey: ''
            })
          } else {

          }
        }
      })
    } else {
      util.iconnone('请填写完整')
    }
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },
  //初始化数据
  initial: function() {
    var _this = this.data
    _this.account = '' //账号
    _this.account_focus = false
    _this.phone = '' //手机号码
    _this.phone_focus = false
    _this.password = '' //密码
    _this.password_confirm = '' //密码
    _this.codekey = '' //验证码
    clearInterval(timer);
    this.setData({
      codekey_focus: false,
      phone_focus: false,
      account_focus: false,
      obtain:'获取验证码',
      countdown_state:false,
      countdown:60,
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  //忘记密码
  modifyUname: function() {
    wx.request({
      url: util.prefixUrl() +'supp/supplier/check',
      method: 'POST',
      data: {
        username: this.data.account
      },
      success: (res) => {
        if (res.data.code == 0) {
          util.frametips('此账号未注册');
          this.setData({
            account_focus: true,
            account:''
          })
        }
      }
    })
  },
  modify: {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //查询账号
  findUsername:function(){
    var _this=this.data;
    console.log()
    wx.request({
      url: util.prefixUrl() +'supp/supplier/findUsername',
      method:'POST',
      data:{
        tel:_this.phone,
        codekey: _this.codekey
      },
      success:(res)=>{
        if(res.code!=1){
          this.setData({
            accountinput: false,
            accountArray: res.data,
          })
        }
      }
    })
  },
  // 协议
  agreementBook:function(){
    wx.navigateTo({
      url: '../user/pages/agreement/agreement',
    })
  }
})